# Публичная копия MSS Master Implementation Plan

План и матрицы подготовлены для Makepad SandStudio по срезу 2026-10-30.
Это документация и данные анализа, не release работающего runtime.

Перед публичным размещением из метаданных убраны локальные пользовательские
пути. Исходные записи GitHub, точные SHA, результаты проверок и тексты
зафиксированных публичных исходников сохранены. Manifest хешей пересобран для
публичной копии. Исходный локальный архив не изменялся.

## Включённые исходные тексты

`toolkit/source-bundle.json` содержит выбранные публичные исходники
**paulgreenbox-beep/rust-makepad-toolkit** на commit
`0b01942f1a7d1c276f130c9db03146cb96c1718a`.

Copyright (c) 2026 paulgreenbox-beep. Полный исходный текст MIT License включён
в [LICENSES/rust-makepad-toolkit-MIT.txt](LICENSES/rust-makepad-toolkit-MIT.txt).
Лицензия получена из LICENSE на указанном commit. В комплекте нет полной копии
Makepad SDK. Ссылки на исходники не являются доказательством runtime acceptance.

Проверка целостности и связности: `node validate-plan.mjs`.
Она не запускает MSS/Toolkit тесты, приложения или модели.

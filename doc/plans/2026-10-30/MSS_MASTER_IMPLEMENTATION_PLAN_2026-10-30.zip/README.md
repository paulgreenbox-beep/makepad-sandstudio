# MSS MASTER IMPLEMENTATION PLAN — комплект аудита

Основной документ: [MSS_MASTER_IMPLEMENTATION_PLAN.md](MSS_MASTER_IMPLEMENTATION_PLAN.md).
Он содержит все 18 запрошенных разделов на русском языке. Приложения ниже —
часть единого плана, а не отдельные разрешения на реализацию.

Снимок источников: 2026-10-30; повторная сверка GitHub — 19:33:58 UTC.
Main и девять открытых Draft PR сохранили HEAD SHA. Исходники, ветки, PR,
upstream, Secrets и настройки хоста не менялись; мониторинг остаётся PAUSED.

## Начать чтение

1. [Основной план, 18 разделов](MSS_MASTER_IMPLEMENTATION_PLAN.md).
2. [Первые 10 готовых инженерных задач](first-ten-tasks.md).
3. [Упорядоченные 22 PR-пакета](ordered-pr-backlog.md).
4. [54 фальсифицируемых инварианта](invariant-catalog.md).
5. [68 будущих проверок](missing-tests.md).
6. [Все 112 операций Toolkit](toolkit/toolkit-operations-appendix.md).
7. [Полный именованный инвентарь существующих MSS-тестов](existing-test-inventory.md).
8. [Runtime/Windows source audit](runtime/runtime-audit.md) и
   [Broker/dispatcher security audit](infrastructure/infrastructure-audit.md).

## Машиночитаемые приложения

| Файл | Назначение |
|---|---|
| repository-snapshot.json / final-github-recheck.json | Точные SHA/status/base, Issues6/8, повторная сверка |
| commit-statuses.json / check-runs.json | Реальное отсутствие Actions/check evidence, не false PASS |
| component-inventory.json | Current Main / PR / implementation / verification / gaps / risk |
| invariants.json | 54 правила с counterexample/test/evidence/status |
| proposed-tests.json | 68 NOT_RUN требований к будущим проверкам |
| pr-backlog.json | 22 пакета с base, dependencies, scope, invariants/tests и merge gates |
| first-ten-tasks.json | 10 пакетов с inputs, changes, tests, expected result и DoD |
| risks-and-decisions.json | P0–P3 и явные проектные решения |
| ci-gates.json | Раздельные root, broker, standalone fixture, Node и live gates |
| toolkit/toolkit-parity.json | 112 exact catalog rows; реальные source flags отдельно от planned acceptance |
| toolkit/scenario-registry.json | 44 checked-in .aiui.json пути:43v1 scripts +1suite,13sample-not-run |
| toolkit/test-inventory.json | 210Rust /116Node declarations; не количество runtime cases |
| runtime/runtime-test-inventory.json | 45 именованных случаев с разными ревизиями и результатами |
| infrastructure/infra-test-inventory.json | 119 случаев:39Rust +80Node, с exact source/log evidence |
| artifact-validation.json | Результат локальной проверки артефактов, не MSS acceptance |

164 именованных MSS-случая — объединённый **реестр разных веток**, не один
прошедший suite. Исторические результаты: PR10 logical44 PASS; PR11
44PASS/1FAIL и fmtFAIL; инфраструктура37activeRust PASS/2NOT_RUN и80Node PASS.
Production/USER32 остаются BLOCKED/NOT_VERIFIED. Новых project test runs в
планировании не было. Все необходимые ограничения и старые FAIL сохранены.

## Проверить комплект

```text
node validate-plan.mjs
```

Нужен только уже установленный Node, без npm install, сети, Cargo или запуска
приложений. Валидатор проверяет 18 разделов, все ссылки между инвариантами/
тестами/PR, ацикличность зависимостей, все112 строк против исходного каталога,
161 исходный Git blob Toolkit, словарь статусов и наличие source-bound evidence.
`VALID` относится только к артефактам плана.

`build-master.mjs` — локальный генератор документации. Для его повторной сборки
нужны исходные локальные MSS Git objects и прежние локальные evidence-файлы;
поэтому он не обещает самодостаточную регенерацию на другом компьютере.
Проверка `validate-plan.mjs` самодостаточна внутри распакованного комплекта.

Toolkit содержит отдельные Python extract/validate helpers, но основной
Node-валидатор уже проверяет обязательную полноту и hashes. Две дополнительные
попытки запуска через Windows Python aliases в корневом shell оказались
BLOCKED_ENVIRONMENT; ничего не устанавливалось. Подробности и границы
проверок сохранены в artifact-limitations.json. Это не результат MSS-тестов.

## Независимый просмотр и доказательства

Первоначальные замечания: infrastructure/review-master.json. Их исправления и
финальная проверка восьми файлов с hashes: infrastructure/final-review.json.
Это статическая рецензия плана, а не квалификация безопасности runtime.

В evidence/ сохранены source-bound JSON старых запусков. Raw logs с локальными
путями не публикуются этим комплектом. Source/hash/line indexes позволяют
проверить происхождение. Toolkit source-bundle — выбранные pinned публичные
тексты для чтения, не исполняемый checkout и не копия Makepad SDK.

Никакой пакет не исполняется автоматически. Следующее действие — отдельное
разрешение владельца на W01/A00: исправление Unicode fixtures и форматирования
существующего PR11 с сохранением тестов и повторной проверкой нового SHA.

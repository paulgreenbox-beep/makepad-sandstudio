# PR #11 — проверка на Windows

Результат: **FAIL**. Проверен актуальный HEAD
`192b81ac83cfa3945318804430af25b3795609ad` из
https://github.com/paulgreenbox-beep/makepad-sandstudio/pull/11.
База: `8863cc326b99f8d76b2bf66725d87540aab79f02`.
После проверок HEAD повторно сверен с GitHub и не изменился.

Среда: Windows NT 10.0.26300.0, Rust/Cargo 1.97.1. Команды выполнялись
последовательно, с CARGO_NET_OFFLINE=true, CARGO_BUILD_JOBS=2,
CARGO_INCREMENTAL=0, в отдельном чистом detached checkout.

| Команда | Статус | Exit code |
|---|---|---|
| cargo test -p mss-remote --lib --locked --offline tests::rejects_noncanonical_padded_widget_addresses_without_dispatch -- --exact | FAIL | 101 |
| cargo metadata --format-version 1 --locked --offline | PASS | 0 |
| cargo fmt --all -- --check | FAIL | 1 |
| cargo check --workspace --all-targets --locked --offline | PASS | 0 |
| cargo test --workspace --all-targets --no-fail-fast --locked --offline | FAIL | 101 |
| cargo clippy --workspace --all-targets --locked --offline -- -D warnings | PASS | 0 |
| git diff --check 8863cc326b99f8d76b2bf66725d87540aab79f02 HEAD | PASS | 0 |

Общий набор: **44 PASS, 1 FAIL, 0 ignored**. Core16, API6, Remote5 PASS /1 FAIL,
Render9 и восемь интеграционных тестов. Первый именованный запуск повторяет тот
же падающий тест и не является вторым отдельным дефектом.

Падает `tests::rejects_noncanonical_padded_widget_addresses_without_dispatch`.
В строке352 MSS_Remote/src/lib.rs заданы:

```rust
"\\u{00a0}input.name"
"input.name\\u{2003}"
```

Это буквальные строки с обратным слешем и текстом u{...}, а не символы NBSP
и em-space. В строке356 наблюдается `Err(NotDispatched)` вместо ожидаемого
`Err(InvalidInput)`. Тест прекращается на первом таком расхождении, поэтому
оставшиеся примеры внутри него не дают доказательства результата.

Минимальная предлагаемая коррекция тестовых данных, не внесённая этим прогоном:

```rust
"\u{00a0}input.name"
"input.name\u{2003}"
```

Форматирование требует развернуть массив тестовых значений и убрать пустую
строку перед закрывающей скобкой модуля. После исправления необходим повторный
прогон. Ни один assertion не менялся и не отключался.

Сборки debug/release отдельно NOT_RUN: текущая задача — тестирование точечного
Rust-изменения; полная milestone release-проверка интеграции здесь не повторялась.
Существующие duplicate-package предупреждения Cargo остались в логах.

Исходники, lockfile, PR и ветки не изменены. GitHub-записей/комментариев нет.
Dispatcher, модели/API-canary, GUI и пользовательский desktop не запускались.
Контейнеры/VM и внешние исходные репозитории не использовались и не менялись.
Нативный runtime и полный Toolkit parity остаются NOT_VERIFIED.

Точные команды, времена, коды выхода, имена тестов и SHA256 локальных логов
сохранены в checks.json и summary.json рядом с этим отчётом. Raw logs остаются
локальными: они могут содержать пути checkout/cache, поэтому не публиковались.

"""Source-only MSS planning audit. No upstream code, tests or applications run.

Inputs are pinned read-only GitHub text snapshots. Writes stay beside this file.
Literal source/test links are candidates, never execution/semantic-coverage proof.
"""
from __future__ import annotations
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = 'paulgreenbox-beep/rust-makepad-toolkit'
BASE = 'prototypes/ai-ui-test-tool-auto-probe/'

# Proposed independent MSS acceptance observations, NOT existing implementations.
# Exactly one explicit entry per catalog operation; additions fail closed below.
POSTCONDITIONS = '''
session.open|Независимый реестр показывает ровно новую owned-сессию с app PID/birth/image и отдельным worker/channel; соседние записи неизменны.
session.list|Снимок авторитетного реестра совпадает с выданным списком доступных caller сессий; закрытые/чужие и неявная default-сессия не добавлены.
session.close|Повторное чтение owned-реестра не находит точную incarnation; retained app/worker handles сигнализированы и её каналы/ресурсы освобождены, сосед сохранён.
acquire_input_lock|Независимый lease snapshot содержит одну выдачу caller/session с ограниченным сроком; конкурент не получает тот же ресурс до освобождения.
release_input_lock|Lease snapshot больше не содержит точный session/token; чужая аренда и её состояние неизменны.
inspect_ui|Полученное дерево совпадает с app-originated semantic snapshot той же incarnation и revision; узлы/состояния соседней сессии отсутствуют.
inspect_semantic|Независимый semantic producer подтверждает набор стабильных IDs, типов, capabilities и состояний в той же revision без скрытой физической подмены.
inspect_spatial_target|Независимый layout snapshot подтверждает ID, finite actionable bounds, DPI/scale и layout generation; разрешённая точка внутри целевого прямоугольника.
read|Повторный app-side read подтверждает значение/состояние точного AutomationId и generation; чтение не изменяет state revision.
set_value|App-side value readback равен value до и после settle; сохранён именно declared SetValue mechanism, runtime health и соседние значения неизменны.
input|Readback и app event trace подтверждают text и требуемый input-механизм/события до и после settle; SetValue не считается эквивалентом без отдельного доказательства.
click|App action log содержит одно действие точного ID; независимое заданное postcondition выполнено, target-state и runtime health проверены после settle.
focus|App-side focus owner стал точным ID в той же сессии; keyboard target readback совпадает, foreground пользовательского desktop не менялся.
double_click|App trace подтверждает double-click одного ID с нужной семантикой и его независимым наблюдаемым эффектом; single-click не считается заменой.
right_click|App snapshot показывает контекстное действие/меню правильного ID; соседние меню/сессии и пользовательский desktop не затронуты.
toggle|Readback toggled/selected состояния точного ID соответствует ожидаемому переходу и остаётся тем же после settle.
choose|Value/selection readback совпадает с указанным value и допустимым вариантом; app event trace и стабильное состояние подтверждены.
select|Независимый selection snapshot содержит целевой ID по declared single-selection правилам; соседняя сессия неизменна.
add_to_selection|Selection snapshot добавляет ID, сохраняя прежние выбранные элементы; capabilities разрешают multiple selection.
remove_from_selection|Selection snapshot исключает только ID, сохраняя остальные выбранные элементы.
clear_selection|Selection snapshot целевого scoped-контейнера пуст, при этом список элементов и соседний контейнер не изменились.
select_many|Selection snapshot точно совпадает с запрошенным набором ids согласно documented replacement semantics; порядок/дубликаты не создают лишних эффектов.
select_range|Readback показывает ровно диапазон start_id..end_id по независимому порядку элементов, включая границы; вне диапазона соблюдён declared selection contract.
ensure_visible|Независимые layout/viewport snapshots показывают видимую actionable часть ID и совпадающую layout generation; чужой viewport не сдвинут.
scroll|Снимок scroll offset/content anchor отражает delta и declared clamp; bounds/layout revision целевой области обновлены, соседняя область сохранена.
scroll_to_start|Readback scroll offset достиг начала доступного диапазона, начальный content anchor видим и состояние стабильно после settle.
scroll_to_end|Readback достиг конца доступного диапазона и конечный content anchor видим; ложная остановка при virtualized loading исключена.
wait_for_automation_id|Независимый snapshot до deadline содержит точный ID в целевой incarnation; last observation и elapsed time сохранены.
wait_for_value|Независимые повторные reads до deadline подтверждают требуемое value; timeout не преобразуется в успех.
wait_for_state|App snapshot до deadline удовлетворяет полному заданному state predicate, а не одному выбранному полю; сохранено последнее наблюдение.
wait_until|Независимый observer до deadline подтвердил condition над актуальным scoped состоянием; bounded polling и последнее несовпадение сохранены.
wait_visible|Scoped layout/semantic snapshot до deadline показывает ID visible с актуальными bounds, а не лишь существующий узел.
wait_hidden|Scoped snapshot до deadline показывает declared hidden/absence predicate точного ID; ошибка чтения не считается скрытием.
wait_enabled|App readback до deadline показывает enabled=true для ID при живом runtime.
wait_disabled|App readback до deadline показывает enabled=false для ID; отсутствие/ошибка наблюдения не подменяет false.
wait_selected|Независимый selection snapshot до deadline содержит выбранный ID и его контейнер.
wait_count|Независимая scoped enumeration до deadline даёт count по declared фильтру/контейнеру, не truncated выборку.
wait_idle|App-side pending work/input/render observations удовлетворяют объявленному idle predicate в нужном интервале; простой sleep не является доказательством.
assert_visible|Актуальный scoped snapshot подтверждает visible ID и причину видимости; missing/hidden возвращают неуспех с evidence.
assert_interactable|Независимый snapshot подтверждает visible/enabled/actionable bounds и необходимые capability/obstruction условия для точного ID.
assert_valid_bounds|Bounds/layout generation актуальны, координаты finite, размеры положительны и согласованы с родительским clip/viewport.
assert_canvas_healthy|App/render telemetry подтверждает требуемое состояние Healthy с generation и provenance; Unknown/Degraded не считаются Healthy.
get_canvas_health|Выданный enum и diagnostics совпадают с независимой canvas/render telemetry; неизвестность сохранена явно без продвижения в Healthy.
move_pointer|App-side pointer observer показывает точную resolved position внутри ID и правильную layout generation; пользовательский cursor не перемещён.
pointer_down|App input state содержит нажатую нужную button и target/pointer capture той же сессии; соседний input state сохранён.
pointer_up|App input state больше не содержит указанную button; capture/gesture release подтверждены независимо, даже при ошибочном предшествующем жесте.
click_relative|Resolved point подтверждён layout snapshot; app action trace и независимое postcondition относятся к этой точке/ID ровно один раз.
double_click_relative|App trace подтверждает double-click в resolved position и соответствующий наблюдаемый эффект, при неизменной target generation.
right_click_relative|App trace и контекстное состояние подтверждают right-click в resolved position нужного ID; соседний target не активирован.
hover_relative|App hover target/position readback совпадает с ID/relative position и актуальными bounds; действие не подменено click/focus.
wheel_relative|App scroll offset/anchor изменился согласно delta_y у scoped resolved position; другая scrollable область не изменилась.
drag|App gesture trace и state readback подтверждают перенос ID к to с правильными down/move/up и освобождённым capture.
drag_to|App readback подтверждает результат drag source id на target_id, порядок/данные target и source согласованы, capture освобождён.
drag_relative|App trace подтверждает from->to внутри актуальных bounds, declared button и независимый drag effect; button/capture после жеста освобождены.
select_region|Selection geometry readback совпадает с from/to после coordinate conversion; crop/clip/DPI и generation подтверждены.
hotkey|App key/modifier trace и отдельное postcondition подтверждают нужную комбинацию; после завершения нет удержанных modifiers.
press|App key trace содержит ровно declared key press/release, postcondition выполнено и не осталось held key.
press_repeat|App trace содержит ровно count нажатий нужного key, readback эффекта соответствует count и все keys отпущены.
type_text|App text/event readback подтверждает точный Unicode text и declared typing mechanism; set_value/input не подменяются этим вызовом без parity proof.
activate_window|App-side active window/focus snapshot принадлежит exact owned window/session; пользовательский foreground desktop не используется как fallback.
windows_set_window_bounds|Независимый owned-window geometry readback равен width/height и заданным координатам с declared DPI/clamp; соседние окна неизменны.
inspect_window_interaction|Window capability/hit-region/frame/DPI metadata совпадает с независимым snapshot exact owned window, без его перемещения.
windows_drag_title|Owned-window bounds изменились на delta_x/delta_y по declared DPI/clamp; drag lifecycle завершён и соседний desktop не затронут.
windows_resize_frame|Независимый geometry readback соответствует requested target/frame edge, minimum constraints и DPI; pointer capture освобождён.
windows_double_click_title|Owned-window state readback подтверждает предусмотренный maximize/restore transition и соответствующие bounds.
windows_set_window_state|Независимый window state/visibility/bounds readback равен requested state; скрытое действие на другом окне исключено.
screenshot_window|Независимый renderer/capture provenance подтверждает exact window/session/frame revision, PNG decode/dimensions и freshness; статическая fixture не принимается за app frame.
screenshot_element|Изображение относится к точному ID и актуальному element clip/bounds; renderer provenance, decode и freshness подтверждены отдельно.
capture_region|Независимые layout и renderer observations подтверждают region conversion/crop, размеры, frame revision и exact source session.
windows_capture_region|PNG/crop metadata и provenance подтверждают requested region точного owned target с корректным DPI и declared native capture method.
get_runtime_health|Независимые retained-process liveness/exit и stderr/telemetry observers согласованы с health report; fatal Makepad/Script errors не скрыты.
get_runtime_stderr|Возвращён bounded tail именно owned процесса, включая удержанные critical errors; timestamps/sequence согласованы с независимым capture.
windows_export_evidence|Независимое чтение bundle подтверждает required JSON/artifacts, ordered action/result identities, hashes и redaction; bundle с пропуском обязательного файла не успешен.
windows_validate_evidence|Проверка реального bundle независимо обнаруживает изменённые hashes, отсутствующие файлы, cross-session identities и несогласованные counts; валидный bundle даёт явный результат.
get_task_state|App-originated task registry для operation_id подтверждает state/result/error и generation без изменения самого task.
wait_for_task|До deadline task observer подтверждает существование/declared target predicate operation_id, сохраняя terminal failures и последнее наблюдение.
wait_for_task_state|До deadline независимый task registry показывает exact requested state operation_id; failed/cancelled не преобразуются в желаемое состояние.
wait_for_task_complete|Task registry подтверждает terminal completion operation_id до deadline; completion отдельно отличает success от failure/cancellation.
assert_task_success|Task registry содержит terminal successful result operation_id и подтверждённые postconditions; completed-with-error не проходит.
get_runtime_milestones|Независимый ordered milestone log совпадает с возвращёнными names/sequences/timestamps данной generation.
wait_for_runtime_milestone|До deadline app-originated log содержит требуемое name в нужной generation; old-process milestone не принимается.
assert_runtime_milestone|В независимом текущем runtime log существует exact name с проверяемыми sequence/time/source, иначе явный assertion failure.
get_runtime_timeline|Returned ordered events согласованы с app/task/process observations и timestamps; пропуски/truncation помечены, не скрыты.
get_api_request_state|Trusted request observer подтверждает request_id state/status/acceptance, correlation и generation; агентский произвольный HTTP ответ не является authority.
wait_for_api_state|До deadline trusted observer показывает requested state exact request_id; HTTP success отдельно не означает accepted/completed.
wait_for_api_response|Trusted observer подтверждает полученный correlated response до deadline, включая валидность payload/status и явный failure outcome.
assert_api_success|Независимый request observer подтверждает transport/HTTP/payload/acceptance success request_id; каждый обязательный уровень отдельно проверен.
assert_api_failure|Trusted observer подтверждает ожидаемый failure request_id и его класс; ошибка самой проверки не засчитывается как ожидаемый API failure.
wait_for_file|Trusted root-bound filesystem observer до deadline подтверждает path без traversal/reparse escape и нужный object type/source.
assert_file_exists|Независимый filesystem stat подтверждает объект внутри admitted root с canonical identity; access denied не считается существованием.
assert_file_not_exists|Trusted root-bound observer подтверждает отсутствие exact path; access denied/invalid path/ошибка проверки не считаются отсутствием.
assert_file_size|Bounded stat внутри admitted root показывает ровно expected_bytes для exact file identity, не меняющегося между read/stat.
assert_file_count|Root-bound enumeration показывает ровно count допустимых объектов по declared scope/filter, без truncation и symlink escape.
assert_file_hash|Независимое bounded чтение exact file identity даёт требуемый sha256; изменённый файл и подстановка между open/read отвергнуты.
wait_for_file_stable|Несколько root-bound stat/content observations в declared stable interval подтверждают неизменные identity/size/hash, не один удачный poll.
assert_not_blank|Независимый декодер и declared content metric подтверждают nonblank app-originated capture с provenance; synthetic PNG header не является доказательством.
assert_region_changed|Fresh current capture и bound baseline одной region/session отличаются по declared metric/threshold; unrelated region и stale frame исключены.
assert_region_unchanged|Fresh captures той же bound region удовлетворяют declared unchanged tolerance; отсутствие/ошибка capture не считается unchanged.
assert_similarity|Независимый comparison вычисляет declared similarity metric/threshold на fresh capture и bound baseline с согласованными dimensions.
compare_screenshot|Comparison report повторно вычисляется из проверенных baseline/current bytes и совпадает по metric/threshold, source/crop/dimensions.
get_makepad_visual_diagnostics|App-originated renderer/layout diagnostics совпадают с независимыми frame/layout generations; отсутствие telemetry остаётся Unknown.
get_application_logs|Независимый owned log sink подтверждает ordered bounded records/correlation/time range; реальные secrets отредактированы и соседние логи отсутствуют.
wait_for_log|До deadline owned log observer содержит contains в правильной correlation/generation; историческая строка другого запуска не принимается.
assert_log_contains|Независимый scoped log snapshot содержит contains в заявленном диапазоне и сообщает truncation; отсутствие не скрывается.
assert_log_not_contains|Полный достаточный scoped log interval не содержит contains; truncated/missing interval не может доказать отрицание.
assert_trace_event|Trusted trace observer содержит exact event с нужной session/correlation/time ordering; текст похожего лога не подменяет trace.
assert_no_stale_window|Independent owned-window registry и retained native observations не содержат stale identities после завершения; чужие окна не перечисляются для cleanup.
assert_no_pending_task|App task registry и worker state подтверждают отсутствие pending/running задач в exact session; неизвестный task state не считается пустым.
assert_no_phantom_semantic_node|Semantic snapshot для exact id согласован с живым widget/layout lifecycle; detached/disposed phantom node отсутствует без обращения к соседним IDs.
repeat_until|Независимые observation samples показывают завершение declared predicate внутри timeout/max_iterations; число вызовов bounded и неподходящая мутация не повторяется автоматически.
wait_for_outcome|Один из явно заданных outcomes подтверждён независимым observer до deadline с bounded iterations; missing/ambiguous outcome остаётся явным failure/unknown.
click_once_and_wait_for_outcome|Trace подтверждает не более одного dispatch click, затем только bounded observation; принятое ambiguous error не вызывает второй click, outcome подтверждён независимо.
'''

ARG_DESCRIPTIONS = {
 'id':'Точный semantic/AutomationId target в текущей session; catalog не задаёт отдельный JSON type.',
 'session_id':'Явная сессия; не OS PID и не implicit current session.',
 'value':'Запрошенное значение; точный backend-specific тип не задан generic step schema.',
 'text':'Текст по контракту данной операции; input и type_text сохраняют разные механизмы.',
 'token':'Точный ранее выданный input lease token той же сессии.',
 'ids':'Набор exact target IDs; declared multiple-selection semantics обязательна.',
 'start_id':'Первый exact ID диапазона в авторитетном порядке элементов.',
 'end_id':'Последний exact ID диапазона в авторитетном порядке элементов.',
 'delta':'Величина прокрутки по backend contract; единицы не следует угадывать.',
 'state':'Ожидаемое состояние/предикат; shape зависит от операции и не унифицирован catalog.',
 'condition':'Явный проверяемый предикат; generic schema допускает operation arguments.',
 'count':'Требуемое количество; проверка допустимого диапазона принадлежит owning validator.',
 'position':'RelativePoint; spatial.rs проверяет finite координаты в [0,1].',
 'button':'Кнопка указателя по owning validator; не произвольная host-input команда.',
 'delta_y':'Вертикальная wheel delta по declared spatial contract.',
 'to':'Назначение drag/relative gesture; shape зависит от точной операции.',
 'from':'Начало relative gesture; spatial validation должна подтвердить bounds/generation.',
 'target_id':'Exact semantic ID цели drag; не имя окна/процесса.',
 'keys':'Declared key/modifier combination, не строка shell-команды.',
 'key':'Одна клавиша по declared keyboard grammar.',
 'width':'Ширина окна по native/DPI contract; exact constraints проверяет backend.',
 'height':'Высота окна по native/DPI contract; exact constraints проверяет backend.',
 'delta_x':'Смещение окна по declared DPI/geometry contract.',
 'target':'Resize target geometry/frame region; exact shape определяет owning backend.',
 'region':'RelativeRect; spatial.rs проверяет finite normalized область и actionable bounds.',
 'bundle':'Evidence bundle reference; owning validator проверяет реальные файлы/identity/counts.',
 'operation_id':'Correlated ID app-side task, не OS process ID.',
 'name':'Exact runtime milestone name из app-originated telemetry.',
 'request_id':'Correlated ID trusted external request observer.',
 'root':'Идентификатор admitted trusted filesystem root, не произвольный host root.',
 'path':'Путь под trusted root; traversal/reparse/path authority требуют отдельной проверки.',
 'expected_bytes':'Ожидаемый размер exact file; единица — bytes.',
 'sha256':'Ожидаемый SHA-256 содержимого exact admitted file.',
 'baseline_path':'Bounded trusted baseline artifact reference; не произвольный секретный host path.',
 'contains':'Искомый log текст в scoped interval/correlation.',
 'event':'Ожидаемый trace event по trusted telemetry contract.',
 'outcomes':'Набор outcome descriptors; parsing/validation см. script_controls.rs.',
 'timeout_ms':'Явный bounded timeout; для script control schema 1..120000 ms.',
 'max_iterations':'Явный предел iterations; script control schema 1..1000.',
 'accept_ambiguous_error_codes':'Явный список accepted ambiguous dispatch errors; не разрешает второй click.'
}

def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))

def write_json(name, value):
    target = (ROOT / name).resolve()
    assert target.parent == ROOT, 'Artifacts may not escape the assigned directory'
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def sha256(raw): return hashlib.sha256(raw).hexdigest()

def source_url(path, line=None):
    url = f'https://github.com/{REPO}/blob/{SOURCE_SHA}/{path}'
    return url + (f'#L{line}' if line else '')

def line_at(text, pos): return text.count('\n', 0, pos) + 1

def brace_end(text, start, language='rust'):
    """Lexical balanced body: skip comments, Rust raw strings, quoted strings.
    This inventories definitions; it is not a Rust/JS semantic parser.
    """
    depth, i, n = 0, start, len(text)
    while i < n:
        if text.startswith('//', i):
            p = text.find('\n', i + 2); i = n if p < 0 else p + 1; continue
        if text.startswith('/*', i):
            d, i = 1, i + 2
            while i < n and d:
                if text.startswith('/*', i): d += 1; i += 2
                elif text.startswith('*/', i): d -= 1; i += 2
                else: i += 1
            continue
        raw = re.match(r'(?:br|r)(#{0,32})"', text[i:])
        if raw:
            closing = '"' + raw.group(1); p = text.find(closing, i + raw.end())
            i = n if p < 0 else p + len(closing); continue
        if language == 'js' and text[i] == '/':
            previous = text[:i].rstrip()
            if not previous or previous[-1] in '=(:,[!&|?{;' or re.search(r'\breturn$', previous):
                j, in_class = i + 1, False
                while j < n:
                    if text[j] == '\\': j += 2; continue
                    if text[j] == '[': in_class = True
                    elif text[j] == ']': in_class = False
                    elif text[j] == '/' and not in_class:
                        j += 1
                        while j < n and text[j].isalpha(): j += 1
                        i = j; break
                    elif text[j] == '\n': break
                    j += 1
                if i == j: continue
        char_literal = text[i] == "'" and re.match(r"'(?:\\.|[^'\\\n])'", text[i:])
        if text[i] in ('"', '`') or char_literal or (language == 'js' and text[i] == "'"):
            quote = text[i]; i += 1
            while i < n:
                if text[i] == '\\': i += 2
                elif text[i] == quote: i += 1; break
                else: i += 1
            continue
        if text[i] == '{': depth += 1
        elif text[i] == '}':
            depth -= 1
            if depth == 0: return i + 1
        i += 1
    return None

def quoted_operations(text):
    return sorted(name for name in OP_NAMES if re.search(r'["\']' + re.escape(name) + r'["\']', text))

def scan_tests(files):
    tests, functions, parse_issues = [], [], []
    rust_test = re.compile(r'(?P<attrs>(?:\s*#\[[^\]]*\]\s*)+)(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+(?P<name>\w+)[^{;]*\{')
    rust_fn = re.compile(r'\b(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+(\w+)[^{;]*\{')
    node_test = re.compile(r'(?<![\w.])(?:test|it)(?:\.(skip|todo|only))?\s*\(\s*(["\'`])((?:\\.|(?!\2).)*?)\2', re.S)
    for f in files:
        path, text = f['path'], f['content']
        if path.endswith('.rs'):
            test_spans = []
            for m in rust_test.finditer(text):
                if not re.search(r'#\[(?:[\w:]+::)?test(?:\s|\])', m.group('attrs')): continue
                opening = text.find('{', m.start(), m.end()); end = brace_end(text, opening)
                if end is None: parse_issues.append({'path':path,'line':line_at(text,m.start()),'kind':'unbalanced Rust test body'}); continue
                item = {'kind':'rust_test_declaration','path':path,'name':m.group('name'), 'line':line_at(text,m.start()),
                    'attributes':m.group('attrs').strip(), 'ignored_declared':bool(re.search(r'#\[ignore',m.group('attrs'))),
                    'operations_literal_mentions':quoted_operations(text[opening:end]),
                    'assertion_macro_count_lexical':len(re.findall(r'\bassert(?:_eq|_ne)?!',text[opening:end])),
                    'source_url':source_url(path,line_at(text,m.start())), 'execution_status':'NOT_RUN','execution_note':'Source audit only; not run by this audit'}
                tests.append(item); test_spans.append((m.start(),end))
            for m in rust_fn.finditer(text):
                if any(a <= m.start() < b for a,b in test_spans): continue
                opening=text.find('{',m.start(),m.end()); end=brace_end(text,opening)
                if end is None: continue
                body=text[opening:end]; names=quoted_operations(body)
                if names or m.group(1)=='main':
                    functions.append({'path':path,'name':m.group(1),'line':line_at(text,m.start()),
                        'operations_literal_mentions':names,'source_url':source_url(path,line_at(text,m.start())),
                        'error_code_literals':sorted(set(re.findall(r'\b(?:host_error|error)\s*\(\s*["\']([A-Z][A-Z0-9_]{3,})["\']',body)
                          + re.findall(r'\bcode\s*:\s*["\']([A-Z][A-Z0-9_]{3,})["\']',body))),
                        'relationship':'Exact quoted operation literal in lexical function body; not a semantic dispatch or coverage proof'})
        elif path.endswith('.mjs'):
            for m in node_test.finditer(text):
                tail=text[m.end():]; callback=re.search(r'(?:=>|function\s*\([^)]*\))\s*\{',tail)
                opening=m.end()+callback.end()-1 if callback else None
                end=brace_end(text,opening,'js') if opening is not None else None
                if callback is None or end is None: parse_issues.append({'path':path,'line':line_at(text,m.start()),'kind':'Node callback boundary unresolved'})
                tests.append({'kind':'node_test_declaration','path':path,'name':m.group(3), 'line':line_at(text,m.start()),
                    'mode':m.group(1) or 'normal','dynamic_name':m.group(2)=='`' and '${' in m.group(3),
                    'operations_literal_mentions':quoted_operations(text[opening:end]) if end else [],
                    'source_url':source_url(path,line_at(text,m.start())), 'execution_status':'NOT_RUN','execution_note':'Source audit only; not run by this audit'})
    for i,t in enumerate(tests): t['id']=f'T{i+1:04d}'
    for i,t in enumerate(functions): t['id']=f'F{i+1:04d}'
    return tests, functions, parse_issues

def walk_operations(value, pointer=''):
    uses=[]
    if isinstance(value,dict):
        if isinstance(value.get('op'),str): uses.append({'operation':value['op'],'json_pointer':pointer+'/op','form':'explicit_op'})
        if 'repeat_until' in value: uses.append({'operation':'repeat_until','json_pointer':pointer+'/repeat_until','form':'structural_script_control'})
        for k,v in value.items(): uses += walk_operations(v,pointer+'/'+k.replace('~','~0').replace('/','~1'))
    elif isinstance(value,list):
        for i,v in enumerate(value): uses += walk_operations(v,pointer+'/'+str(i))
    return uses

def slice_for(op):
    if op.startswith('session.') or op.endswith('input_lock'): return 'V1-owned-session-runtime'
    if op in ('inspect_ui','inspect_semantic','read','wait_for_automation_id'): return 'V2-semantic-read-identity'
    if op in ('set_value','input','focus','wait_for_value'): return 'V3-value-and-focus-separate-methods'
    if 'selection' in op or op in ('toggle','choose','select','select_many','select_range'): return 'V5-widget-selection'
    if op in ('click','double_click','right_click','click_once_and_wait_for_outcome'): return 'V4-invoke-and-uncertain-outcome'
    if op.startswith('windows_') and 'evidence' not in op and 'capture' not in op: return 'V7-window-lifecycle'
    if any(s in op for s in ('screenshot','region_changed','region_unchanged','similarity','not_blank','visual_diagnostics')) or op in ('capture_region','windows_capture_region'): return 'V9-native-render-visual-evidence'
    if op.startswith(('get_task','wait_for_task','assert_task','get_runtime','wait_for_runtime','assert_runtime','get_api','wait_for_api','assert_api','wait_for_file','assert_file','get_application_logs','wait_for_log','assert_log','assert_trace','assert_no_')): return 'V8-runtime-and-trusted-observers'
    if 'evidence' in op or op in ('repeat_until','wait_for_outcome'): return 'V10-script-and-evidence-composition'
    if any(s in op for s in ('pointer','relative','drag','scroll','hotkey','press','type_text','select_region','spatial')): return 'V6-addressed-spatial-keyboard-pointer'
    return 'V2-semantic-read-identity'  # Wait/assert predicates over the semantic state.

def failure_plan(op, record):
    specific = {
      'session.open':'Отказ при невалидном executable/launch binding; неизвестный start не выдаёт готовую сессию.',
      'session.close':'Unconfirmed exit/resource release остаётся cleanup-pending/unknown, сосед не завершается.',
      'acquire_input_lock':'Чужая/просроченная аренда и capacity conflict не выдают новый token.',
      'release_input_lock':'Неверный session/token не освобождает чужую аренду.',
      'windows_validate_evidence':'Missing/tampered bundle, identity mismatch и hash/count corruption дают явный validation failure.',
      'windows_export_evidence':'Неполный/redaction-failed export не получает successful receipt.',
      'assert_api_failure':'Невозможность observer прочитать состояние не считается ожидаемым API failure.',
      'assert_file_not_exists':'Permission denied/path error не считаются доказанным отсутствием.',
      'assert_log_not_contains':'Truncated/missing log interval не доказывает отрицание.',
      'click_once_and_wait_for_outcome':'Ambiguous dispatch сохраняется как unknown до независимого outcome; второй click запрещён.',
      'repeat_until':'Timeout/max_iterations и disallowed repeated mutation дают отказ; bounded loop не ослабляется.',
      'wait_for_outcome':'Ни один/несколько несовместимых outcomes к deadline не дают PASS.'
    }
    if op in specific: reason=specific[op]
    elif op.startswith('wait'): reason=f'Для {op} unmet predicate к deadline даёт timeout/failure с последним независимым наблюдением.'
    elif op.startswith('assert'): reason=f'Для {op} ложное/неизвестное условие даёт assertion failure; ошибка наблюдения не превращается в истину.'
    elif 'file' in op: reason=f'Для {op} traversal/reparse/foreign root, changing file identity и чтение с ошибкой дают отказ без доступа вне root.'
    elif 'screenshot' in op or 'capture' in op: reason=f'Для {op} stale/cross-session capture, invalid decode/crop/provenance и отсутствующий renderer дают явный failure/unsupported.'
    elif record.get('mutation') is True: reason=f'Для {op} неподтверждённый effect после dispatch сохраняется OUTCOME_UNKNOWN; postcondition mismatch/runtime crash дают явный failure.'
    else: reason=f'Для {op} отсутствующий/чужой/stale источник, malformed arguments или неполное независимое наблюдение дают явный отказ/unknown, не PASS.'
    return {'status':'NOT_VERIFIED','is_plan':True,'operation_specific':reason,
      'before_dispatch':'Deny foreign/stale/invalid scope before effects; missing admitted backend/prerequisite is UNSUPPORTED/BLOCKED, never PASS.',
      'after_uncertain_mutation':'OUTCOME_UNKNOWN; no automatic replay. Catalog idempotency and mutation flags are independent.'}

def declared(record, field):
    return {'status':'DECLARED' if field in record else 'NOT_VERIFIED','value':record.get(field),
      'reason':None if field in record else f'Field {field} absent in exact catalog; no inference is made.'}

def semantic_classification(name, record, refs):
    """Separate source-inferred/planned semantic effect from raw catalog fields.
    Read-only refers to the target app, never all filesystem/reporting effects.
    """
    if name in ('session.open','session.close'):
        effect='MUTATING_LIFECYCLE'; note='Изменяет session registry и может создавать/завершать app process; не read-only несмотря на отсутствующий mutation flag.'
    elif name in ('acquire_input_lock','release_input_lock'):
        effect='MUTATING_CONTROL_LEASE'; note='Меняет lease/control state даже без GUI действия и без mutation flag в catalog.'
    elif name=='click_once_and_wait_for_outcome':
        effect='MUTATING_ONCE_THEN_OBSERVATION'; note='Один click dispatch, затем bounded observation; idempotency нельзя вывести из bounded loop.'
    elif record.get('mutation') is True or name in ('ensure_visible','move_pointer','hover_relative'):
        effect='MAY_MUTATE_APP_UI_POINTER'; note='Может изменять value/selection/focus/scroll/window/pointer state; фактический метод и наблюдаемый effect доказываются отдельно.'
    elif name in ('screenshot_window','screenshot_element','capture_region','windows_capture_region','windows_export_evidence'):
        effect='ARTIFACT_PRODUCING_OBSERVATION'; note='Наблюдает app/renderer, но может записывать screenshots/bundle; read-like/idempotent не означает отсутствие filesystem side effects.'
    elif name in ('repeat_until','wait_for_outcome'):
        effect='LOCAL_BOUNDED_OBSERVATION_CONTROL'; note='Локальное управление observation/polling; разрешённый read subset задаёт script_controls, arbitrary mutation replay не разрешён.'
    elif 'file' in name:
        effect='TRUSTED_FILE_OBSERVATION'; note='Читает admitted-root filesystem; evidence/report wrappers могут создавать артефакты, mutation app не подразумевается.'
    elif name.startswith(('wait_','assert_')) or name=='windows_validate_evidence':
        effect='TARGET_OBSERVATION_OR_PREDICATE'; note='Проверяет target/observer predicate; auto-evidence/reporting может иметь filesystem side effects. Нормативная гарантия полной purity не установлена.'
    else:
        effect='TARGET_OBSERVATION'; note='Семантически read-like lookup/snapshot; internal health caches/action journals и report wrappers могут меняться. Полная purity не заявлена.'
    return {'source_inferred_classification':effect,'basis_status':'SOURCE_INFERRED_NOT_NORMATIVE_PURITY_GUARANTEE',
      'source_function_candidate_ids':refs,'explanation_ru':note,
      'normative_method_guarantee':'NOT_VERIFIED','planned_mss_classification':effect,
      'composition_side_effects':'Public runner/reliability may write reports/evidence on success/failure independently of target-app mutation.'}

def main():
    global SOURCE_SHA, OP_NAMES
    bundle=load('source-bundle.json'); tree=load('repository-tree.json'); versions=load('version-baselines.json')
    SOURCE_SHA=bundle['source_sha']; files=bundle['files']; by_path={f['path']:f for f in files}
    bad=[]
    for f in files:
        raw=f['content'].encode('utf-8')
        actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if f['sha']!=actual: bad.append({'path':f['path'],'expected_git_blob':f['sha'],'actual_git_blob':actual})
        f['sha256']=sha256(raw); f['source_sha']=SOURCE_SHA; f['source_url']=source_url(f['path'])
    if bad: raise SystemExit('Pinned text/blob mismatch: '+json.dumps(bad))
    raw_catalog=by_path[BASE+'operations.json']['content'].encode('utf-8')
    raw_schema=by_path[BASE+'ai-ui-test-script.schema.json']['content'].encode('utf-8')
    (ROOT/'operations.raw.json').write_bytes(raw_catalog); (ROOT/'schema.raw.json').write_bytes(raw_schema)
    catalog=json.loads(raw_catalog); schema=json.loads(raw_schema)
    OP_NAMES=[op['name'] for op in catalog['operations']]
    assert len(OP_NAMES)==len(set(OP_NAMES))==112
    post=dict(line.split('|',1) for line in POSTCONDITIONS.strip().splitlines())
    assert set(post)==set(OP_NAMES), ('Explicit postcondition inventory differs',set(OP_NAMES)-set(post),set(post)-set(OP_NAMES))
    assert all(arg in ARG_DESCRIPTIONS for op in catalog['operations'] for arg in op.get('required',[]))
    source_files=[f for f in files if f['path'].endswith(('.rs','.mjs'))]
    tests, functions, parse_issues=scan_tests(source_files)
    scenarios=[]
    for f in files:
        if not f['path'].endswith('.aiui.json'): continue
        doc=json.loads(f['content']); uses=walk_operations(doc)
        scenarios.append({'id':f'S{len(scenarios)+1:03d}','path':f['path'],'git_blob_sha':f['sha'],'sha256':f['sha256'],
          'source_sha':SOURCE_SHA,'source_url':source_url(f['path']),'name':doc.get('name'),
          'document_kind':'public_script_v1' if doc.get('version')==1 and 'steps' in doc else 'suite_wrapper',
          'explicit_not_run_sample':str(doc.get('name','')).startswith('sample-') and str(doc.get('name','')).endswith('-not-run'),
          'operation_uses':uses,'operations':sorted(set(u['operation'] for u in uses)),
          'suite_members':doc.get('tests',[]),'expected_error_cases':doc.get('steps',[]) if 'negative' in f['path'] else [],
          'tags':doc.get('tags',[]),'application':doc.get('application'), 'execution_status':'NOT_RUN','execution_note':'Source audit only; not run by this audit',
          'prohibited_environment_source_profile':bool(re.search(r'/container/|wslc|/physical-',f['path']))})
    rows=[]
    for index,op in enumerate(catalog['operations']):
        name=op['name']; tref=[t['id'] for t in tests if name in t['operations_literal_mentions']]
        fref=[t['id'] for t in functions if name in t['operations_literal_mentions']]
        sref=[{'scenario_id':s['id'],'json_pointers':[u['json_pointer'] for u in s['operation_uses'] if u['operation']==name]}
              for s in scenarios if name in s['operations']]
        codes=sorted(set(code for f in functions if name in f['operations_literal_mentions'] for code in f['error_code_literals']))
        line=next((n+1 for n,l in enumerate(raw_catalog.decode().splitlines()) if f'"{name}"' in l),1)
        logical = name in ('session.open','session.list','session.close','inspect_ui','inspect_semantic','read','set_value','input','focus')
        rows.append({'index':index+1,'name':name,'source_sha':SOURCE_SHA,'catalog_url':source_url(BASE+'operations.json',line),
          'planned_test_id':f'TK-OP-{index+1:03d}','planned_acceptance_gate':'A13','planned_test_status':'NOT_RUN',
          'catalog_record_exact':op,
          'argument_schema':{'catalog_required_exact':op.get('required',[]),'catalog_optional_exact':op.get('optional',[]),
             'generic_step_schema_ref':'schema.raw.json#/$defs/steps/items','generic_step_schema':schema['$defs']['steps']['items'],
             'operation_specific_formal_schema_status':'NOT_DECLARED_BY_CATALOG: generic step additionalProperties=true; owning Rust validators remain normative',
             'required_argument_readable_contracts':{a:ARG_DESCRIPTIONS[a] for a in op.get('required',[])},
             'script_controls_schema_ref':'schema.raw.json#/$defs/repeat_until' if name == 'repeat_until' else None,
             'control_operation_validator':source_url(BASE+'src/script_controls.rs') if name in ('repeat_until','wait_for_outcome','click_once_and_wait_for_outcome') else None},
          'capability':declared(op,'capability'),'mutation':declared(op,'mutation'),'idempotency':declared(op,'idempotency'),
          'physical_input':declared(op,'physical_input'),'scheduler_classification':declared(op,'scheduler_classification'),
          'declared_semantic_flags':{k:op[k] for k in ('target','wait','verification','assertion','spatial','local_only','coverage','evidence') if k in op},
          'semantic_effect_classification':semantic_classification(name,op,fref),
          'actual_physical_method':{'status':'NOT_VERIFIED','execution_note':'No runtime execution or observed physical method',
              'source_note':'Catalog physical_input is a declaration, not observed SendInput/UIA dispatch. Preserve set_value/input/click distinctions; no desktop fallback is authorized.',
              'source_owner_function_candidates':fref},
          'mss_equivalent':{'execution_status':'UNSUPPORTED','implementation_status':'NOT_IMPLEMENTED','verification_status':'NOT_VERIFIED','logical_gate_only':logical,
              'note':'Only in-process scoped registry/auth/refusal/intent validation or supplied-frame storage exists; no Toolkit execution adapter, native UI producer, app transport or runner is installed.'},
          'planned_independent_success_postcondition':{'status':'NOT_IMPLEMENTED','is_plan':True,'verification_status':'NOT_RUN','observation_ru':post[name],
              'binding':'Exact source, registry/session/generation, owned process birth/image/channel, request correlation, runtime health and retained evidence; no acknowledgement-only success.'},
          'failure_classification':failure_plan(name,op),
          'source_error_literals_candidates':{'values':codes,'status':'NOT_VERIFIED',
              'relationship':'Only host_error/error constructor or code-field literals in candidate functions; not an operation-specific error enum',
              'operation_error_contract_validated':False},
          'baseline_test_mapping':{'scenario_occurrences':sref,'test_declaration_ids':tref,'source_function_candidate_ids':fref,
              'coverage_status':'NOT_VERIFIED: exact literal references are navigation, not assertion review or an executed proof',
              'missing_existing_direct_test_reference':not bool(tref),'missing_existing_explicit_scenario_reference':not bool(sref),
              'missing_MSS_tests':[
                f'TK-OP-{index+1:03d}-CONTRACT [A13]: {name} unchanged public argument/schema negative conformance and foreign/stale ownership refusal',
                f'TK-OP-{index+1:03d}-EFFECT [A13]: {name} real owned-app effect/observation satisfying the explicit proposed postcondition',
                f'TK-OP-{index+1:03d}-FAILURE [A13]: {name} operation-specific failure/unknown outcome and runtime-health/evidence preservation',
                f'TK-OP-{index+1:03d}-ISOLATION [A13]: {name} two independent sessions, cancellation/owner loss and owned-only cleanup without user desktop']},
          'proposed_vertical_slice':slice_for(name)})
    fetched_paths={f['path'] for f in files}
    all_aiui={f['path'] for f in tree['tree'] if f['type']=='blob' and f['path'].endswith('.aiui.json')}
    all_sources={f['path'] for f in tree['tree'] if f['type']=='blob' and f['path'].endswith(('.rs','.mjs'))}
    assert all_aiui <= fetched_paths and all_sources <= fetched_paths
    meta={'schema':'mss-toolkit-parity-master-plan-v1','repository':REPO,'source_sha':SOURCE_SHA,'source_tree_sha':tree['sha'],
       'status':'SOURCE_ONLY_PLAN_NO_TOOLKIT_TEST_EXECUTED','catalog_version':catalog['version'],'operation_count':len(rows),
       'catalog_sha256':sha256(raw_catalog),'catalog_git_blob_sha':by_path[BASE+'operations.json']['sha'],
       'public_schema_sha256':sha256(raw_schema),'operations':rows,
       'test_inventory_ref':'test-inventory.json','scenario_registry_ref':'scenario-registry.json','source_inventory_ref':'source-inventory.json',
       'inventory_scope':{'tree_truncated':tree['truncated'],'repository_entries':len(tree['tree']),
          'repository_files':sum(f['type']=='blob' for f in tree['tree']),'all_rs_mjs_files_fetched':len(all_sources),
          'all_aiui_paths_fetched':len(all_aiui),'complete_catalog_rows':True,
          'not_a_full_executed_baseline':True,'limitations':['Static Rust/Node lexical test inventory is not macro-expanded/cfg-resolved test collection.',
            'Shell/CI/manual/native runner targets may add acceptance obligations; repository tree is retained for root review.',
            'Inline/generated JSON scenarios are not claimed as exhaustive concrete cases; all checked-in .aiui.json paths are enumerated.',
            'No Toolkit or MSS test, GUI/app, model canary, container/VM/WSL workflow was run.']},'versions':versions}
    write_json('toolkit-parity.json',meta)
    write_json('scenario-registry.json',{'schema':'mss-toolkit-scenarios-v1','source_sha':SOURCE_SHA,'count':len(scenarios),'scenarios':scenarios})
    write_json('test-inventory.json',{'schema':'mss-toolkit-test-source-inventory-v1','source_sha':SOURCE_SHA,
       'scope':'Every checked-in .rs and .mjs file in the nontruncated pinned repository tree; lexical declarations and candidate operation mentions only',
       'counts':dict(Counter(t['kind'] for t in tests)),'parse_issues':parse_issues,'tests':tests,'function_candidates':functions,
       'other_runner_and_shell_files':[f for f in tree['tree'] if f['type']=='blob' and f['path'].endswith(('.ps1','.cmd','.yml','.yaml'))]})
    write_json('source-inventory.json',{'schema':'mss-toolkit-source-inventory-v1','source_sha':SOURCE_SHA,
        'fetched_files':[{k:v for k,v in f.items() if k not in ('content','url')} for f in files],
        'all_repository_files':[{k:v for k,v in f.items() if k!='url'} for f in tree['tree'] if f['type']=='blob']})
    write_json('audit-summary.json',{'artifact_status':'VALID_SOURCE_INVENTORY_NOT_TEST_PASS','source_sha':SOURCE_SHA,
      'operations':len(rows),'catalog_sha256':sha256(raw_catalog),'all_aiui_paths':len(scenarios),
      'script_v1_paths':sum(s['document_kind']=='public_script_v1' for s in scenarios),'suite_wrappers':sum(s['document_kind']=='suite_wrapper' for s in scenarios),
      'explicit_not_run_profile_samples':sum(s['explicit_not_run_sample'] for s in scenarios),'test_declarations':dict(Counter(t['kind'] for t in tests)),
      'source_files_fetched':len(files),'rs_mjs_files':len(source_files),'test_parser_issues':parse_issues,
      'no_direct_scenario_ops':[r['name'] for r in rows if r['baseline_test_mapping']['missing_existing_explicit_scenario_reference']],
      'no_direct_test_literal_ops':[r['name'] for r in rows if r['baseline_test_mapping']['missing_existing_direct_test_reference']]})
    render_markdown(meta,scenarios,tests,parse_issues)
    print(json.dumps(load('audit-summary.json'),ensure_ascii=False,indent=2))

def escaped(s): return str(s).replace('|','\\|').replace('\n',' ')

def render_markdown(meta,scenarios,tests,issues):
    lines=['# Полный каталог Toolkit: план паритета MSS', '',
      f"Источник: `{meta['source_sha']}`; напрямую пересчитано **{meta['operation_count']} операций**. Это SOURCE-ONLY PLAN; ни одна операция/сценарий не запускалась.", '',
      'Каждая строка ссылается на полный machine-readable объект в [toolkit-parity.json](toolkit-parity.json). Его `catalog_record_exact` сохраняет исходные поля без додумывания. Полная generic step schema — [schema.raw.json](schema.raw.json); `additionalProperties=true` не является полной типизированной схемой аргументов каждой операции. Имена required сохранены точно; readable contracts редакционные, owning validators остаются нормативными.', '',
      '`mutation`, `idempotency` и `physical_input` независимы. «Не задано» означает NOT_VERIFIED, а не false/idempotent/semantic. Физический флаг каталога не доказывает фактический UIA/SendInput-механизм. SetValue, input и click не взаимозаменяемы. Source-inferred/planned effect class указан отдельно: lifecycle/lease/artifact side effects не теряются из-за отсутствующего mutation flag. Все postconditions И failure classifications ниже — **предлагаемые критерии**, не существующая MSS реализация или подтверждённый per-op error enum. Полные source purity/method guarantees NOT_VERIFIED.', '',
      'S = число checked-in сценариев с явной/структурной ссылкой, U = число unit/Node declarations с точным quoted operation literal. Это навигационные кандидаты, не доказательство assertion coverage. Полные file/line/hash/JSON-pointer ссылки и недостающие MSS проверки — в JSON, [test-inventory.json](test-inventory.json) и [scenario-registry.json](scenario-registry.json).', '',
      'Статусы MSS разделены: `execution_status=UNSUPPORTED`, `implementation_status=NOT_IMPLEMENTED`, `verification_status=NOT_VERIFIED`. Будущие acceptance tests имеют отдельный `planned_test_status=NOT_RUN`; составные статусы и PASS для плана не используются.', '',
      '| № / operation | Required / capability | Mutation / idempotency / physical declaration | Предлагаемое независимое postcondition | Failure / test mapping / MSS |',
      '|---|---|---|---|---|']
    for r in meta['operations']:
        cat=r['catalog_record_exact']; name=r['name']; required=', '.join(cat.get('required',[])) or 'нет required в catalog'
        flag=lambda k: str(cat[k]).lower() if k in cat else 'NOT_VERIFIED: не задано'
        cap=cat.get('capability','NOT_VERIFIED: не задана')
        mapping=r['baseline_test_mapping']; s=len(mapping['scenario_occurrences']); u=len(mapping['test_declaration_ids'])
        lines.append('| '+ ' | '.join(map(escaped,[f"{r['index']}. [{name}]({r['catalog_url']}) / {r['planned_test_id']} [A13]",f'{required}; cap={cap}; schema=generic step + owning validator',
          f"mutation={flag('mutation')}; idem={flag('idempotency')}; physical={flag('physical_input')}; effect plan={r['semantic_effect_classification']['planned_mss_classification']}",
          r['planned_independent_success_postcondition']['observation_ru'],
          f"{r['failure_classification']['operation_specific']} S={s}, U={u}; details operations[{r['index']-1}]. MSS execution=UNSUPPORTED, implementation=NOT_IMPLEMENTED, verification=NOT_VERIFIED; planned test=NOT_RUN; {r['proposed_vertical_slice']}"]))+' |')
    lines += ['', '## Реестр public .aiui.json', '',
      f"Все **{len(scenarios)} пути** из полного Git tree: 43 v1 script и 1 suite wrapper; 13 profile samples явно названы `sample-*-not-run`. Одинаковое содержимое в нескольких profiles сохраняется как отдельные пути. Эти sample-файлы не доказывают заполненную acceptance suite.", '',
      '| ID | Файл / имя | Kind / flags | Операции | SHA-256 |','|---|---|---|---|---|']
    for s in scenarios:
        flags=s['document_kind']+('; SAMPLE_NOT_RUN' if s['explicit_not_run_sample'] else '')+('; запрещённый environment profile' if s['prohibited_environment_source_profile'] else '')
        lines.append('| '+' | '.join(map(escaped,[s['id'],f"[{s['path']}]({s['source_url']}) — {s['name']}",flags,', '.join(s['operations']) or 'suite references: '+str(s['suite_members']),s['sha256']]))+' |')
    lines += ['', '## Границы полноты', '',
      f"Git tree не усечён: {meta['inventory_scope']['repository_entries']} entries / {meta['inventory_scope']['repository_files']} files. Извлечены все 91 Rust и 8 Node-source files; найдены {sum(t['kind']=='rust_test_declaration' for t in tests)} Rust и {sum(t['kind']=='node_test_declaration' for t in tests)} Node test declarations. Runtime runner binaries, shell/CI drivers и generated/inline cases не выдаются за полностью исполненный baseline. Parser issues: {len(issues)}; подробности в test-inventory.json.", '',
      'План MSS должен сохранить ВСЕ исходные операции и отрицательные/teardown сценарии. Container/WSL/interactive-desktop profiles не запускаются под ограничениями MSS и не удаляются из Toolkit. Для них требуются разрешённый эквивалент и отдельное доказательство контракта либо явный BLOCKED/NOT_VERIFIED.', '',
      '## Версии и будущие вертикальные срезы', '',
      'Toolkit main — 0b01942f1a7d1c276f130c9db03146cb96c1718a. Его Makepad dependency — local `.deps/makepad/widgets`, version 2.0.0; точный Git SHA из manifest не восстанавливается. MSS/official dev pin — 130be1d0318adcf69453d925342607466353152c. tools-2 main — b521a6c475348fb73494abdbe6adaf3c2c43320d, target Makepad — 71c9ddcbb9c01dd208f99621fdd71024a5d35c65. Совместимость этих стеков NOT_VERIFIED; version 2.0.0 не заменяет SHA.', '',
      'V1: owned app/worker runtime и exact identities. V2: app-originated semantic IDs/read. V3: SetValue/input/focus с отдельными механизмами и readback. V4: Invoke и неизвестный outcome без повторной мутации. V5: selection. V6: addressed keyboard/pointer/spatial. V7: window lifecycle. V8: runtime/task/API/file/log observers. V9: native capture/visual checks. V10: неизменённый public runner, schema, evidence/redaction/cleanup composition. Порядок требует dependency/acceptance review; ни один срез не объявлен готовым.', '',
      'MSS сейчас имеет лишь logical registry/auth/refusal/frame-admission contracts. Их локальные проверки не реализуют ни одну Toolkit execution operation. Никаких source/PR/branch/upstream изменений этим аудитом не сделано.', '']
    (ROOT/'toolkit-operations-appendix.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')

if __name__=='__main__': main()

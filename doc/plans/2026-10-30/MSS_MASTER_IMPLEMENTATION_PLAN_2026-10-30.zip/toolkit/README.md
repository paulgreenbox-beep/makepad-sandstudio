# Toolkit parity inventory для мастер-плана MSS

Это план и source-only audit, не реализация. Никакие Toolkit/MSS тесты, GUI-приложения, контейнеры, VM/WSL или model/API canaries не запускались. Изменены только новые артефакты в назначенной папке; upstream/project/branch/PR не изменялись.

Начните с [полного приложения операций](toolkit-operations-appendix.md). Machine-readable authority — [toolkit-parity.json](toolkit-parity.json): **112 строк, по одной на каждую операцию исходного operations.json**, с точными required/catalog flags, generic schema, capabilities, ограничениями метода, существующими source/test/scenario ссылками, недостающими MSS tests и явными предлагаемыми независимыми postconditions. Ни один execution backend MSS не объявлен готовым.

Каждая операция имеет будущий acceptance ID **TK-OP-001..TK-OP-112**, привязанный к gate **A13**; CONTRACT/EFFECT/FAILURE/ISOLATION subchecks являются планом, все NOT_RUN. Отдельная `semantic_effect_classification` описывает source-inferred/planned target/control/artifact effects, не изменяя исходный catalog mutation flag. Нормативные purity/method guarantees NOT_VERIFIED. `source_error_literals_candidates` очищен до error-constructor/code-field literals, но остаётся только навигацией с `operation_error_contract_validated=false`, не подтверждённым per-op error enum. Failure taxonomy в приложении явно PLANNED.

В `mss_equivalent` используются отдельные значения: `execution_status=UNSUPPORTED`, `implementation_status=NOT_IMPLEMENTED`, `verification_status=NOT_VERIFIED`. Статус будущих проверок хранится отдельно как `planned_test_status=NOT_RUN`; составных статусов и PASS для плана нет.

## Provenance и файлы

- Toolkit main повторно получен через GitHub: `0b01942f1a7d1c276f130c9db03146cb96c1718a`; tree `f16ddf13c2e59387aa32645cc6d0a76288f4eb54`, `truncated=false`.
- [operations.raw.json](operations.raw.json) — точные UTF-8 bytes каталога; SHA-256 `ffaaba15ddc2ee57c7eaf001383ee2bd285d324d640a49eed390eb4fcf339470`.
- [schema.raw.json](schema.raw.json) — исходная .aiui.json schema. Она допускает additional operation properties и **не задаёт полный JSON type каждого operation argument**. Это не заполнено догадками: formal-schema gaps помечены явно, required имена сохранены точно, owning Rust validators даны source links.
- [scenario-registry.json](scenario-registry.json) — все **44** checked-in `.aiui.json` пути: **43 v1 scripts и 1 suite wrapper**. У каждого source SHA, Git blob SHA, SHA-256 UTF-8 bytes, имя, JSON-pointer operation uses и ссылка. **13** profile files прямо названы `sample-*-not-run`; это samples, не доказанная полная acceptance suite.
- [test-inventory.json](test-inventory.json) — просмотр всех **91 Rust + 8 Node source files**, lexical inventory **210 Rust / 116 Node test declarations**, их source/file/line/operation candidates. Выполнение/cfg expansion/dynamic parameter expansion не производились. Отдельно перечислены shell/CI drivers и runner entrypoints; наличие теста не означает PASS.
- [repository-tree.json](repository-tree.json) / [source-inventory.json](source-inventory.json) — полный pinned tree **355 entries / 270 files**, fetch scope и hashes. Все 161 прочитанный текст сверены с исходным Git blob SHA-1, не только с новым SHA-256.
- [source-bundle.json](source-bundle.json) — локальные pinned source texts для воспроизводимого статического извлечения: все Rust/Node files, все `.aiui.json`, schema/catalog, выбранные fixture/suite/policy JSON, root manifest и reliability contract. Это не executable checkout и не Makepad SDK copy.
- [version-baselines.json](version-baselines.json), [audit-summary.json](audit-summary.json), [artifact-validation.json](artifact-validation.json) — точные базовые версии, итоги и проверка артефактов.

## Значимые ограничения/различия

1. `mutation`, `idempotency` и `physical_input` независимы. Отсутствующее поле — NOT_VERIFIED, не false. Каталог отдельно помечает nonphysical `set_value` и physical `input`/`click`; MSS не вправе молча заменять эти механизмы.
2. В фактическом Toolkit `reliability.rs` literal routes `input | set_value` ведут в `verified_input`, который вызывает host `input`; при этом catalog physical flags различаются. Это source-level связь, **не доказательство паритета фактического execution method**. Понадобится явный метод/readback/health/evidence oracle; нельзя перенести alias как разрешение ослабить контракт.
3. Toolkit manifest содержит Makepad path `.deps/makepad/widgets`, version `2.0.0`, без Git SHA. Exact Makepad revision Toolkit NOT_VERIFIED. Official Makepad dev/MSS pin подтверждён как `130be1d0318adcf69453d925342607466353152c`. tools-2 main подтверждён как `b521a6c475348fb73494abdbe6adaf3c2c43320d`; его Makepad target `71c9ddcbb9c01dd208f99621fdd71024a5d35c65` отличается. Совместимость не объявлена.
4. Реальные Script/schema/runner/API/reliability/observation/spatial/evidence, Scheduler и Windows UIA source прочитаны; raw README не использован как замена механизму. Evidence implementation расположен в `crates/toolkit-windows-automation/src/evidence.rs`; reliability bundle exporter/validator и runner artifact refs — отдельные пути.
5. Exact quoted operation mentions в unit/test/runner source — навигация, не доказательство полного assertion coverage. «Нет прямой ссылки» означает gap статического индекса, а не доказанное отсутствие generic/native test. Inline/generated scripts и shell/native runner compositions шире 44 checked-in paths; полный исполненный baseline этим аудитом не заявлен.
6. Container/WSL/physical-desktop source scenarios сохранены как требования, но запрещённые среды не запускаются. Path-based environment flags — только положительные подсказки; отсутствие такого флага не авторизует исполнение. Требуется разрешённый equivalent + parity proof либо BLOCKED/NOT_VERIFIED.
7. Все per-op postconditions и missing MSS tests — **план**. Source-level логические gates/44 ранее сообщённых MSS unit/integration checks не реализуют ни одну из 112 native Toolkit execution операций. PR11 Windows failure/format evidence не подменяет или не отменяет отдельный baseline.

## Воспроизводимость только артефактов

`extract_audit.py` использует только Python standard library и локальный source bundle. `validate_audit.py` сверяет catalog exact rows/flags, hashes, полный набор `.aiui.json`, source/test ссылки и отсутствие ложных execution claims. Они не импортируют и не запускают upstream Rust/Node код.

Запускать разрешённым уже установленным Python: `python extract_audit.py`, затем `python validate_audit.py`. В этой среде WindowsApps alias оказался нерабочим; использован уже установленный bundled Python Codex без установки зависимостей. `artifact-validation.json: VALID` относится только к этим data artifacts и **не является PASS Toolkit, MSS, native/GUI или release**.

"""Validate only owned audit artifacts; does not import or execute Toolkit code."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def load(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
def digest(raw): return hashlib.sha256(raw).hexdigest()

def main():
    parity=load('toolkit-parity.json'); catalog=load('operations.raw.json')
    scenarios=load('scenario-registry.json'); tests=load('test-inventory.json')
    bundle=load('source-bundle.json'); tree=load('repository-tree.json')
    names=[x['name'] for x in catalog['operations']]
    assert len(names)==len(set(names))==112
    assert [x['name'] for x in parity['operations']]==names
    assert parity['operation_count']==112
    assert parity['catalog_sha256']==digest((ROOT/'operations.raw.json').read_bytes())
    assert parity['public_schema_sha256']==digest((ROOT/'schema.raw.json').read_bytes())
    assert tree['truncated'] is False
    bypath={x['path']:x for x in bundle['files']}
    exact_aiui={x['path'] for x in tree['tree'] if x['type']=='blob' and x['path'].endswith('.aiui.json')}
    assert exact_aiui=={x['path'] for x in scenarios['scenarios']}
    assert len(exact_aiui)==scenarios['count']==44
    all_source={x['path'] for x in tree['tree'] if x['type']=='blob' and x['path'].endswith(('.rs','.mjs'))}
    assert all_source <= set(bypath)
    assert len(all_source)==99
    for item in bundle['files']:
        raw=item['content'].encode('utf-8')
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==item['sha'], item['path']
    test_ids={x['id'] for x in tests['tests']}; fn_ids={x['id'] for x in tests['function_candidates']}
    scenario_ids={x['id'] for x in scenarios['scenarios']}
    assert not tests['parse_issues']
    for index,(expected,row) in enumerate(zip(catalog['operations'],parity['operations'])):
        assert row['catalog_record_exact']==expected
        assert row['argument_schema']['catalog_required_exact']==expected['required']
        for key in ('mutation','idempotency','physical_input','capability','scheduler_classification'):
            field=row[key]
            assert field['value']==expected.get(key)
            assert field['status']==('DECLARED' if key in expected else 'NOT_VERIFIED')
        assert row['actual_physical_method']['status']=='NOT_VERIFIED'
        assert row['mss_equivalent']['execution_status']=='UNSUPPORTED'
        assert row['mss_equivalent']['implementation_status']=='NOT_IMPLEMENTED'
        assert row['mss_equivalent']['verification_status']=='NOT_VERIFIED'
        assert 'acceptance_status' not in row['mss_equivalent']
        assert row['planned_test_id']==f'TK-OP-{index+1:03d}' and row['planned_acceptance_gate']=='A13'
        assert row['planned_test_status']=='NOT_RUN'
        assert row['semantic_effect_classification']['normative_method_guarantee']=='NOT_VERIFIED'
        assert row['source_error_literals_candidates']['status']=='NOT_VERIFIED'
        assert row['source_error_literals_candidates']['operation_error_contract_validated'] is False
        assert not ({'PASS','FAIL','SKIPPED','SHIFT','CTRL'} & set(row['source_error_literals_candidates']['values']))
        p=row['planned_independent_success_postcondition']
        assert p['is_plan'] and p['verification_status']=='NOT_RUN' and len(p['observation_ru'])>70
        mapping=row['baseline_test_mapping']
        assert set(mapping['test_declaration_ids']) <= test_ids
        assert set(mapping['source_function_candidate_ids']) <= fn_ids
        assert {x['scenario_id'] for x in mapping['scenario_occurrences']} <= scenario_ids
        assert len(mapping['missing_MSS_tests'])>=4
    for s in scenarios['scenarios']:
        raw=bypath[s['path']]['content'].encode('utf-8')
        assert digest(raw)==s['sha256']
        assert s['source_sha']==parity['source_sha'] and s['execution_status']=='NOT_RUN'
    appendix=(ROOT/'toolkit-operations-appendix.md').read_text(encoding='utf-8')
    assert sum(line.startswith('| '+str(i)+'. [') for i in range(1,113) for line in appendix.splitlines())==112
    result={'schema':'mss-toolkit-audit-artifact-validation-v1','result':'VALID',
      'meaning':'Only local artifact completeness/provenance/reference consistency; not Toolkit/MSS tests or runtime acceptance',
      'source_sha':parity['source_sha'],'operations':112,'scenario_paths':44,'all_rs_mjs_files':99,
      'source_text_git_blobs_verified':len(bundle['files']),'rust_test_declarations':sum(t['kind']=='rust_test_declaration' for t in tests['tests']),
      'node_test_declarations':sum(t['kind']=='node_test_declaration' for t in tests['tests']),
      'catalog_sha256':parity['catalog_sha256']}
    (ROOT/'artifact-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()

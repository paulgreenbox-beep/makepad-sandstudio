# Упорядоченный PR backlog

Все пакеты — предложения. PR/branches не создавались; существующие ветки не менялись. Имена A/B — planning IDs, не новые GOAL IDs. Приоритет/зависимости/merge gates обязательны. Оценки S/M/L/XL условны, не сроки.

## A00 — Доработать существующий PR #11: реальные Unicode fixtures и rustfmt

| Поле | Значение |
|---|---|
| Goal | Устранить наблюдаемый FAIL, не менять intent/filter/ожидаемый InvalidInput. |
| Base | Существующая #11 поверх #10 |
| Depends On | — |
| Files | MSS_Remote/src/lib.rs |
| Required Code | Заменить только double-escaped NBSP/em-space на настоящие Rust Unicode escapes; rustfmt; сохранить имя и все asserts. Дополнить Focus/Text только в отдельном узком test-only diff. |
| Invariants | INV-CMD-01 |
| Tests | T-009 |
| Acceptance | Named regression, Remote6 и все45 workspace tests PASS/0ignored; fmt/check/Clippy PASS на новом SHA. |
| Risks | Случайное ослабление assert или silent trimming вместо исправления fixture. |
| Size | S — Один узкий diff/контракт, без нового OS/GPU backend. |
| Merge Gate | Owner review исправленного точного SHA; до этого #11 остаётся FAIL/Draft. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A01 — Принять совместимую основу PR #10/#11 без переписывания #1–#4

| Поле | Значение |
|---|---|
| Goal | Сделать один проверенный base для runtime; сохранить историю и ограничения. |
| Base | main; объединяющий PR #10 |
| Depends On | A00 |
| Files | MSS_Core/**; MSS_API/**; MSS_Remote/**; MSS_Render/**; README.md; doc/** |
| Required Code | Предлагается owner-reviewed merge исправленного #11 в #10, обновление source-bound evidence/README, затем отдельный ручной merge #10 в main. Никакого rebase/force/squash исходных историй. |
| Invariants | INV-TEST-01; INV-CMD-01 |
| Tests | T-X02 |
| Acceptance | Все7 Cargo gates + diff,45 актуальных tests и native/Toolkit status boundaries; exact ancestor check каждого #1–#4 head. |
| Risks | Зелёные старые receipts не относятся автоматически к новому merge SHA. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Ручной owner merge; #1–#4 закрывать как superseded только после подтверждённого merge #10 и сохранения истории. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A02 — Audit/CI contracts и воспроизводимые manifests

| Поле | Значение |
|---|---|
| Goal | Закрепить текущий каталог/инвентарь/invariants, убрать structural drift и проектировать безопасные CI gates. |
| Base | main после A01; можно готовить stack над #10 |
| Depends On | A01 |
| Files | doc/**; verification/** (минимальные manifests/validator); MSS_Remote/mss_remote.sklt; MSS_Render/mss_render.sklt; .github/workflows/mss-verify.yml (disabled до B06) |
| Required Code | Перенести reviewed артефакты плана, добавить small static validator, недостающие direct API dependency declarations без смены object_id. Workflow только проект/disabled; отсутствие qualified physical boundary запрещает PR code execution. |
| Invariants | INV-ID-01; INV-ID-03; INV-ID-04; INV-AUTH-02; INV-AUTH-04; INV-CMD-03; INV-CANCEL-01; INV-RENDER-01; INV-RENDER-05; INV-RENDER-07; INV-TEST-01; INV-STRUCT-01; INV-PARITY-01; INV-PLATFORM-01 |
| Tests | T-001; T-003; T-004; T-006; T-008; T-011; T-015; T-024; T-028; T-030; T-035; T-051; T-X01 |
| Acceptance | Exact catalog112, complete test/source inventories, acyclic PR dependencies, all invariant→test/PR links, preserved IDs. |
| Risks | CI на broad physical runner до qualification опасен; GitHub-hosted VM запрещены. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Review документов/validator; activation CI отдельно только после B06. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A03 — Issue #6: source-based Windows rendering qualification spike

| Поле | Значение |
|---|---|
| Goal | Принять доказанное A/B rendering решение до большого runtime; исправить прежнее неполное описание Windows hosted. |
| Base | main после A02 |
| Depends On | A02 |
| Files | doc/windows-feasibility.md; MSS_Core/tests/windows_feasibility.rs; MSS_SDK/tests/fixtures/native_frame_app/** |
| Required Code | Только доверенный fixture/harness: app-owned RenderBGRAu8 readback — предпочтительный кандидат; Windows hosted D3D/WS — сравнительный. Сначала controller+1app, затем расширение; нет real models и нет agent-generated code. Нужен approved noninteractive runtime profile. Начальный harness автономен только в узком fixed-fixture смысле: собственные retained process handles, Job и bootstrap endpoint, не ещё не существующая production ProcessOwner/auth system. A04/A05 затем переиспользуют проверенные механизмы без дублирования. Только read/capture/self-driven render nonce; внешние mutations до A06 запрещены. Fixture executable — standalone Cargo package с собственными [workspace], lock и exact Makepad pin; его metadata/check/test идут отдельно через --manifest-path, корневые7 members его не покрывают. |
| Invariants | INV-RENDER-08; INV-PLATFORM-01; INV-RENDER-02; INV-PROC-05 |
| Tests | T-031; T-052; T-X12 |
| Acceptance | Физический GPU: реальные nonce pixels/read-state, process/channel proof и bounded cleanup; иначе воспроизводимый NO-GO/NOT_RUN с причиной. Ни hosted WS, ни numeric surface id не считать auth. Обязательный positive B case T-X12; A/shared-surface tests условны выбору A. A NO-GO/NOT_RUN не выдаётся за PASS и не блокирует независимо доказанный B path. |
| Risks | SDK entry/readback недоступен; private-desktop GPU не работает; ignored AcquireSync/default SD создают отдельные NO-GO. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Source+recipe/harness review допустим отдельно; выбор backend только по actual Windows/GPU evidence, не Cargo. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A04 — Native Process Owner и session lifecycle

| Поле | Значение |
|---|---|
| Goal | Связать существующий registry с собственными app/test process leases и точной identity. |
| Base | main после feasibility GO; design может идти после A02 |
| Depends On | A03 |
| Files | MSS_Core/src/windows/**; MSS_Core/src/lib.rs; MSS_Core/Cargo.toml; MSS_Core/tests/**; doc/process-ownership.md |
| Required Code | Минимальные RuntimeSessionKey/epoch, ProcessLease, generation rebind, explicit argv/image pin, suspended launch+Job before resume, allowed handles, deadlines и cleanup-pending/quarantine. Windows dependency добавлять только после exact pin/license/features review; broker Cargo не сливать в root workspace. Epoch выпускает доверенный host через OS CSPRNG; PID/время/числовой counter не считаются credential. При rebind generation увеличивается проверяемо без wrap; restart создаёт новый authority domain и отклоняет прежние wire keys. |
| Invariants | INV-ID-02; INV-PROC-01; INV-PROC-02; INV-PROC-03; INV-PROC-05 |
| Tests | T-002; T-017; T-018; T-021; T-X11 |
| Acceptance | PID/birth/image/handle negatives, close A preserves B, controlled crashes/descendants, logical tests preserved. T-X11 проверяет именно runtime-profile inherited-handle denial отдельно от hardened broker; proof B04 сюда не переносится. |
| Risks | Same-user desktop/Job не sandbox; новое GUI-capable runtime profile не равно hardened CheckBroker profile. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Own-process evidence и независимый security review профиля; no foreign attach/kill. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A05 — Минимальный SDK producer и authenticated API/channel

| Поле | Значение |
|---|---|
| Goal | Аутентифицировать app/client, читать state/capabilities и frames без внешнего AgentId bypass. |
| Base | main после A04 |
| Depends On | A04 |
| Files | MSS_SDK/src/**; MSS_API/src/**; MSS_Remote/src/**; MSS_Core/src/windows/**; MSS_SDK/tests/** |
| Required Code | Opt-in fixture bridge на app thread; dedicated named pipe с explicit ACL, launch capability/peer birth binding; внешний principal -> trusted RequestContext. Bootstrap через allowlisted inherited handle/OS-protected channel, не env/token в логах. Пока только handshake/read/capture; mutation gate закрыт до A06. |
| Invariants | INV-AUTH-01; INV-AUTH-03; INV-CMD-02 |
| Tests | T-005; T-007; T-010 |
| Acceptance | Fake caller/app/WidgetId/stale generation/capability refused; read-only context не получает Input; no public unauth Remote HTTP bypass. |
| Risks | Публичных Makepad hooks может не хватить; gateway перед открытым HTTP не устраняет bypass. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Actual protected channel denial и минимальный source-reviewed app entry; SDK extensions не копируют Makepad. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A06 — Replay ledger и outcome/cancellation classification

| Поле | Значение |
|---|---|
| Goal | Перед первым side effect реализовать reserved/dispatched/observed/unknown и ровно один dispatch. |
| Base | main после A05 |
| Depends On | A05 |
| Files | MSS_Remote/src/ledger.rs; MSS_Remote/src/lib.rs; MSS_API/src/**; MSS_Core/src/**; MSS_Remote/tests/**; MSS_SDK/tests/fixtures/native_frame_app/** |
| Required Code | Bounded per-session ledger, atomic reserve, request identity/sequence, completed/unknown fences, refusal before effects, cancel phase и independent readback hooks. Старый RemoteGate остаётся fail-closed без injected executor. Для actual lost-reply test добавить ровно один opt-in trusted fixture action/counter и independent observer в SDK fixture: dispatch возможен только после atomic reserve; широкого mutation executor здесь нет. |
| Invariants | INV-CMD-04; INV-CMD-05; INV-CANCEL-02 |
| Tests | T-012; T-013; T-016 |
| Acceptance | Race/duplicate/out-of-order/MAX, lost reply after mutation, worker loss/cancel phases; no auto retry. |
| Risks | Ledger eviction/persistence/restart не должны разрешать повтор старой unknown mutation. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Race/fault evidence + boundedness review; mutation запрещена при недоступном ledger. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A07 — Trusted Frame Producer и bounded Render Stream

| Поле | Значение |
|---|---|
| Goal | Подключить реальные renderer-owned pixels с provenance/freshness/reset и backpressure. |
| Base | main после A03/A05 |
| Depends On | A03; A05 |
| Files | MSS_Render/src/**; MSS_SDK/src/**; MSS_API/src/**; MSS_Render/tests/** |
| Required Code | Producer handshake, process/render epoch/capture timestamps/stride/content SHA256, frame tickets/lease retirement и latest-only bounded queue. Выбранный readback adapter; hostile decode изолировать/budget, не объявлять pixel cap RAM containment. Shared surfaces только если A03 доказывает security+sync. |
| Invariants | INV-RENDER-02; INV-RENDER-03; INV-RENDER-04; INV-RENDER-06 |
| Tests | T-025; T-026; T-027; T-029 |
| Acceptance | Actual rendered nonce frames, swapped producer/surface, delayed/reset, malformed bytes, decoder/flood budgets, no cross-cache. |
| Risks | PNG profile может отвергать encoder metadata; decoder working-set cap требует enforcement, не одной проверки output length. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Actual GPU/window profile evidence; static fixture не acceptance producer. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A08 — Первый полный Windows two-session PoC

| Поле | Значение |
|---|---|
| Goal | Два независимых app процесса и два agent clients с реальным адресным state change/кадрами/cleanup. |
| Base | main после минимальных native/auth/ledger/render slices |
| Depends On | A04; A06; A07 |
| Files | MSS_Core/tests/two_session_windows.rs; MSS_SDK/tests/fixtures/**; MSS_API/tests/**; doc/evidence/**; MSS_Core/tests/fixtures/session_test_worker/**; MSS_API/tests/fixtures/agent_client/** |
| Required Code | Составить уже готовые минимальные adapters; два deterministic client процесса с отдельными credentials (не платные модели), разные app nonce/counters, test worker processes отдельно. Никакого нового общего orchestrator framework. Включить минимальные фиксированные worker helpers: отдельный процесс per-session test и отдельный agent-client, управляемые тем же own-process механизмом. Это только PoC roles; production Scheduler/leases/Runner остаются A10. Controller+2apps+2clients+2test-workers — семь собственных процессов, не семь полных framework-компонентов. |
| Invariants | INV-PROC-04; INV-INPUT-01; INV-RENDER-02; INV-CANCEL-02; INV-CMD-04; INV-PROC-05 |
| Tests | T-020; T-054; T-X03; T-X04 |
| Acceptance | Real A/B actions+independent health/readback+frames, чужой доступ denied, close/crash A не повреждает B; no global input; retained resource cleanup. |
| Risks | Все app/agent/test identities должны быть настоящими процессами; controller threads не замена. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | GO только по physical Windows/GPU evidence для exact profile. При отсутствии prerequisites NOT_RUN/BLOCKED, не синтетический substitute. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A09 — Подключить существующий MSS Desktop viewer

| Поле | Значение |
|---|---|
| Goal | Заменить illustrative rows/placeholder настоящим authorized session/frame state. |
| Base | main после A08 |
| Depends On | A08 |
| Files | MSS_Desktop/src/main.rs; MSS_Desktop/src/**; MSS_API/src/**; MSS_Render/src/**; MSS_Desktop/tests/** |
| Required Code | Использовать текущую Makepad оболочку; list/session status/latest frame/stale/no-frame/errors; input только через API. Lease release при tab switch/close, no direct process/global input. |
| Invariants | INV-DESKTOP-01 |
| Tests | T-047 |
| Acceptance | Owned viewer displays actual selected app nonce; delayed frames/close/reset cannot cross views; API authorization remains. |
| Risks | UI screenshot оболочки не подтверждает app runtime; потребление GPU frames и освобождение textures отдельно проверяются. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Separate owned GUI/render acceptance + unchanged root gates; no user-desktop test dependency. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A10 — Test workers, Scheduler adaptation, runtime health и evidence

| Поле | Значение |
|---|---|
| Goal | Добавить независимые workers/leases и достоверные результаты до полного Script Runner. |
| Base | main после A08 |
| Depends On | A08 |
| Files | MSS_Core/src/**; MSS_API/src/**; MSS_SDK/src/**; MSS_Remote/src/**; doc/evidence-contract.md; tests/worker-fixtures/** |
| Required Code | Переиспользовать публичные Toolkit Scheduler/verification contracts через adapter, не второй scheduler framework. Worker per job, scoped roots/queues, health observation, redacted immutable artifact manifests, source/process-bound records, known/unknown cleanup. |
| Invariants | INV-EVIDENCE-01; INV-EVIDENCE-03; INV-SCHED-01; INV-EVIDENCE-02 |
| Tests | T-032; T-034; T-048; T-X08 |
| Acceptance | Worker loss/fairness/queue bounds/lease drain, logs/API/files/milestones/errors, fake artifacts, secret canaries; source-bound evidence complete. |
| Risks | Toolkit default desktop capacity1 нельзя без proof снять новой label; service/evidence signing authority не должна жить в worker. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Independent native worker/failure evidence; receipt authority для untrusted execution зависит от B05. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A11 — Thin MCP, расширения SDK и MSS Skills

| Поле | Значение |
|---|---|
| Goal | Подключить стандартные клиенты к одному API и опубликовать только реальные capabilities. |
| Base | main после A05/A08; worker features после A10 |
| Depends On | A05; A08 |
| Files | MSS_MCP/src/**; MSS_MCP/Cargo.toml; MSS_SDK/src/**; MSS_Skills/**; MSS_API/src/** |
| Required Code | Пин официальной MCP protocol/SDK версии после dependency review; thin tools без provider business logic. Два protocol clients, lifecycle/cancel, capability/error serialization; versioned agent instructions. Реальные Codex/Claude/Cline/OpenCode canaries отдельно и только с разрешением расходов. |
| Invariants | INV-MCP-01; INV-AUTH-01 |
| Tests | T-049; T-X09 |
| Acceptance | MCP conformance, foreign credentials/unknown tools, same API outcomes; provider-specific test clients без API затрат сначала. |
| Risks | Нельзя передавать caller agent_id как identity; SDK id/tree не автоматически semantic parity. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Model-free protocol acceptance; real-client evidence отдельно, unsupported capabilities остаются явными. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A12 — Toolkit Script Runner adapter и semantic operation slices

| Поле | Значение |
|---|---|
| Goal | Сохранить .aiui.json/schema/runner/reliability/evidence и реализовывать op groups через app-owned SDK. |
| Base | main после A10/A11 |
| Depends On | A10; A11 |
| Files | MSS_API/src/toolkit/**; MSS_Remote/src/**; MSS_SDK/src/**; MSS_Core/src/**; tests/toolkit/**; doc/toolkit-coverage.json |
| Required Code | Публичный Transport/AiUiClient adapter, schema unchanged, exact failure/report semantics, semantic IDs/capabilities и independent postconditions. Разбивать по read/value/invoke/selection/spatial/window/async/file/visual groups; не заменять input/click set_value. |
| Invariants | INV-CMD-06 |
| Tests | T-014 |
| Acceptance | На каждый operation group unchanged positive+negative+teardown corpus; missing op Unsupported, не PASS. |
| Risks | Некоторые Toolkit операции требуют запрещённого global input; нужна доказанная разрешённая equivalence, не переименование метода. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Per-operation/source/profile evidence и совместимость SDK tuple; все112 остаются в matrix. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## A13 — Полная Toolkit и native/product acceptance

| Поле | Значение |
|---|---|
| Goal | Подтвердить целевой полный паритет без удаления scenario/теста. |
| Base | main после all runtime slices и qualified CI |
| Depends On | A09; A12; B06 |
| Files | doc/acceptance/**; tests/toolkit/**; verification/** |
| Required Code | Acceptance campaign, разделённая на небольшие operation/profile PRs; никакой имитации missing backend. Матрица112+весь неизменный корпус+multi-agent fault/security cleanup. |
| Invariants | INV-PARITY-01; INV-CMD-06 |
| Tests | T-050; T-X07 |
| Acceptance | Полные attributed reports, all required positive/negative/teardown + native GUI/GPU/concurrency tests; независимый verifier. |
| Risks | Если эквивалент физической/OS операции невозможен при текущих запретах, full parity остаётся BLOCKED/NOT_VERIFIED и scope нельзя незаметно сузить. |
| Size | XL — Acceptance campaign/epic, не разрешение на один гигантский PR; разбить по operation groups/profile, сохраняя общий gate. |
| Merge Gate | Owner/product release acceptance только после всех mandatory gates; не по одной release compilation. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B00 — Согласовать существующий GOAL Registry PR #5 с main

| Поле | Значение |
|---|---|
| Goal | Сохранить формат/ID GOAL и строгие main AGENTS; убрать настоящий AGENTS conflict. |
| Base | Существующий #5 против актуального main |
| Depends On | — |
| Files | AGENTS.md; goals/**; doc/agent-goal-workflow.md |
| Required Code | Ручная reconciliation: объединить оба набора правил; обновить historical source references осознанно после A01, не сбросить статусы/историю. MAIN Cargo.lock/format не удалять. Issue6/8 пока не имеют approved GOAL+scope — не создавать автоматически. |
| Invariants | INV-STRUCT-01; INV-GITHUB-02 |
| Tests | T-044; T-051 |
| Acceptance | Schema/manifest/catalog/dependency-cycle/stale-source checks; independent VERIFIED procedure specified. |
| Risks | Старый branch tip diff показывает отсутствие main lock, но это не разрешение его удалить. |
| Size | S — Один узкий diff/контракт, без нового OS/GPU backend. |
| Merge Gate | Owner registry review; no self-VERIFIED и no automatic issue execution. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B01 — Согласовать выключенный dispatcher PR #7 и check catalog

| Поле | Значение |
|---|---|
| Goal | Сохранить80 model-free tests, устранить command/receipt schema integration gaps без enablement. |
| Base | Существующий #7 поверх принятого B00 |
| Depends On | B00 |
| Files | scripts/codex-issue/**; .github/codex-issue-policy.json; .github/workflows/codex-issue.yml; goals/checks/catalog.json; goals/**; doc/** |
| Required Code | Узкие approved check IDs/argv для Node и standalone broker; current new Rust gates с --locked. Различить manual history и automatic sha256 receipts, preserve pending scope approvals. Сохранить enabled=false/isolation.approved=false/scopes empty до qualification. |
| Invariants | INV-GITHUB-01; INV-GITHUB-02; INV-CATALOG-01 |
| Tests | T-043; T-044; T-045 |
| Acceptance | 80 originals +catalog-policy exact argv tests, actor/body/claim uncertainty, fake receipt/transition and no-auto-merge; workflow syntax and permissions. |
| Risks | Широкое добавление node/shell в allowed_commands недопустимо; agent-ready и codex-ready не взаимозаменяемы. |
| Size | M — Два-три владельца модулей/связанный контракт; scope ограничен и есть fixtures. |
| Merge Gate | Owner review disabled workflow; tests не дают права runtime activation. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B02 — Native Broker: authenticated execution authority

| Поле | Значение |
|---|---|
| Goal | Первый production-compatible vertical contract, по-прежнему fail-closed до всех gates. |
| Base | Существующий #9 поверх B01 |
| Depends On | B01 |
| Files | native-check-broker/src/protocol.rs; native-check-broker/src/authority.rs; native-check-broker/src/main.rs; native-check-broker/tests/** |
| Required Code | Реальная OS-authenticated caller identity, separate controller/worker principal, immutable request/check/GOAL/source binding. Trusted fixture API не превращать в authorizer; production branch без qualified components продолжает BLOCKED. |
| Invariants | INV-BROKER-01; INV-BROKER-02 |
| Tests | T-040; T-041 |
| Acceptance | Fake caller/peer/token, request replay, unapproved GOAL/source, production refusal unchanged. |
| Risks | Требуется independently provisioned service/logon identity и защищённые ACL; полей JSON недостаточно. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Independent authority review+negative OS evidence, production still disabled до B07. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B03 — Protected source materializer и exact toolchain/executable identity

| Поле | Значение |
|---|---|
| Goal | Дать broker immutable source/dependency/toolchain bytes без writable agent authority. |
| Base | PR9 follow-up после B02 |
| Depends On | B02 |
| Files | native-check-broker/src/source.rs; native-check-broker/src/native.rs; native-check-broker/tests/**; doc/protected-materialization.md |
| Required Code | Защищённый exact tree importer без arbitrary git hooks; separate readonly source vs writable target/evidence, path/handle no-follow validation, executable file pin/argv/env, toolchain/cache policy; reject malicious configs вне qualified worker. Здесь только static/import/file-pin/harmless owned executable checks; hostile build.rs/wrapper/DLL execution запрещено до independently admitted B04 profile. Полный negative confinement T-X13 выполняется позже в B06. |
| Invariants | INV-FS-01; INV-EXEC-01; INV-SOURCE-01 |
| Tests | T-036; T-038; T-039 |
| Acceptance | Reparse/case/ADS/TOCTOU/materialization mutation/image swap/Cargo wrapper negatives. |
| Risks | Cargo/build.rs исполняют attacker code; наличие --locked не sandbox и не замена worker boundary. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Verified immutable tree+filesystem/exe authority proofs; no host-global dependency installs этим PR. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B04 — Native containment, WFP, cross-session ACL и USER32/crash qualification

| Поле | Значение |
|---|---|
| Goal | Закрыть реальные OS gaps существующих native fixtures; не снимать current mandatory gate. |
| Base | PR9 follow-up после B02/B03 |
| Depends On | B02; B03 |
| Files | native-check-broker/src/native.rs; native-check-broker/tests/native_windows.rs; native-check-broker/src/bin/**; native-check-broker/evidence/** |
| Required Code | Actual token/Job/handles/resource enforcement, independently provisioned ACL identities, network WFP enforcement и replay stress. USER32 observation currentQueryUnavailable остаётся BLOCKED до проверенного решения. Не ослаблять Win32k и не использовать user desktop. |
| Invariants | INV-PROC-03; INV-PROC-06; INV-PROC-07; INV-NET-01; INV-BROKER-03; INV-FS-01; INV-PROC-05 |
| Tests | T-019; T-022; T-023; T-037; T-042; T-X10 |
| Acceptance | Все39 Rust declarations с feature/nonfeature scopes, existing10 native fixtures,2 prerequisites NOT_RUN до реального grant; stress child/output/memory/FS/network/cleanup. |
| Risks | WFP/identity provisioning физического host требует owner/security admin; restricted token/RC общий SID не proves full session isolation. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Independent physical-host evidence каждой обязательной границы; mocks/config readback недостаточны. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B05 — Trusted receipts и безопасное collect/publish separation

| Поле | Значение |
|---|---|
| Goal | Не дать untrusted Codex/worker подменить PASS или поздние шаги того же job. |
| Base | B04 + protected caller/materializer |
| Depends On | B03; B04 |
| Files | native-check-broker/src/receipt.rs; scripts/codex-issue/run.mjs; .github/workflows/codex-issue.yml; native-check-broker/tests/**; doc/receipt-authority.md; native-check-broker/src/main.rs; native-check-broker/src/lib.rs |
| Required Code | Trusted receipt producer/signature or protected channel with actual verifier; provenance/nonce/source binding, immutable artifact store, redaction. Разделить untrusted model worker и trusted collect/publish jobs/identities; follow-up steps не полагаться на прежние host files после модели. Реализовать положительный wiring admission→protected materialization→native check→health/cleanup→immutable bytes→authenticated receipt. Полный actual model-free roundtrip T-X14 — в B06 после prerequisites, через тот же production admission без тестового обхода authority; dispatcher остаётся выключен. |
| Invariants | INV-EVIDENCE-02; INV-BROKER-01; INV-SOURCE-01 |
| Tests | T-033; T-X05 |
| Acceptance | Forged receipts/keys/path/logs, changed command/source, damaged bundle, poisoned collect/upload files; no secret in logs. |
| Risks | SHA256 integrity не proof signer; signing authority недоступна agent/worker. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Independent receipt security and artifact lineage review; no API spending. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B06 — Квалифицировать физические Windows runners и включить только безопасные CI checks

| Поле | Значение |
|---|---|
| Goal | Доказать рабочую CI boundary для reviewed sources и adversarial PR negatives до model dispatcher. |
| Base | main after reviewed B05; CI design A02 |
| Depends On | A02; B05 |
| Files | .github/workflows/mss-verify.yml; .github/workflows/codex-issue.yml; doc/windows-runner-qualification.md; verification/** |
| Required Code | Раздельные control/worker service identities, pinned protected tools/source authority, resource/egress policy, no interactive desktop. Саму регистрацию/Secrets/host provisioning делает владелец отдельно; current plan ничего не применяет. Missing control runner требует независимого operator-visible preflight: queued не receipt BLOCKED. |
| Invariants | INV-EVIDENCE-02; INV-EXEC-01; INV-CI-01; INV-RELEASE-01; INV-SOURCE-01; INV-BROKER-01; INV-BROKER-02; INV-EVIDENCE-01 |
| Tests | T-046; T-X06; T-X13; T-X14 |
| Acceptance | Wrong runner/identity/pins/secret/offlinecache, no runner queue and all core/broker/Node scopes; adverse PR code confined; no model. Перед любым paid canary обязательны T-X13 и T-X14: adversarial containment и положительный harmless end-to-end broker run с действительной authority, receipt и независимым verifier. Никаких bypass флагов, fake signers либо агентского выставления qualified=true. |
| Risks | Self-hosted label не доказательство физического/защищённого host; GitHub-hosted VM запрещены. |
| Size | L — Нативные API, fault cases или несколько связанных компонентов; размер зависит от платформенного GO. |
| Merge Gate | Independent runner qualification + owner-approved CI switch, dispatcher enabled remains false. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

## B07 — Контролируемый canary и production activation dispatcher

| Поле | Значение |
|---|---|
| Goal | Только после all mandatory proof и отдельного разрешения владельца на расход. |
| Base | main after B06, reviewed GOAL scopes and independent signoff |
| Depends On | B06 |
| Files | .github/codex-issue-policy.json; goals/**; doc/activation-receipt.md |
| Required Code | Не обычная autonomous code task: staged owner change enable flags/host pins/scopes, bounded single issue canary with budget, independently validated receipts/Draft PR and stop/rollback-disable procedure. Secrets/branch protection не меняет агент. |
| Invariants | INV-RELEASE-01 |
| Tests | T-053 |
| Acceptance | Readiness-negative model-free check при удалении каждого gate; затем отдельно разрешённый paid canary; exact result/source/evidence и no main/merge privileges. |
| Risks | Любой missing gate=>BLOCKED; canary успех не автоматически broad activation или full MSS runtime acceptance. |
| Size | S — Один узкий diff/контракт, без нового OS/GPU backend. |
| Merge Gate | Independent security reviewer + explicit owner approval; agent не назначает VERIFIED и не делает merge. |
| Regressions | Сохранить все исходные тесты, ошибки/статусы и exact source binding; не расширять scope без нового анализа. |

# MSS MASTER IMPLEMENTATION PLAN

Русский инженерный план. Срез: **2026-10-30 18:51:54 UTC**. Режим **PLAN FIRST / аудит исходников**. Комплект содержит документацию, данные и локальные анализаторы. Файлы проекта, ветки, PR, исходные репозитории, Secrets, настройки runner и режим dispatcher не менялись. Новые сборки, проектные тесты, приложения с GUI и пробные вызовы модели не запускались. Мониторинг остаётся PAUSED.

Повторная сверка GitHub: **2026-10-30 19:33:58 UTC**, изменения относительно снимка: **нет**. Подробности: [final-github-recheck.json](final-github-recheck.json).

## 1. Executive Summary

В main пока находится архитектурный каркас с иллюстративной оболочкой Makepad; логическая основа реализована в ещё не слитых PR. В PR #10 совместно проверены Core/API/Remote/Render: **44 теста Rust — PASS**. Процессы приложений, нативный ввод и захват кадров, MCP и исполнитель Toolkit ещё отсутствуют. PR #11 добавляет проверку адресов, однако на его точном SHA получены **44 PASS / 1 FAIL и fmt FAIL**: Unicode-символы в тестовых строках экранированы дважды. Источники: [свидетельства интеграции](evidence/pr10-integration.json), [результаты PR #11 на Windows](evidence/pr11-windows-summary.json), [место ошибки](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/192b81ac83cfa3945318804430af25b3795609ad/MSS_Remote/src/lib.rs#L352). Прежняя запись «PR11 NOT_RUN» уже не отражает текущий результат.

Имеются 80 тестов Dispatcher без вызовов модели и 37 активных именованных тестов Broker на Rust. При этом производственная точка входа **всегда BLOCKED**; два пропущенных нативных теста с невыполненными предпосылками остаются NOT_RUN, а обязательная проверка привязки USER32 — BLOCKED. [Исходник Broker](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/368e5c54bb3da8a65cad2db9f141041100eb4630/native-check-broker/src/main.rs) и [нативные свидетельства с привязкой к исходникам](evidence/pr9-crash-user32.json) не подтверждают полную безопасность нативного исполнения или приёмку Toolkit.

Кратчайший безопасный путь: исправить и проверить существующий PR #11 → принять PR #10 с сохранением истории → провести эксперимент с кадром от одного приложения на проверенных исходниках и хосте → добавить минимальные механизмы процессов, каналов, учёта команд и кадров → проверить **два настоящих процесса приложений**, два детерминированных процесса клиентов-агентов с раздельными учётными данными и независимые процессы проверки → затем подключить просмотр, MCP и полный Toolkit. Общая инфраструктура расширений и оформление оболочки не нужны на этом критическом пути.

Главная новая архитектурная находка: закреплённая версия Makepad уже содержит **Windows hosted D3D11** наряду с hosted-кодом для Linux. Однако WebSocket, build-ID, именованные поверхности, дескрипторы безопасности по умолчанию и игнорируемые результаты работы mutex не доказывают аутентификацию и восстановление MSS. Предпочтение первому варианту с принадлежащим приложению ReadBack и защищённым каналом pipe остаётся **условным** до фактического решения GO по A03. Если нет поддерживаемой публичной точки входа или результата GPU без зависимости от рабочего стола пользователя, требуется NO-GO. Скрытый обходной путь недопустим. [Полный аудит исходников и ссылки на Microsoft API](runtime/runtime-audit.md).

Комплект включает **112/112** операций, **54** инварианта с проверяемыми условиями нарушения, **68** будущих сквозных проверок, ещё 112 групп приёмки отдельных операций, **22** связанных зависимостями пакета PR и 10 подготовленных инженерных задач. Все предлагаемые проверки исполнения имеют статус NOT_RUN. Локальный валидатор артефактов проверяет полноту и связность плана; он не проверяет работающую среду MSS.

## 2. Repository and PR Snapshot

Главная ветка: **83ff50112fbbdc1cd2a43ccd2ac1650504394a67**. Все 9 указанных PR открыты как Draft и не слиты. GitHub сообщает о конфликте у PR #5; остальные допускают слияние относительно **своих баз**, которые могут отличаться от main. Это не означает одобрения PR или изменения их готовности. [Машиночитаемый снимок](repository-snapshot.json).

| PR | Название | HEAD SHA | Base / SHA в ответе PR | Состояние / конфликт |
|---|---|---|---|---|
| #1 | Implement and verify MSS_Core logical session registry | 6998cef53077eab021f129e583d4979e2e70e297 | main / 83ff50112fbbdc1cd2a43ccd2ac1650504394a67 | open; Draft=true; mergeable=true |
| #2 | MSS_API: exact session authorization and typed operation contracts | abcf43b08a13da5fbf70ba1b66ef16de512ebcb5 | codex/mss-core-session-registry / 75e39070f0ac12ac314bff5e627da56675c55f99 | open; Draft=true; mergeable=true |
| #3 | MSS_Remote: authorized command gate and explicit refusal | ad42653ac6e5b60c63262e48441a02607b0e5d83 | codex/mss-api-contract / abcf43b08a13da5fbf70ba1b66ef16de512ebcb5 | open; Draft=true; mergeable=true |
| #4 | MSS_Render: bounded per-session frame store | de2d32ee44cbab5882a5f5bf359db89e565cd26f | codex/mss-api-contract / abcf43b08a13da5fbf70ba1b66ef16de512ebcb5 | open; Draft=true; mergeable=true |
| #5 | Add GitHub agent goals, check catalog, and status workflow | 9c0e867f8844a6bc7949c7705db5c2cbbb65ef1c | main / b4556baae7b628e00322bb20bb9cc1d8221032fc | open; Draft=true; mergeable=false |
| #7 | Prepare disabled Codex Issue dispatcher for native Windows runners | d83520d931ab000574c5c02192b9f49da86a34ea | codex/mss-agent-goals / 9c0e867f8844a6bc7949c7705db5c2cbbb65ef1c | open; Draft=true; mergeable=true |
| #9 | Prove owned desktop crash cleanup; keep USER32 association blocked | 368e5c54bb3da8a65cad2db9f141041100eb4630 | codex/github-issue-dispatcher / d83520d931ab000574c5c02192b9f49da86a34ea | open; Draft=true; mergeable=true |
| #10 | Integrate and verify MSS Core, API, Remote and Render | 8863cc326b99f8d76b2bf66725d87540aab79f02 | main / 83ff50112fbbdc1cd2a43ccd2ac1650504394a67 | open; Draft=true; mergeable=true |
| #11 | MSS_Remote: reject ambiguous padded widget addresses | 192b81ac83cfa3945318804430af25b3795609ad | integration/mss-core-api-remote-render / 8863cc326b99f8d76b2bf66725d87540aab79f02 | open; Draft=true; mergeable=true |


Столбец «Base / SHA в ответе PR» точно передаёт метаданные GitHub и не обозначает текущий HEAD базовой ветки. Например, у PR #2 base.sha — 75e3907 при текущем HEAD базовой ветки 6998; у PR #5 base.sha — b455 при текущем main 83ff. Их фактические merge-base независимо прочитаны как 75e3907 и b455. Текущие вершины базовых веток учитываются отдельно в снимке.

Фактическая цепочка веток: PR #1 содержит текущий main; PR #2 основан на прежнем Core 75e3907; PR #3 и #4 — параллельные ветки поверх PR #2; PR #10 сохраняет историю всех 4 исходных веток; PR #11 основан на PR #10. Отдельная цепочка — #5 → #7 → #9. Единственное пересечение изменений main и PR #5 относительно merge-base — AGENTS.md. Наличие старой вершины ветки не даёт права удалить добавленный в main Cargo.lock. [Разбор истории и конфликта](infrastructure/infrastructure-audit.md).

Issues: **#6 open/agent-ready/unassigned** — исследование реализуемости; **#8 open/agent-blocked** — предпосылки производственного Broker. Автоматическое исполнение не запускается; метка готовности сама по себе не предоставляет полномочий. Тексты Issues сохранены в снимке и прочитаны как требования, а не как команды оболочки или разрешения. Последние комментарии владельца в PR #3 и #10 направляют к PR #11; новых рецензий и одобрений нет. [Issue #6](https://github.com/paulgreenbox-beep/makepad-sandstudio/issues/6), [Issue #8](https://github.com/paulgreenbox-beep/makepad-sandstudio/issues/8).

В GitHub Actions total_runs=0; у HEAD всех 9 PR число check-runs и status contexts равно 0. Состояние combined state pending при 0 contexts означает отсутствие свидетельств CI и не доказывает запуск или неуспешное завершение задания. [Запуски проверок](check-runs.json), [статусы коммитов](commit-statuses.json). Локальные результаты Cargo и Node сохранены отдельно.

Закреплённые исходные версии: Makepad dev = MSS **130be1d0318adcf69453d925342607466353152c**; Toolkit main **0b01942f1a7d1c276f130c9db03146cb96c1718a**; tools2 main **b521a6c475348fb73494abdbe6adaf3c2c43320d** с целевой версией Makepad 71c9ddcbb9c01dd208f99621fdd71024a5d35c65. Корневой проект Toolkit использует .deps/makepad/widgets, для которого SHA восстановить не удалось. [Манифест версий](toolkit/version-baselines.json), [указатель исходников](runtime/source-reference-manifest.json). Совместимость различных сочетаний версий не объявлена.

## 3. Complete Component Inventory

| Модуль | Текущий main | Существующий PR | Реализация | Проверка | Недостающий код | Зависимости | Риск | Приоритет |
|---|---|---|---|---|---|---|---|---|
| MSS_Core | Status NotImplemented | 1,10 | Логические RegistryId/AgentId/SessionId с областью действия; поколение, владелец, выбор и закрытие | Core: 12 тестов в #1, 16 в #10/#11; только логическая модель | Эпоха исполнения, ProcessLease, запуск, Job, идентичность, жизненный цикл и восстановление | std; только API потребляет полномочия Core | P0: внешняя идентичность и время жизни | P1 |
| MSS_API | Каркас статуса | 2,10 | Заимствованный реестр Core; авторизация до отказа по классу или имени; отмена до допуска | 6 модульных тестов PASS в #10/#11 | Внешняя идентичность, разрешения операций, настоящие исполнители, работоспособность, свидетельства и сетевой протокол | Core; без дублирования реестра | P0: подмена вызывающей стороны при прямом внешнем доступе | P1 |
| MSS_Remote | Каркас статуса | 3,10,11 | Типизированные Read/Focus/Text с проверкой формата и лимитов; всегда NotDispatched; проверка краевых пробелов в #11 | 5 PASS + 1 FAIL в #11; форматирование — FAIL | Аутентифицированный канал приложения, семантическая цель/WidgetId, защита от повторов, результат и чтение состояния | API/Core | P1: неуспешный тест; P0 до первого нативного изменения состояния | P1 |
| MSS_Render | Каркас статуса | 4,10 | Авторизованный кеш переданных PNG; точные ID, последовательности и освобождение ресурсов; ограниченный декодер и квоты | 9 модульных и 8 публичных композиционных тестов PASS в #10/#11; синтетические данные | Аутентификация источника, захват, время и эпоха рендерера, поток, обратное давление и реальный бюджет памяти | API/Core; закреплённый zune; Remote только для разработки | P0: нет доверенного источника; P2: ограничения декодера и профиля | P1 |
| MSS_SDK | Каркас статуса | Нет реализации | Только ImplementationStatus | 0 поведенческих тестов | Явно подключаемые канал приложения, разрешения, состояние, действия, работоспособность и источник кадров | Зависимостей Cargo пока нет; API запланирован в SKLT | P1: нет границы доверия приложения | P1 |
| MSS_MCP | Каркас статуса | Нет реализации | Только ImplementationStatus | 0 поведенческих тестов | Стандартные жизненный цикл MCP, авторизация и инструменты поверх API; совместимость клиентов | Зависимостей пока нет; API запланирован | P1: не допустить второго реестра и политики | P3 |
| MSS_Desktop | Иллюстративная оболочка Makepad | #10 наследует исходники main | Кнопки, подписи и заглушка отсутствующего кадра; связи с backend нет | Скомпилирован в #10; GUI NOT_RUN; 0 поведенческих тестов | Настоящие список сессий, кадры, статусы, ошибки, отмена и владение ресурсами через API | Точный Makepad 130be; API/Render запланированы | P2: статический просмотр может создать ложное впечатление приёмки | P2 |
| MSS_Skills | README + SKLT | Нет устанавливаемого пакета | Только инструкции; нет полномочий инструментов или учётных данных | Только чтение исходников | Версионируемые безопасные примеры разрешений, сессий, API и MCP | Запланированы API/MCP | P3: расхождение инструкций с реализацией | P3 |
| GOAL Registry | Отсутствует | #5; унаследован в #7/#9 | Схема, манифест, каталог и события MSS001…004; статусы и зависимости | Статические исходники; нужен новый валидатор; ссылки исторические | Разрешить конфликт AGENTS; утвердить GOAL и объём Issues 6/8; согласовать каталог | Только существующий формат; ID SKLT сохраняются | P1: устаревшие свидетельства, исходники и команды | P1 |
| Codex Dispatcher | Отсутствует | #7; унаследован в #9 | Авторизация события владельца, объём, резервирование задачи, ветка, свидетельства и Draft PR; политика отключена | 80 именованных тестов без модели — PASS; реальные Actions — NOT_RUN | Квалификация runner, broker и полномочий; недостающая команда проверки, формат свидетельств и отделение collect | GOAL 5 → Broker 9; секрет OPENAI не устанавливается планом | P0: неквалифицированное исполнение при включении | P1 |
| Native Check Broker | Отсутствует | #9 / Issue 8 | Строгий протокол; производственная точка входа всегда блокирует; нативные пробы отдельно | 39 именованных тестов Rust: 37 PASS / 2 NOT_RUN; только примитивы и стенды; USER32 заблокирован | Квалификация производственных вызывающей стороны, подготовки исходников, идентичностей, ACL, WFP, свидетельств и квот | Отдельный Cargo workspace; PR7/5; независимый физический хост | P0: производственные проверки не завершены | P0 |


Точные публичные интерфейсы, строки исходников и состояния по семи ревизиям приведены в [аудите среды исполнения](runtime/runtime-audit.md) и [манифесте исходников](runtime/source-reference-manifest.json). Прочитаны исходники каждого крейта, включая Cargo, README, SKLT и инструкции skills. Корневой workspace содержит 7 крейтов; MSS_Skills — документация, а не восьмой крейт Rust. Desktop main.rs содержит код нативного интерфейса, но ещё не показывает работающие дочерние приложения.

Владелец нативных процессов, планировщик исполнения и процессы агентов отсутствуют. API не создаёт второй реестр; RequestContext пока считается доверенным входом логической модели. В Remote нет механизма доставки команд и защиты от повторного исполнения. FrameStore принимает переданные извне байты после логической авторизации, не подтверждая их происхождение от рендерера. Перечисления статусов SDK/MCP — каркас; README Skills не предоставляет полномочий. GOAL, dispatcher и broker существуют только в своей цепочке веток. [Машиночитаемый перечень компонентов](component-inventory.json).

## 4. Architecture and Trust Boundaries

Предлагаемый путь данных: аутентифицированный внешний субъект → MCP/Desktop → единый MSS_API → идентичность и владение ресурсами в Core, исполнитель и журнал команд в Remote → явно подключённый SDK приложения в его собственном потоке событий → независимое наблюдение состояния, работоспособности и кадров → доставка кадров с лимитами и сохранением свидетельств в Render → область выбранного приложения в Desktop. Значения agent_id, PID, WidgetTarget, номер порта и имя файла не являются учётными данными.

Полномочия на ресурсы принадлежат Core и контроллеру; семантика GUI-действий и постусловия — API и адаптеру Toolkit; семантическое состояние приложения и захват кадров — SDK. Render проверяет источник кадра, сессию, свежесть, формат и квоты. MCP, Skills и Viewer не создают отдельные реестры политик или сессий. Доверенный управляющий слой необходимо отделить от недоверенных данных Issues, агентов, PR и приложений реальными границами ОС и каналов связи. Инструкции в запросе модели сами по себе изоляцию не обеспечивают.

| Модуль | Ответственность | Полномочия / граница | Недопустимые действия |
|---|---|---|---|
| Core | Сессии, процессы, Job, владение ресурсами и жизненный цикл | Сохранённые дескрипторы собственных ресурсов и точное поколение | Семантика GUI, поиск и завершение чужих процессов |
| API | Авторизация, разрешения, координация и результаты | Контекст из проверенной идентичности и политика | Доверие к AgentId от клиента или дублирование реестра |
| Remote | Типизированная доставка команд, защита от повторов и чтение результата | Аутентифицированная привязка приложения и журнал команд | Глобальный ввод или автоматический повтор при неизвестном результате |
| Render | Подлинность и свежесть кадров, квоты и владение ресурсами | Источник, канал, процесс и эпоха рендерера | Вывод о подлинности кадра по сигнатуре PNG |
| SDK | Семантические действия, состояние, работоспособность и чтение результата в приложении | Явно подключённый поток приложения и источник разрешённых возможностей | Копирование или форк всего Makepad SDK |
| MCP | Отображение протокола в общий API | Проверенные полномочия клиента | Отдельные бизнес-правила поставщика или передача дескрипторов ОС |
| Desktop | Вкладки, статусы и текущий кадр собственного приложения | Авторизация через API; владение только ресурсами просмотра | Перевод в foreground или обход через глобальный физический ввод |
| Skills | Версионируемые безопасные инструкции | Без учётных данных и выдачи разрешений | Скрытый обход ограничений или повышение статуса |
| CheckBroker | Проверки утверждённых неизменяемых исходников | Независимые полномочия на исполнение и выпуск свидетельств | Ослабление защищённого профиля ради использования как среды GUI |


Структурное исследование корня PR #10 вернуло SKLT_ONLY: 8 модулей, объектов и файлов, 0 GLIF, write_enabled=false. Это только наблюдение структуры. Идентификаторы mss.core/api/remote/render/sdk/mcp/desktop/skills сохраняются. Прямые зависимости Remote/Render от API в Cargo описаны шире, чем в текущем SKLT; запланированные дополнительные связи нельзя удалять лишь потому, что реализация ещё отсутствует. [Декларации Dungeon](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/doc/dungeon.md), [SKLT Render](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Render/mss_render.sklt). Подключение к управляемому режиму, индексирование и проекция не выполнялись.

**Нужны два профиля:** защищённый CheckBroker без GUI для потенциально враждебного кода сборки и тестов и отдельно проверенный профиль исполнения Makepad. Нельзя ослаблять токен Broker или проверки Win32k/USER32 ради рендеринга. Частные рабочие столы, адресация ввода, Job и раздельные процессы сами по себе не изолируют файловую систему, сеть или все ресурсы ОС. [SECURITY](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/SECURITY.md), [аудит Broker](infrastructure/infrastructure-audit.md).

## 5. Findings and Risk Register (P0/P1/P2/P3)

P0 — обязательное условие безопасности и квалификации перед изменяющими состояние действиями или включением автоматизации; P1 — препятствие функциональной интеграции или согласованию исходников; P2 — надёжность, структура и просмотр; P3 — отложенная интеграция поставщиков и документация. Многие риски P0 сейчас сдерживаются отключённым режимом с отказом по умолчанию. Это запрет на включение до проверки, а не утверждение об уже произошедшем инциденте.

| ID | Priority | Finding | Source | Mitigation / Invariants |
|---|---|---|---|---|
| R01 | P0 | Нельзя исполнять недоверенный agent/PR код через существующий production Broker: entry всегда BLOCKED, authority/materializer/network/receipt границы не qualified. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/368e5c54bb3da8a65cad2db9f141041100eb4630/native-check-broker/src/main.rs) | B02–B07; не включать dispatcher. INV-BROKER-01, INV-BROKER-02, INV-NET-01 |
| R02 | P0 | Обязательный USER32 gate BLOCKED: post-READY NULL/error0 нельзя подменить startup descriptor/READY. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/368e5c54bb3da8a65cad2db9f141041100eb4630/native-check-broker/evidence/20261030-crash-user32.json) | Сохранить gate; исследовать независимое OS observation; при несовместимости constraints — NO-GO, отдельное security design review без weakening. INV-PROC-07 |
| R03 | P0 | Внешний caller/app не аутентифицируется; RequestContext/AutomationId — данные, не credentials. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_API/src/lib.rs) | A04/A05 capability+peer-process binding до реальной delivery. INV-AUTH-01, INV-AUTH-03 |
| R04 | P0 | Нет authenticated app producer, replay/outcome ledger и независимых runtime postconditions; первые side effects сейчас небезопасны. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Remote/src/lib.rs) | A05 read-only -> A06 reserve/outcome -> A07 renderer -> A08 PoC. INV-CMD-04, INV-CMD-06, INV-RENDER-02 |
| R05 | P0 | Protected source, WFP/egress, per-session OS principals и receipt authority не доказаны; общий same-user/RC доступ остаётся риском. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/368e5c54bb3da8a65cad2db9f141041100eb4630/native-check-broker/src/native.rs) | Independent cross-session ACL+network/authority gates B02–B05. INV-BROKER-02, INV-NET-01, INV-EVIDENCE-02 |
| R06 | P0 | Cargo build.rs/тесты — произвольный код; self-hosted physical labels и --locked не защищают host. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/d83520d931ab000574c5c02192b9f49da86a34ea/.github/workflows/codex-issue.yml) | CI disabled/trusted manual source proof до B06; no windows-latest/VM. INV-CI-01, INV-EXEC-01 |
| R07 | P0 | Физический input/window contract Toolkit может не иметь разрешённого эквивалента при фиксированных запретах; full112 parity не обещается заранее. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/doc/testing.md) | Не сокращать suite; per-op equivalent proof или UNSUPPORTED/BLOCKED. INV-PARITY-01, INV-INPUT-01 |
| R08 | P1 | PR11 actual regression FAIL и fmt FAIL на current192b81a; GitHub description NOT_RUN устарел. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/192b81ac83cfa3945318804430af25b3795609ad/MSS_Remote/src/lib.rs#L352) | A00 минимальный fixture escaping/rustfmt и повтор gates. INV-CMD-01 |
| R09 | P1 | Документация не учитывала полный Windows hosted D3D path: выбранный backend нельзя обосновать Linux-only тезисом. | [источник](https://github.com/makepad/makepad/blob/130be1d0318adcf69453d925342607466353152c/platform/src/os/windows/windows_stdin.rs) | A03 точный A/B spike/ADR; runtime appendix. INV-PLATFORM-01, INV-RENDER-08 |
| R10 | P1 | Hosted использует Studio WS/build id и named Local D3D handles/default SD; не готовый private parent pipe/auth. | [источник](https://github.com/makepad/makepad/blob/130be1d0318adcf69453d925342607466353152c/platform/src/os/windows/d3d11.rs#L3608) | Не включать hosted как security backend без ACL/channel/sync proofs; B candidate preferred conditional. INV-RENDER-02, INV-RENDER-08 |
| R11 | P1 | Ignored AcquireSync outcomes и non-Unix watchdog не дают dead-peer/frame/host-loss proof. | [источник](https://github.com/makepad/makepad/blob/130be1d0318adcf69453d925342607466353152c/platform/src/os/windows/d3d11.rs#L1159) | Timeout/abandoned qualification; own Job; no unsafe fallback или upstream patch здесь. INV-RENDER-08, INV-PROC-05 |
| R12 | P1 | PR5 имеет AGENTS conflict, старые GOAL pointers и manual checks; нельзя переносить старую версию поверх строгого main. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/9c0e867f8844a6bc7949c7705db5c2cbbb65ef1c/AGENTS.md) | B00 reconciliation и сохранить main Cargo.lock/правила; no second GOAL system. INV-STRUCT-01, INV-CATALOG-01 |
| R13 | P1 | CODEX_DISPATCH_TESTS argv не admitted policy, manual receipt refs не automatic format; standalone broker не в root workspace. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/368e5c54bb3da8a65cad2db9f141041100eb4630/goals/checks/catalog.json) | B01 exact check IDs/argv/receipt provenance + separate manifests; no arbitrary shell allowlist. INV-CATALOG-01 |
| R14 | P1 | Actions runs0 и commit-status contexts0: independent CI evidence отсутствует; state pending не выполняющийся gate. | [источник](https://api.github.com/repos/paulgreenbox-beep/makepad-sandstudio/actions/runs) | Проект CI и physical qualification B06; сохранить historical local evidence отдельно. INV-CI-01, INV-TEST-01 |
| R15 | P1 | openai/codex-action Windows unsafe не native security boundary; action устанавливает CLI/proxy и workflow делает collect/upload после untrusted model step. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/d83520d931ab000574c5c02192b9f49da86a34ea/.github/workflows/codex-issue.yml) | Exact action/CLI supply-chain approval, protected stage separation B05/B06; никаких установок сейчас. INV-CI-01, INV-EVIDENCE-02 |
| R16 | P1 | Process-local IDs/Fixed generation1 не годятся как durable wire credentials между restarts. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Core/src/lib.rs) | Runtime epoch/peer binding/generation transitions A04; Core public type не переписывать без consumer gates. INV-ID-02, INV-ID-03 |
| R17 | P1 | Toolkit .deps Makepad SHA неизвестен; tools2 target71c9dd отличен от MSS130be. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/doc/compatibility.md) | Freeze a tested version tuple; tool2 remains experimental, no SDK upgrade by assumption. INV-PLATFORM-01 |
| R18 | P2 | FrameStore PNG профиль намеренно узкий; accepted-pixel cap не hard peak RAM; нет freshness/renderer epoch/backpressure. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Render/src/lib.rs) | Actual encoder compatibility and bounded decode/stream worker A07; no fake GPU claims. INV-RENDER-03, INV-RENDER-04, INV-RENDER-06 |
| R19 | P2 | SKLT direct dependencies Remote/Render→API не отражены полностью; object_id стабильны, GLIF0. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Render/mss_render.sklt) | A02 точечные structural declarations; не managed adoption/index. INV-STRUCT-01 |
| R20 | P2 | Desktop/SKD/MCP иллюстративны/placeholder; polishing до producer/API создаст фиктивную функциональность. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Desktop/src/main.rs) | Сначала actual frame+process channel; A09/A11 тонкие adapters. INV-DESKTOP-01, INV-MCP-01 |
| R21 | P3 | MSS_Skills пока один README; provider-specific инструкции могут рассинхронизироваться с capabilities. | [источник](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/MSS_Skills/README.md) | Versioned examples только поверх подтверждённых API после A11. INV-MCP-01 |


Дополнительно: каталог Toolkit различает set_value и input, но исходники reliability используют общий маршрут verified_input. Название маршрута не доказывает способ исполнения: нужен независимый критерий проверки результата. Совпадение внутреннего маршрута не разрешает подменять операции. [Аудит Toolkit](toolkit/README.md). Историческая запись об оборудовании не подтверждает физический runner или отсутствие виртуализации; функции хоста на этом этапе не менялись.

## 6. Formal Invariant Catalog

Полный [каталог из 54 строк](invariant-catalog.md) и [JSON](invariants.json) содержат формальное правило, существующую реализацию, сценарий нарушения, обязательную проверку, свидетельства и статус. Распределение статусов в указанных границах: PASS=13, FAIL=1, BLOCKED=2, NOT_RUN=0, NOT_VERIFIED=38. PASS логической модели или собственного тестового процесса не переносится на нативную среду, продукт или производственную эксплуатацию.

| Invariant ID | Формальное правило | Обязательный тест | Текущий статус |
|---|---|---|---|
| INV-ID-01 | В одном процессе полный ID=(RegistryId,local_id) ненулевой и не повторяется после close/drop; MAX выдаётся один раз, затем IdExhausted без wrap. | T-001 | PASS |
| INV-ID-02 | Сериализованный RuntimeSessionKey включает случайный supervisor epoch и generation; ключ из предыдущего запуска никогда не авторизуется в новом trust domain. | T-002 | NOT_VERIFIED |
| INV-ID-03 | Несовпадающее поколение live session всегда даёт StaleGeneration до side effects; закрытый handle UnknownSession.  | T-003 | PASS |
| INV-ID-04 | AgentId является логическим владельцем ровно назначенных sessions; передача selection не передаёт ownership. | T-004 | PASS |
| INV-AUTH-01 | Внешний RequestContext выводится из проверенного principal/capability, а не из переданного клиентом agent_id. | T-005 | NOT_VERIFIED |
| INV-AUTH-02 | Authorization exact owner/generation предшествует parsing, cancellation, capability reporting и любым side effects. | T-006 | PASS |
| INV-AUTH-03 | Разрешение класса Inspect не даёт Input/Test; target-specific capability подтверждена приложением и policy до dispatch. | T-007 | NOT_VERIFIED |
| INV-AUTH-04 | Любой отказ сохраняет registry/selection/frame sequence/ledger и состояние соседней session. | T-008 | PASS |
| INV-CMD-01 | AutomationId точный, непустой, без краевых Unicode whitespace/controls; адрес не меняется silent trim. UTF-8 byte bounds соблюдены. | T-009 | FAIL |
| INV-CMD-02 | AutomationId/WidgetId/action связываются с app identity, layout/focus generation и capability; строка target сама не доказывает widget existence. | T-010 | NOT_VERIFIED |
| INV-CMD-03 | При отсутствии backend исполнение не возвращает успех/OBSERVED/PASS. | T-011 | PASS |
| INV-CMD-04 | RequestId=(runtime epoch,session,generation,client nonce,sequence) уникален; side effect допустим лишь после атомарного reserve. Один id не исполняется дважды. | T-012 | NOT_VERIFIED |
| INV-CMD-05 | Принятые command sequences возрастают в своей session/generation; rollback/wrap/параллельное нарушение порядка отвергаются до dispatch. | T-013 | NOT_VERIFIED |
| INV-CMD-06 | OBSERVED требует независимого postcondition после dispatch и runtime health той же app generation; acknowledgement недостаточен. | T-014 | NOT_VERIFIED |
| INV-CANCEL-01 | CancellationToken монотонен, clones разделяют flag; flag проверяется после ownership и до admission. | T-015 | PASS |
| INV-CANCEL-02 | Cancel после dispatch не означает rollback/known refusal; потеря ответа/worker => OUTCOME_UNKNOWN до независимого readback, без automatic repeat. | T-016 | NOT_VERIFIED |
| INV-PROC-01 | Управление process допускается только при совпадении retained HANDLE, PID, creation time, canonical image path/hash и session generation. | T-017 | NOT_VERIFIED |
| INV-PROC-02 | Процесс создаётся suspended с reviewed token/profile и помещается в owned Job до ResumeThread; работа вне Job невозможна. | T-018 | NOT_VERIFIED |
| INV-PROC-03 | Inherited handles ограничены allowlist конкретного запуска; GitHub/API/signing/source authority handles не наследуются. | T-019; T-X11 | NOT_VERIFIED |
| INV-PROC-04 | Close/cancel одной app/test session останавливает только её Job и удаляет только её leases/channels/frames; другая продолжает работу. | T-020 | NOT_VERIFIED |
| INV-PROC-05 | Graceful close имеет deadline; hard containment и cleanup-pending отличаются от normal exit; неопределённая ownership запрещает force kill. | T-021 | NOT_VERIFIED |
| INV-PROC-06 | Для конкретного crash fixture supervisor и owned child завершаются; observer handle закрывается; точный desktop затем отсутствует. | T-022 | PASS |
| INV-PROC-07 | Фактическая post-READY USER32 association проверяется у exact retained primary thread; launch desktop string/PEB/READY не заменяют observation. | T-023 | BLOCKED |
| INV-RENDER-01 | Publish/latest/live forget авторизуют exact scoped SessionHandle; frame identity и положительная sequence совпадают с контекстом. | T-024 | PASS |
| INV-RENDER-02 | Frame producer — аутентифицированный retained app instance; подпись/канал и process identity проверены независимо от присланной metadata. | T-025 | NOT_VERIFIED |
| INV-RENDER-03 | Freshness проверяет capture time/receive time/monotonic seq в пределах renderer epoch; старый latest не выдаётся за current. | T-026 | NOT_VERIFIED |
| INV-RENDER-04 | Renderer reset меняет renderer epoch, инвалидирует старые frames/surface leases; новый seq1 не конфликтует и не смешивается со старым GPU resource. | T-027 | NOT_VERIFIED |
| INV-RENDER-05 | Encoded frame/aggregate bytes/count и live watermarks bounded; forget не сбрасывает sequence, Closed receipt чистит только exact incarnation. | T-028 | PASS |
| INV-RENDER-06 | Hard decoder memory/CPU и queue/backpressure ограничены отдельным enforceable budget; accepted-pixel cap не объявляется peak-RAM quota. | T-029 | NOT_VERIFIED |
| INV-RENDER-07 | PNG admission проверяет supported profile, CRC/structure/dimensions/zlib/filter/decode до cache mutation; отказ сохраняет прежний frame. | T-030 | PASS |
| INV-RENDER-08 | Если используется backend A/shared surfaces: acquire/release timeout/abandonment учитываются; surface name/build id не являются credentials. | T-031 | NOT_VERIFIED |
| INV-EVIDENCE-01 | Evidence manifest привязан к source/dep/toolchain/check argv, session/agent/generation/process/request, времени, result и SHA-256 каждого artifact. | T-032 | NOT_VERIFIED |
| INV-EVIDENCE-02 | Receipt authority недоступна worker/agent; SHA-256 не заменяет authenticity. Verifier проверяет protected channel/signature/nonce/source/check. | T-033; T-X14 | NOT_VERIFIED |
| INV-EVIDENCE-03 | Credentials не попадают в stdout/stderr/artifacts/PR/Issue; redaction failure не даёт PASS и не публикует raw secret. | T-034 | NOT_VERIFIED |
| INV-TEST-01 | PASS требует executed exact contract; compile/dispatch/HTTP ACK/скриншот не повышают уровень native/GUI/production evidence. | T-035 | NOT_VERIFIED |
| INV-FS-01 | Все paths разрешены через owned roots/handles; traversal/UNC/device/reparse/case collision/TOCTOU отказываются до доступа. | T-036 | NOT_VERIFIED |
| INV-NET-01 | Network deny/allow выполняется ОС для exact process identity; boolean policy или localhost binding не являются enforcement. | T-037 | NOT_VERIFIED |
| INV-EXEC-01 | Запускается exact approved executable через pinned path/file identity; argv array фиксирован, shell/PATH/wrapper/DLL/config injection не дают broad host execution. | T-038; T-X13 | NOT_VERIFIED |
| INV-SOURCE-01 | Materialization immutable exact commit tree; рабочие source/control policy не writable агентом в течение проверки; output root отдельно. | T-039 | NOT_VERIFIED |
| INV-BROKER-01 | Production binary не запускает checks и не выпускает receipts, пока mandatory boundary не qualified; JSON validity не authority. | T-040 | PASS |
| INV-BROKER-02 | Caller authority проверяется независимо от attacker JSON; controller/worker identities, source/receipt roots и capabilities разделены. | T-041 | NOT_VERIFIED |
| INV-BROKER-03 | Один broker request/check binding резервируется create-only; uncertainty не вызывает automatic replay; outputs/deadline/process limits enforced. | T-042 | NOT_VERIFIED |
| INV-GITHUB-01 | Ready label actor (sender.id/login/triggeringActor + maintain/admin) и approved body hash проверяются до claim; issue body — data.  | T-043 | PASS |
| INV-GITHUB-02 | Claim create-only + uncertain-write readback; PR confirmed Draft before IN_REVIEW; only exact task branch writable; VERIFIED/merge/main-policy forbidden агенту. | T-044 | NOT_VERIFIED |
| INV-CATALOG-01 | Required check set общий для catalog/policy/GOAL/broker; неизвестные/manual checks и неподтверждённые receipts не обходятся. | T-045 | BLOCKED |
| INV-CI-01 | Недоверенный PR/build.rs исполняется только внутри qualified physical-worker boundary; GitHub-hosted VM/containers и broad self-hosted host execution запрещены. | T-046 | NOT_VERIFIED |
| INV-DESKTOP-01 | Viewer показывает только selected authorized session/current epoch, освобождает только свои GPU/cache leases; UI thread не получает raw process authority. | T-047 | NOT_VERIFIED |
| INV-SCHED-01 | App/agent/test worker identities и bounded queues/leases независимы; global desktop capacity не объявляется parallel addressed input. | T-048 | NOT_VERIFIED |
| INV-MCP-01 | MCP — тонкий transport над тем же API; SDK actions/health/capabilities принадлежат app, provider не создаёт второй registry. | T-049 | NOT_VERIFIED |
| INV-PARITY-01 | Все112 выбранных Toolkit operations и unchanged .aiui.json/schema/negative/teardown tests сохраняются; semantic/physical methods не подменяются. | T-050 | NOT_VERIFIED |
| INV-STRUCT-01 | SKLT object_id стабильны; declared dependencies отражают реальные owned edges; SKLT BOUNDED не OS sandbox proof. | T-051 | NOT_VERIFIED |
| INV-PLATFORM-01 | Любое compatibility PASS относится к точной версии/platform tuple; Toolkit local .deps SHA и experimental tools2 target не подменяются Makepad dev. | T-052; T-X12 | NOT_VERIFIED |
| INV-RELEASE-01 | Production activation требует независимого acceptance всех mandatory gates и owner approval; агент не выставляет VERIFIED и не включает dispatcher. | T-053 | NOT_VERIFIED |
| INV-INPUT-01 | Ввод доставляется только own app channel; нет SendInput/global foreground/desktop switch/user-desktop handle; адресный event != full OS sandbox. | T-054 | NOT_VERIFIED |


Для каждой строки полный каталог задаёт конкретный контрпример и ожидаемое наблюдение. Утверждение об изоляции требует проверки идентичности, отказов доступа через ACL и каналы, жизненного цикла процессов и ресурсов, а также негативных сценариев.

## 7. Complete Toolkit Operation Parity Matrix

Повторный подсчёт точного operations.json дал **112** операций; прежнее количество не менялось. SHA256 исходного каталога: **ffaaba15ddc2ee57c7eaf001383ee2bd285d324d640a49eed390eb4fcf339470**; Git blob и источник сохранены. Полное приложение содержит **112 строк**: [toolkit-operations-appendix.md](toolkit/toolkit-operations-appendix.md). Нормативные данные для машинной проверки: [toolkit-parity.json](toolkit/toolkit-parity.json), исходные [каталог](toolkit/operations.raw.json) и [схема](toolkit/schema.raw.json).

Для каждой операции указаны точное имя, обязательные и необязательные параметры, признаки каталога, capability и схема. Признаки изменения состояния, идемпотентности и физического ввода рассматриваются независимо; отсутствие сведений означает NOT_VERIFIED, а не false. Классификация эффектов по исходникам отделена от нормативных гарантий; без исполнения фактический способ остаётся NOT_VERIFIED. Текущий эквивалент MSS — UNSUPPORTED, реализация NOT_IMPLEMENTED, проверка NOT_VERIFIED. Заданы конкретные PLANNED-проверки независимых постусловий и отказов, ссылки на базовые сценарии, исходники и тесты, а также недостающие проверки MSS. Идентификаторы TK-OP-001…112 включают CONTRACT/EFFECT/FAILURE/ISOLATION и контрольный этап A13. Текстовые упоминания и предполагаемые ошибки служат навигацией; это **не подтверждённое перечисление ошибок и не доказательство покрытия**.

Общая схема с additionalProperties=true не задаёт полный формальный тип каждого аргумента операции: нормативным источником остаются соответствующие валидаторы Rust. Гарантии, которых нет в исходниках или результатах исполнения, не добавлены как факты. Наличие 43 сценариев v1, 1 набора suite и 13 профилей sample-not-run не означает выполнения всей базовой программы приёмки. Публичные композиции runner, generated, inline и shell сохранены в области инвентаризации. [Указатель исходников и тестов](toolkit/test-inventory.json).

Недопустимые отождествления: set_value≠input, click≠set_value, ACK≠фактический эффект, скриншот≠независимое постусловие, компиляция≠совместимость при исполнении. Все 112 операций остаются целевым критерием, даже если некоторые оконные сценарии или операции физического ввода окажутся невозможны при действующих ограничениях. В таком случае требуются UNSUPPORTED/BLOCKED и статус полного паритета NOT_VERIFIED; выборочное удаление или пропуск тестов недопустимы.

## 8. Existing Test Inventory

[Полный именованный реестр](existing-test-inventory.md), [JSON среды исполнения](runtime/runtime-test-inventory.json), [JSON инфраструктуры](infrastructure/infra-test-inventory.json), [общий указатель](existing-tests-index.json). Каждая текущая или историческая запись содержит имя, файл и строку, SHA исходников, результат, уровень свидетельства и ссылку. Для инфраструктуры также сопоставлены точные Git blobs, cfg, ignore и журналы.

| Срез | Тесты в исходниках | Что действительно подтверждено |
|---|---|---|
| main 83ff501 | 0 поведенческих тестов Rust | Каркас и скомпилированный иллюстративный Desktop; нативное исполнение и GUI — NOT_VERIFIED |
| PR1 | 12 Core | Исторический результат Core: 12 PASS на точных исходниках; семь исходных тестов сохранены |
| PR2 | Всего 9 = Core 7 + API 2 | Перечень из исходников; исполнение этой ветки не выдаётся за запуск PR10 |
| PR3 | Всего 11 = Core 7 + API 2 + Remote 2 | Перечень из исходников; исходные утверждения тестов сохранены |
| PR4 | Всего 12 = Core 7 + API 2 + Render 3 | Перечень из исходников; исходная проверка сигнатуры не доказывает целостность PNG |
| PR10 | 44 = Core 16 / API 6 / Remote 5 / Render 9 / композиция 8 | Логические тесты на точном 352e2c3 — PASS; восемь команд — PASS; 8863 меняет только документацию, код идентичен |
| PR11 | 45 | Фактический результат 192b81a: 44 PASS / 1 FAIL / 0 ignored; fmt FAIL; в аудите ошибка не исправлялась |
| PR5/7/9: инфраструктура | 119 уникальных именованных тестов = 39 Rust + 80 Node | 37 Rust PASS / 2 NOT_RUN и 80 Node PASS на своих исходниках; это не единый интеграционный запуск |
| Исходный Toolkit | 210 деклараций Rust + 116 Node | Статическая инвентаризация всех исходников; развёртывание динамических и cfg-тестов не выполнялось; все исполнения в аудите — NOT_RUN |


Всего в разных ветках **164 именованных тестовых случая MSS**. Их исторические PASS нельзя объединять в утверждение о едином успешно выполненном наборе: они принадлежат разным деревьям исходников. При заблокированной приёмке USER32 успешно проходят утверждения об отказе; это не PASS фактической привязки рабочего стола. Два ignored-теста WFP/symlink сохранены со статусом NOT_RUN и своими предпосылками. [Нативные свидетельства](evidence/pr9-crash-user32.json), [история Node и ручной проверки](evidence/pr7-dispatcher-manual.json). В этой фазе PLAN FIRST новых запусков проектных тестов — 0; хеши прежних журналов и идентичность исходников сверены повторно.

## 9. Missing Tests and Verification Matrix

Все 68 будущие или расширяемые проверки приведены в [полной таблице](missing-tests.md) и [JSON](proposed-tests.json); дополнительно заданы 112 групп операций в матрице паритета. Для каждой проверки указаны сценарий, предпосылки, ожидаемый результат, среда, свидетельства, приоритет, целевой PR и ссылки на инварианты.

| Уровень | Основная область | Обязательные примеры / IDs |
|---|---|---|
| 1. Статические проверки | Закреплённые версии, схемы, каталог, GOAL, SKLT, CI и метаданные доверия | T-X01/X02; INV-STRUCT/CATALOG/CI; граф зависимостей и привязка к исходникам |
| 2. Модульные тесты и свойства Rust | Исчерпание ID, поколения, авторизация и отказ, отмена, лимиты журнала и декодера | Сохранить текущие тесты; детерминированные последовательности и барьеры конкурентного исполнения, без обхода производственной авторизации |
| 3. API/Remote/Render | Владелец, чужая или устаревшая сессия, заполненный кеш, неверные данные, отмена | Сохранить 8 публичных интеграционных тестов; добавить реальные идентичности, источники кадров и сбои исполнителя |
| 4. Нативные процессы | Собственный ProcessLease, приостановленный Job, идентичности дочернего процесса и процесса тестирования | Подмена PID, времени создания и образа; список дескрипторов; закрытие A при продолжающей работу B |
| 5. Безопасность Windows и освобождение ресурсов | Токен, ACL, WFP, reparse, исходники, свидетельства, USER32, потеря управляющего процесса | B02–B06; предпосылки существующих ignored-тестов не заменять имитацией |
| 6. Адресованный ввод Makepad | Семантические возможности в потоке приложения, чтение результата и работоспособности | INV-INPUT/CMD/AUTH, T-X03/X04; без глобального ввода |
| 7. Настоящий рендерер | Реальные кадры с nonce, источник, сброс, свежесть, mutex и нагрузка на декодер | INV-RENDER-02…08; проверки синтетических PNG остаются отдельными |
| 8. Область просмотра Desktop | Выбранный текущий кадр, устаревание, ошибка и освобождение ресурсов | INV-DESKTOP-01; отдельное собственное тестовое приложение просмотра |
| 9. MCP/Toolkit | Общие контексты API, неизвестные инструменты, сохранение семантики сценариев и отчётов | T-X07/X09; TK-OP-001…112; платные пробные вызовы клиентов — отдельно |
| 10. Параллельность, отказы и безопасность | Гонки, повторы, потерянные ответы, аварии, ресурсы и смешение свидетельств | T-X03/X04/X05/X08/X10; точная классификация неизвестного результата и освобождение ресурсов |


Требуемые свидетельства: исходники, команда и среда; фактическое наблюдение и работоспособность приложения; идентичность процесса, канала и кадра каждой сессии; SHA256 неизменяемых артефактов; результат освобождения ресурсов и перечень оставшихся ресурсов. Синтетическая модель, реальный собственный примитив ОС и работающее приложение Makepad учитываются раздельно. Объявление тестовой функции само по себе не подтверждает покрытие или результат.

## 10. Required Code and Architecture Changes

Минимальный дополнительный код сгруппирован по ответственным и PR в [22 подробных карточках](ordered-pr-backlog.md). Каждая объясняет, почему имеющегося кода недостаточно, и задаёт файлы, интерфейсы, ссылки на инварианты и тесты, критерии приёмки и риски регрессий. Существующие реестр, API, механизмы отказа и кеш не переписываются. Общая инфраструктура расширений и оркестрации вводится только при обоснованной необходимости.

| Область | Нужное расширение | Что переиспользовать | Проверка регрессий |
|---|---|---|---|
| Идентичность и жизненный цикл | RuntimeSessionKey(epoch), ProcessLease/Identity; явный запуск, Job, сроки завершения и карантин | Непрозрачные ID, владелец и поколение Core; реестр числовых PID недостаточен | Исходные 16 тестов Core и нативные проверки своих и соседних процессов |
| Авторизация и связь с приложением | Контекст из проверенной идентичности, начальная привязка приложения и клиента, семантические разрешения | Единый заимствованный API/Core; явно подключаемые публичные точки Makepad через SDK | Отказы для чужих и устаревших сессий, неверного узла и прямого обхода; AgentId из канала не считать доверенным |
| Исполнитель | Ограниченный журнал резервирования, доставки и результата команд; чтение результата и работоспособности | Типизированные намерения Remote и отказ для неверного формата; без автоматического повтора | Гонки, отмена и неизвестный результат до разрешения изменяющих состояние команд |
| Рендерер | Доверенный источник, время, эпоха, шаг строки, хеш и поток с лимитами | Допуск кадров, освобождение ресурсов, последовательности FrameStore и закреплённый декодер | Настоящий кадр приложения; сброс, переполнение потока и бюджет декодера |
| Процессы проверок и свидетельства | Независимые процессы тестирования, адаптеры планировщика Toolkit, защищённые манифесты | Существующие runner, reliability и economy Toolkit; неизменяемые исторические записи | Потеря процесса проверки, работоспособность, сокрытие секретов и подделка свидетельств |
| Клиентские интерфейсы | Тонкие адаптеры просмотра, MCP и skills поверх действующего API | Имеющаяся оболочка Desktop; общая политика без дублирования | Выбранный настоящий кадр, разрешения клиента и отказы |
| Инфраструктура | Полномочия, подготовка исходников, WFP, ACL, свидетельства и разделение управления | Отключённый dispatcher, производственный отказ Broker и пробы с привязкой к исходникам | Отдельный Broker, 80 тестов Node и независимая квалификация безопасности |


Решения без изменения кода: оставить dispatcher отключённым; сохранить полный паритет как цель и все ограничения; выбрать условный эксперимент B и сравнительный вариант A; сохранить единую схему GOAL; не переносить PASS нативного тестового процесса на продукт. Добавление зависимостей или изменение точки входа SDK допускается только в отдельно рассмотренном объёме реализации с анализом точной версии, лицензии, features и платформ.

## 11. Windows Two-Session Feasibility Decision

**Вердикт: исходники дают кандидатов на реализацию; разрешение GO для исполнения — NOT_VERIFIED, живой PoC — NOT_RUN.** Предварительно выбран минимальный PoC B: два собственных процесса приложений Makepad, каждый со своим чтением RenderBGRAu8 из рендерера, защищённым каналом команд и кадров, отдельными учётными данными и клиентами-агентами. Вариант A — общая поверхность D3D дочернего hosted-приложения Windows — остаётся сравнительным экспериментом. Он не становится основным производственным путём до проверки аутентификации, ACL и mutex. [Точные API, файлы, строки и источники ОС](runtime/runtime-audit.md).

| Критерий | A: поверхность дочернего hosted-приложения | B: кадры GPU от самого приложения |
|---|---|---|
| Пути в исходниках | windows.rs/stdin-loop → Studio WebSocket; HostSwapchain/sharedBGRAu8; именованные поверхности D3D NT | Кандидат — захват StandaloneRemote/g либо явно подключённые RenderBGRAu8, Texture::read_back и очередь чтения Cx |
| Наличие в Windows | Код существует на точном 130be1d; прежний обзор только Linux был неполным | API чтения присутствуют; точная точка входа приложения для частного или заэкранного исполнения требует эксперимента |
| Ввод | Сообщения Studio адресованы конкретному приложению; WS/build id не обеспечивают аутентификацию | SDK в потоке приложения, объявленные семантические ID и аутентифицированная привязка pipe |
| Происхождение кадра | Нужна проверка привязки поверхности, дочернего процесса и сборки, а также фактического успеха mutex; импортёр может игнорировать числовой дескриптор | Заявка чтения, сессия, процесс, эпоха рендерера, полный буфер и хеш, а также независимое состояние |
| Производительность | Возможны малые затраты копирования, но есть риски keyed mutex и времени жизни; измерений нет | Затраты CPU на чтение, копирование и PNG; предел эксперимента 800x600@5fps не является измеренной производительностью |
| Пробелы безопасности | Дескриптор безопасности по умолчанию, предсказуемые имена, WS без аутентификации, игнорирование AcquireSync; восстановление после потери узла не доказано | Нужны реализация и проверка отдельного ACL канала pipe, привязки узла и публичной точки источника кадров; одного шлюза недостаточно |
| Совместимость | SharedBGRAu8 не равнозначен обычному чтению RenderBGRA; сочетание hosted/g не проверено | Совместимость узкого профиля PNG MSS с настоящим кодировщиком требует измерений; полного паритета захвата Toolkit нет |
| Решение | Только сравнение; NO-GO, если гарантии недостижимы без запрещённых изменений SDK | Предпочтительный условный первый этап; NO-GO при отказе публичной точки входа, GPU без рабочего стола пользователя, аутентификации или проверки происхождения |


Будущий протокол с ограниченным объёмом исполнения (ещё не выполнен):

1. Зафиксировать неизменяемое сочетание исходников, toolchain, приложения, профиля и зависимостей. Оператор отдельно разрешает запуск только доверенных тестовых приложений. Квалифицировать физический Windows-хост, GPU, драйвер и профиль исполнения. Ради теста нельзя открывать, переключать или наблюдать обычный рабочий стол пользователя.
2. Начать с контроллера и одного доверенного тестового приложения: область с nonce, счётчик и два поля. Исключить плагины, горячую перезагрузку, диалоги и сетевой обходной путь. Проверить исходники публичной точки выдачи кадров; если она требует переписывания upstream, результат — явный NO-GO. Локальная начальная привязка к ОС в стенде A03 не является производственной аутентификацией A04/A05.
3. Для узкого фиксированного стенда сохранить дескрипторы процесса, запись запуска Job и начальной привязки; это ещё не Core ProcessLease. Явно задать executable/argv/env/cwd, поместить приостановленный процесс в Job до возобновления, ограничить наследование дескрипторами начальной привязки и кадров. Проверить точные PID, время создания, образ и рабочий стол; задать сроки и защищённый pipe.
4. Предлагаемые консервативные лимиты: 800x600, 30 кадров при 5 fps, 2 MiB закодированных данных на кадр, одна незавершённая заявка чтения; запуск — 10 s, запрос — 2 s, полное время — 90 s. Это проект допуска и проверки, **не текущее измерение**. Принудительные лимиты CPU/RAM, дочерних процессов и вывода, их наблюдение и нагрузочные проверки рассматриваются отдельно.
5. В A03 разрешены только чтение и захват кадров; nonce изменяется самим тестовым приложением. Нужны реально отрисованные пиксели nonce, независимые состояние и работоспособность, эпоха кадра, последовательность, время и хеш; статический скриншот недостаточен. Внешние команды изменения состояния и сценарии потерянного ответа допустимы только после журнала A06; неизвестный результат не разрешает повтор.
6. Проверить неверный источник, чужого агента, устаревшее поколение, неверный кадр, тайм-аут, сброс рендерера и аварию. Нормальное завершение и принудительное ограничение своим Job учитывать раздельно. Сохранённые дескрипторы должны сигнализировать завершение; ресурсы, права владения и каналы освобождаются либо переводятся в карантин.
7. После GO для одного приложения и реализации необходимых A04–A07 повторить проверку для **двух дочерних процессов приложений**, двух процессов клиентов-агентов и собственных процессов тестирования. У каждого должны быть отдельные nonce, учётные данные и рабочие каталоги. Закрыть или аварийно завершить A, пока B продолжает выдавать кадры и выполнять действия. Это A08 — первая полная приёмка двух сессий, которую нельзя заменить декларацией потоков контроллера.

Решение GO требует свидетельств настоящего кадра, отсутствия запрещённого ввода, проверенных идентичностей и процессов, работоспособности, постусловий и освобождения ресурсов на точном профиле. Предпосылки отсутствуют — NOT_RUN; проверка начата, но предпосылка не позволяет выполнить контракт — BLOCKED; наблюдается неверный эффект, кадр или утечка — FAIL. Недопустимы скрытый перевод в foreground, SendInput, ослабление Win32k, VM или подмена скриншотом и имитацией. Эксперимент возможностей Windows не квалифицирует Broker для исполнения враждебного кода.

## 12. Native Broker Security Gaps

Цепочка #5 → #7 → #9 независима от среды исполнения GUI. Полная [матрица 15 границ безопасности](infrastructure/infrastructure-audit.md) разделяет протокол, модель, исходники, конфигурацию и свидетельства реальных примитивов ОС на фиксированных стендах. Текущая производственная точка входа отказывает даже при корректном JSON; в политике enabled=false, isolation.approved=false, scopes пусты, runner и закреплённые версии не настроены. [Политика](https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/d83520d931ab000574c5c02192b9f49da86a34ea/.github/codex-issue-policy.json).

До производственного включения обязательны следующие проверки:

| Граница | Имеющиеся ограниченные свидетельства | Недостающая обязательная проверка |
|---|---|---|
| Полномочия вызывающей стороны | TypedExecutionBinding и контроллеры фиксированных стендов | Аутентификация вызывающей стороны, узла и токена средствами ОС; защищённые разрешения; процесс исполнения не может выдать себя за контроллер |
| Подготовка исходников | Типизированные данные ExecutionBinding/BoundRequest; защищённый механизм подготовки исходников отсутствует | Доверенный импорт точного дерева; неизменяемые исходники, зависимости и команды; отсутствие обходов через .git/config, hooks, reparse и TOCTOU |
| Защита исполняемого окружения | Примитив запрета совместного доступа к образу и родительским каталогам | Точные путь, хеш и файловая идентичность; защита toolchain, DLL, окружения и конфигурации при враждебной сборке |
| Токен, Job и дескрипторы | Нативные проверки restricted token, low IL, атрибутов Job и дочернего процесса стенда | Раздельные идентичности исполнения, запрет доступа между сессиями; гонки запуска, наследование дескрипторов и нагрузка потомками |
| Файловая система | ACCESS_DENIED для частного и соседнего ресурсов в тестовом стенде | Два настоящих изолированных субъекта и корня исполнения; reparse, hardlink, ADS, регистр имён и гонки ACL |
| Сеть | Тест WFP пропущен; есть только требования политики | Фактическое применение ограничений ОС для IPv4/IPv6/TCP/UDP/DNS и потомков; разрешённые и запрещённые собственные конечные точки |
| Повторы, вывод и квоты | Модель AttemptFence, чтение настроенных лимитов Job и усечение stdout | Защищённые атомарные заявки; фактические лимиты CPU/RAM, процессов, диска и вывода под нагрузкой, включая удерживаемые pipe |
| Авария и освобождение ресурсов | Наблюдалось исчезновение собственного рабочего стола фиксированного стенда | Общее восстановление, карантин и параллельное освобождение ресурсов за пределами одного стенда |
| USER32 | PostREADYQueryUnavailable возвращает NULL/error0; обязательная проверка отклоняет результат | Наблюдение фактической привязки рабочего стола точного потока; недоступность остаётся BLOCKED, без ослабления проверки |
| Полномочия на свидетельства | Валидаторы хешей и формата привязок; производственных свидетельств нет | Защищённые подписант, канал и хранилище; проверка реальных байтов, исходников, nonce и подлинности, а не доверие к JSON процесса исполнения |
| Разделение управления, модели и публикации | Закреплённый workflow, разрешения и проект разделения | Защитить collect/upload после модели в том же задании либо перенести их к отдельной доверенной стороне; квалифицировать реальный физический хост |
| Развёртывание и пробный запуск | Отключённые флаги и требования к владельцу | Независимое одобрение безопасности; Secrets, регистрация, области доступа, версии и бюджет под контролем владельца; один ограниченный пробный запуск до широкого включения |


SHA256 подтверждает целостность, но не подлинность. Job, low IL и частный рабочий стол — отдельные примитивы, не полная граница изоляции ОС. Несовместимость или недоступность обязательной проверки USER32 означает NO-GO. Разрешённый альтернативный проект потребует независимого рассмотрения и новых свидетельств; удаление негативного теста проблему не решает. [Обоснование по Microsoft и исходникам](runtime/runtime-audit.md).

Отдельные проблемы интеграции: самостоятельный Cargo-проект Broker не входит в корневой workspace; проверка каталога Node отсутствует в allowed_commands; ссылки ручных локальных свидетельств несовместимы с автоматической схемой sha256. При отсутствии управляющего runner workflow останется в очереди и сам не сможет написать комментарий BLOCKED. Режим unsafe codex-action на Windows и закрепление action не квалифицируют хост. Установка CLI и proxy, цепочка поставки, идентичности и последующие шаги задания требуют отдельного рассмотрения. [Актуальная официальная документация и аудит закреплённого action](infrastructure/infrastructure-audit.md).

## 13. Dependency Graph

~~~mermaid
flowchart LR
  P11["#11 исправление тестовых строк"] --> P10["#10 принятая база; история #1-4 сохранена"]
  P10 --> A02["A02 контракты и проект отключённого CI"]
  A02 --> A03["A03 доверенный эксперимент Windows GPU"]
  A03 --> A04["A04 владелец процессов"]
  A04 --> A05["A05 аутентифицированные SDK/API"]
  A05 --> A06["A06 повторы и результат"]
  A05 --> A07["A07 доверенный поток кадров"]
  A06 --> A08["A08 PoC двух приложений"]
  A07 --> A08
  A08 --> A09["A09 Desktop"]
  A08 --> A10["A10 процессы проверок и свидетельства"]
  A08 --> A11["A11 MCP и SDK"]
  A10 --> A12["A12 неизменённый Toolkit runner"]
  A11 --> A12
  B00["B00 согласование существующего #5"] --> B01["B01 существующий #7 остаётся отключённым"]
  B01 --> B02["B02 полномочия #9"]
  B02 --> B03["B03 неизменяемые исходники"]
  B03 --> B04["B04 проверки ОС и USER32"]
  B04 --> B05["B05 доверенные свидетельства"]
  B05 --> B06["B06 квалификация физического CI"]
  A02 --> B06
  B06 --> B07["B07 пробный запуск только владельцем"]
  A09 --> A13["A13 полная приёмка продукта"]
  A12 --> A13
  B06 --> A13
~~~

Нормативный машиночитаемый источник — [pr-backlog.json](pr-backlog.json). Валидатор проверяет отсутствие циклов и неизвестных ссылок, а также наличие ссылок на инварианты и тесты. Диаграмма служит кратким представлением для рецензирования и не является трассой исполнения. A00 и B00 можно готовить параллельно; A06 и A07 — параллельно после A05; A09, A10 и A11 — частично параллельно после A08. Проекты B02 и B03 согласуются между собой; фактическое применение ограничений в B04 требует обоих. Свидетельства B05 и квалификация физического хоста B06 следуют последовательно. Любой конфликт в общем файле требует отдельного рассмотрения владельцем.

## 14. Ordered PR Backlog

Все 22 карточки с точными Goal/Base/DependsOn/Files/RequiredCode/Invariants/Tests/Acceptance/Risks/Size/MergeGate приведены в [ordered-pr-backlog.md](ordered-pr-backlog.md) и [JSON](pr-backlog.json). Существующие PR #1–#4 нельзя переписывать или дублировать: их работа уже включена в PR #10. PR #5, #7 и #9 следует дорабатывать в их цепочке только после отдельного разрешения; конкурирующие реализации не создаются.

| PR ID | Название | Зависит от | Объём | Условие слияния |
|---|---|---|---|---|
| A00 | Доработать существующий PR #11: реальные Unicode fixtures и rustfmt |  | S | Owner review исправленного точного SHA; до этого #11 остаётся FAIL/Draft. |
| A01 | Принять совместимую основу PR #10/#11 без переписывания #1–#4 | A00 | M | Ручной owner merge; #1–#4 закрывать как superseded только после подтверждённого merge #10 и сохранения истории. |
| A02 | Audit/CI contracts и воспроизводимые manifests | A01 | M | Review документов/validator; activation CI отдельно только после B06. |
| A03 | Issue #6: source-based Windows rendering qualification spike | A02 | L | Source+recipe/harness review допустим отдельно; выбор backend только по actual Windows/GPU evidence, не Cargo. |
| A04 | Native Process Owner и session lifecycle | A03 | L | Own-process evidence и независимый security review профиля; no foreign attach/kill. |
| A05 | Минимальный SDK producer и authenticated API/channel | A04 | L | Actual protected channel denial и минимальный source-reviewed app entry; SDK extensions не копируют Makepad. |
| A06 | Replay ledger и outcome/cancellation classification | A05 | M | Race/fault evidence + boundedness review; mutation запрещена при недоступном ledger. |
| A07 | Trusted Frame Producer и bounded Render Stream | A03; A05 | L | Actual GPU/window profile evidence; static fixture не acceptance producer. |
| A08 | Первый полный Windows two-session PoC | A04; A06; A07 | L | GO только по physical Windows/GPU evidence для exact profile. При отсутствии prerequisites NOT_RUN/BLOCKED, не синтетический substitute. |
| A09 | Подключить существующий MSS Desktop viewer | A08 | M | Separate owned GUI/render acceptance + unchanged root gates; no user-desktop test dependency. |
| A10 | Test workers, Scheduler adaptation, runtime health и evidence | A08 | L | Independent native worker/failure evidence; receipt authority для untrusted execution зависит от B05. |
| A11 | Thin MCP, расширения SDK и MSS Skills | A05; A08 | M | Model-free protocol acceptance; real-client evidence отдельно, unsupported capabilities остаются явными. |
| A12 | Toolkit Script Runner adapter и semantic operation slices | A10; A11 | L | Per-operation/source/profile evidence и совместимость SDK tuple; все112 остаются в matrix. |
| A13 | Полная Toolkit и native/product acceptance | A09; A12; B06 | XL | Owner/product release acceptance только после всех mandatory gates; не по одной release compilation. |
| B00 | Согласовать существующий GOAL Registry PR #5 с main |  | S | Owner registry review; no self-VERIFIED и no automatic issue execution. |
| B01 | Согласовать выключенный dispatcher PR #7 и check catalog | B00 | M | Owner review disabled workflow; tests не дают права runtime activation. |
| B02 | Native Broker: authenticated execution authority | B01 | L | Independent authority review+negative OS evidence, production still disabled до B07. |
| B03 | Protected source materializer и exact toolchain/executable identity | B02 | L | Verified immutable tree+filesystem/exe authority proofs; no host-global dependency installs этим PR. |
| B04 | Native containment, WFP, cross-session ACL и USER32/crash qualification | B02; B03 | L | Independent physical-host evidence каждой обязательной границы; mocks/config readback недостаточны. |
| B05 | Trusted receipts и безопасное collect/publish separation | B03; B04 | L | Independent receipt security and artifact lineage review; no API spending. |
| B06 | Квалифицировать физические Windows runners и включить только безопасные CI checks | A02; B05 | L | Independent runner qualification + owner-approved CI switch, dispatcher enabled remains false. |
| B07 | Контролируемый canary и production activation dispatcher | B06 | S | Independent security reviewer + explicit owner approval; agent не назначает VERIFIED и не делает merge. |


S — узкое изменение; M — несколько связанных контрактов; L — нативная или платформенная интеграция с проверкой отказов; XL — крупный этап испытаний, который нужно разбить на PR по операциям и профилям. Это оценки объёма при указанных предпосылках, а не обещание календарных сроков.

## 15. Milestones and Critical Path

| Этап | Критерий завершения | Блокирующие условия / параллельность |
|---|---|---|
| M0. Достоверная основа плана | Этот проверенный комплект: согласованы 112 строк, все 9 PR, 2 Issues, реестры тестов, риски и зависимости | Завершена проверка только артефактов плана; реализация не принята |
| M1. Логическая основа в main | A00/A01; 45 тестов и все корневые проверки на точном новом SHA; рецензия владельца | Ошибка PR11 и ручное разрешение на слияние; B00 можно готовить параллельно |
| M2. Один настоящий доверенный кадр | A02/A03: публичная точка входа, физический Windows/GPU, начальная привязка стенда и порядок освобождения ресурсов; решение GO | Нет квалифицированного физического профиля или точки входа — NO-GO/NOT_RUN; оформление UI отложено |
| M3. Минимальные защищённые механизмы приложения | A04/A05, затем A06 и A07 | Журнал до изменения состояния; источник кадров до просмотра; инфраструктурная линия B проектируется независимо |
| M4. Первый PoC двух сессий | A08: два настоящих приложения, клиенты и процессы проверки; чужая сессия, устаревание, неизвестный результат, авария и освобождение ресурсов | M1 → M2 → A04 → A05 → (A06 \|\| A07) → A08 — кратчайший путь к полному PoC |
| M5. Прикладные адаптеры | A09: просмотр; A10: процессы проверок и свидетельства; A11: MCP; затем A12: Runner | Только подтверждённые API и данные; без второго реестра или общей инфраструктуры планировщика |
| M6. Полная приёмка продукта | A13: все 112 операций, неизменённые наборы тестов, нативные GUI/GPU, отказы и безопасность | Недоказанные эквиваленты физического ввода и сочетания версий блокируют утверждение полного паритета |
| MI. Квалификация инфраструктуры | B00 → B01 → B02 → B03 → B04 → B05 → B06 | P0: полномочия, WFP, USER32, исходники, свидетельства и физический хост; отдельно от среды приложений |
| MA. Включение под контролем владельца | B07: независимая рецензия, бюджет владельца и один пробный запуск | Автоматическое включение запрещено; успешный CI или вызов модели не равен M6 |


Эксперимент с одним приложением предшествует полноценному PoC двух приложений: он уточняет порядок реализации, сохраняя исходную цель. До механизмов владения процессами, авторизации, журнала команд и доверенного источника кадров нельзя доказать безопасность двух управляемых сессий. Минимальный объём ограничен доверенными тестовыми приложениями и существующими публичными точками интеграции. Оформление MCP, особенности поставщиков и общая инфраструктура расширений не включаются в критический путь.

## 16. CI and Acceptance Gates

Корневой workspace, отдельный Broker, Node и живые проверки имеют разные области применения. **Нельзя использовать GitHub-hosted runner на VM, Docker, WSL/WSLC, Hyper-V или исполнение в VM.** Автоматическое исполнение недоверенных PR отключено до независимой квалификации физического runner. Метки workflow и флаги сами по себе ничего не доказывают. Для рассмотренных исходников допустимы отдельно разрешённые ручные запуски с точной привязкой к коду; их свидетельства не считаются статусом GitHub CI.

| Проверка | Точная команда | Область / толкование |
|---|---|---|
| G-ROOT-01 | cargo metadata --format-version 1 --locked | Полный граф зависимостей; --offline только после проверки наличия кеша. |
| G-ROOT-02 | cargo fmt --all -- --check | Только собственный workspace; исходные внешние проекты не форматировать. |
| G-ROOT-03 | cargo check --workspace --all-targets --locked | Компиляция всех целей сборки, а не приёмка исполнения. |
| G-ROOT-04 | cargo test --workspace --all-targets --locked | Сохранить все именованные тесты; --no-fail-fast допустим для полной диагностики, не для сокрытия FAIL. |
| G-ROOT-05 | cargo clippy --workspace --all-targets --locked -- -D warnings | Не добавлять подавление предупреждений вместо исправления соответствующих исходников. |
| G-ROOT-06 | cargo build --workspace --locked | Артефакт debug-сборки не доказывает работу просмотра. |
| G-ROOT-07 | cargo build --workspace --release --locked | Обязательная проверка этапа один раз после узких проверок, а не после каждой правки. |
| G-ROOT-08 | git diff --check <reviewed-base> HEAD | Проверяет реальные предлагаемые изменения, а не только пустую разницу рабочего дерева. |


Тяжёлые команды Cargo выполнять последовательно. Сначала — именованный или модульный тест изменённого компонента, затем — интеграция с потребителями, после этого — обязательные проверки этапа. Lockfile и закреплённые версии сохраняются; offline возможен только с заранее заполненным кешем. Отсутствие зависимости, toolchain или профиля явно даёт BLOCKED/NOT_RUN и не разрешает молчаливый пропуск. Новый SHA после слияния требует повторной проверки кода. Более поздний коммит только с документацией связывается с проверенным кодом через точное сравнение Git blobs, а не через текст описания коммита.

| Проверка отдельного Broker | Команда | Толкование |
|---|---|---|
| G-BRK-01 | cargo metadata --manifest-path native-check-broker/Cargo.toml --format-version 1 --locked | Граф зависимостей отдельного проекта. |
| G-BRK-02 | cargo fmt --manifest-path native-check-broker/Cargo.toml -- --check | Форматирование исходников. |
| G-BRK-03 | cargo check --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --locked | Производственный профиль с отказом по умолчанию. |
| G-BRK-04 | cargo test --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --locked | 20 исторических тестов профиля по умолчанию; повторить на новом точном SHA. |
| G-BRK-05 | cargo check --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --features native-probes --locked | Feature фиксированного тестового стенда Windows. |
| G-BRK-06 | cargo test --manifest-path native-check-broker/Cargo.toml --features native-probes --lib --locked -- --test-threads=1 | 24 исторических теста библиотеки; они не дают производственных полномочий. |
| G-BRK-07 | cargo test --manifest-path native-check-broker/Cargo.toml --features native-probes --test native_windows --locked -- --test-threads=1 | Исторически: 10 активных PASS и 2 ignored NOT_RUN; общая нативная приёмка — BLOCKED. |
| G-BRK-08 | cargo clippy --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --all-features --locked -- -D warnings | Обязательная будущая строгая проверка lint; текущий статус NOT_RUN при отсутствии привязанных свидетельств. |
| G-BRK-09 | cargo build --manifest-path native-check-broker/Cargo.toml --workspace --locked | Бинарные файлы профиля по умолчанию. |
| G-BRK-10 | cargo build --manifest-path native-check-broker/Cargo.toml --workspace --all-features --release --locked | Артефакт этапа; сама сборка не запускает тестовый процесс. |


Будущий fixture-пакет не входит в семь корневых members и не должен оставаться непроверенным из-за зелёного root workspace:

| Проверка standalone fixture | Команда | Толкование |
|---|---|---|
| G-FIX-01 | cargo metadata --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --format-version 1 --locked | Будущий standalone fixture: свой [workspace]/lock и exact Makepad pin; не покрывается root metadata. |
| G-FIX-02 | cargo check --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --all-targets --locked | Проверка public app entry/readback hooks; не запуск приложения. |
| G-FIX-03 | cargo test --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --all-targets --locked | Только имеющиеся fixture unit cases. Нулевой suite не подтверждает GPU; T-X12 остаётся отдельной живой проверкой. |


Проверка Node:

~~~text
node --test scripts/codex-issue/test/dispatcher.test.mjs
~~~

Сохранить 80 тестовых случаев; добавить негативные проверки каталога, свидетельств и полномочий. Workflow проверять закреплённым валидатором YAML/actionlint без вызовов модели. Если валидатор не установлен, результат — NOT_RUN; его установку необходимо разрешить отдельно. Скрытое скачивание недопустимо. Фактическое исполнение workflow движком GitHub — NOT_RUN.

| Проверка со свидетельствами | Область исполнения | Критерий приёмки |
|---|---|---|
| G-NATIVE-01 | Квалификация защиты процессов, каналов, ACL, сети, исходников и свидетельств | B02–B06; точный физический хост и рецензент безопасности; все обязательные доказательства без имитаций. |
| G-GPU-01 | A03: сравнение A/B с одним дочерним процессом; A08: настоящие кадры, действия и освобождение ресурсов двух приложений | Физические GPU, драйвер и профиль; настоящее чтение кадра, состояния и работоспособности; доказательство отсутствия запрещённого ввода. |
| G-VIEWER-01 | A09: приёмка выбранного нативного кадра и UI | Собственный рабочий стол просмотра и трасса рендеринга; без зависимости от рабочего стола пользователя. |
| G-TOOLKIT-01 | 112 проверок операций и полные неизменённые профили Script/Scheduler/reliability/evidence | Нужны точный SHA Toolkit .deps и сочетание параметров среды; файлов примеров недостаточно для полной приёмки. |
| G-ACTIVATE-01 | Независимое одобрение, бюджет и включение владельцем, один разрешённый пробный запуск | Только после B07; сейчас BLOCKED; enabled, Secrets и политики main на этом этапе не менять. |


Независимый проверяющий подтверждает точные запрос, исходники, проверку, профиль и идентичность; реальные байты и хеши артефактов; итог тестов, работоспособность, постусловия, освобождение ресурсов и отсутствие пропущенных обязательных проверок. Агент-исполнитель не вправе самостоятельно переводить GOAL в VERIFIED. Нынешние 80 тестов Node, 44 теста Rust и пробы отдельных возможностей не разрешают производственное включение.

## 17. Blockers and Explicit Decisions Required

| ID | Решение | Условие / кто подтверждает |
|---|---|---|
| D01 | Исправленный #11 включить в #10, затем вручную принять #10; только после этого закрывать #1–#4 как заменённые. | Предлагаемый порядок; требует отдельного owner разрешения на изменения/merge. |
| D02 | Первый rendering candidate — app-owned RenderBGRAu8/readback + protected pipe; hosted Windows path оставить comparative spike. | Условное решение до A03 real GPU/entry/channel GO; если B public hook невозможен, NO-GO и reviewed alternative, не SDK fork. |
| D03 | Freeze Toolkit .deps Makepad SHA и platform tuple; не считать локальный path совместимым с MSS pin. | Технический external prerequisite для full Toolkit acceptance; owner должен предоставить/одобрить точный baseline, либо tuple впервые проверяется как новый. |
| D04 | GUI-capable trusted runtime profile и hardened CheckBroker execution profile — разные authorities/qualifications. | Не ослаблять Win32k/token/USER32 требования broker ради Makepad; несовместимость означает отдельный design review/NO-GO. |
| D05 | Для первых native probes только trusted fixed fixtures и deterministic agent clients; не real model/agent-generated code. | Любые Windows app runs требуют отдельной задачи/разрешения и physical profile; paid APIs только после отдельного budget approval. |
| D06 | CI gates mandatory, automatic PR execution disabled до qualified physical-worker boundary. | Сейчас можно source-bound manual evidence от reviewed sources; это не автоматический CI PASS. |
| D07 | Не создавать второй GOAL registry и не автоматически делать GOAL из Issue6/8; согласовать ID/scope/dependencies в существующей schema. | Сохранять MSS001…004/историю; VERIFIED только независимая процедура, не агент. |
| D08 | Exact executable/dependency/profile/receipt changes требуют пересогласования pins; hashes сами не security authority. | Host setup/Secrets/runner registration/branch protection остаются ручными owner действиями, не частью этого плана. |
| D09 | Если любой Toolkit physical/global/window scenario невозможно повторить разрешённым методом с полным контрактом, сохранить UNSUPPORTED/BLOCKED. | Нельзя ослабить target112; scoped prototype допустим как prototype, но full acceptance не выдаётся. |
| D10 | Монитор MSS остаётся PAUSED; этот план не permission на Issue execution, dispatcher activation или дальнейшую реализацию. | Никаких автоматических follow-ups или GitHub writes не настроено. |


Необходимые внешние условия: квалифицированный физический Windows-хост, GPU и профиль исполнения; независимо подготовленные идентичности службы и процессов исполнения, ACL и WFP; закреплённая локальная версия SDK Toolkit; рассмотренные зависимости MCP/SDK; защищённые toolchain, исходники и полномочия на свидетельства. Владелец задаёт обязательных рецензентов, перечень runner, Secrets и бюджет API. В этой фазе перечисленные настройки не менялись. Если формальный контракт технически несовместим с запретами, следует зафиксировать NO-GO и отдельное решение по проекту; превращать этот результат в PASS нельзя.

Первый пакет реализации сейчас блокируют тестовые строки и форматирование PR #11. Производственное включение блокируют нативные полномочия, USER32, WFP, защита исходников, свидетельств и хоста. Отсутствующий код нельзя заменять PASS на имитации. Выключенный мониторинг не возобновлять; этот план не разрешает забирать Issue в работу или запускать Codex без участия владельца.

## 18. First Executable Work Package

**W01/A00 — минимальная поправка существующего PR #11**, только после отдельного разрешения владельца. Входные данные: текущий 192b81a и сохранённый FAIL. Объём: тестовые строки в MSS_Remote/src/lib.rs, строка 352, и rustfmt. Не менять защитную проверку, утверждения тестов, NotDispatched, авторизацию, последовательности или SDK. Ожидаемый результат — корректная тестовая строка Unicode. Сначала выполнить именованный регрессионный тест, затем проверки Remote, всего workspace, форматирования исходников, check, Clippy и обязательные интеграционные проверки этапа. Результат привязать к новому точному SHA и свидетельствам; исходный FAIL сохранить в истории.

Десять конкретных задач с входными данными, точными изменениями, тестами, ожидаемым результатом и критериями завершения приведены в [first-ten-tasks.md](first-ten-tasks.md) и [машиночитаемом JSON](first-ten-tasks.json). Повторная полная инвентаризация для них не требуется, однако перед изменениями исполнитель обязан заново проверить базовый SHA, разрешённый объём и предпосылки.

### W01. Исправить ровно fixture/format дефект PR11

| Параметр | Значение |
|---|---|
| Целевой PR | A00 |
| Входные данные | PR11 head192b81a, source line352, existing failing test/summary.json |
| Точные изменения | Две Unicode строки single Rust escape; rustfmt MSS_Remote; сохранить имя/assertions и refusal behavior. |
| Проверки | Named regression; Remote lib; root metadata/fmt/check/test alltargets/Clippy; no fail-fast нужен для полного failure report. |
| Ожидаемый результат | 45 tests PASS/0fail/0ignored +fmt PASS на новом exact SHA. |
| Критерии завершения | Новый source-bound record, diff только reviewed fixture/fmt; никаких transport/SDK изменений. |

### W02. Собрать проверенный integration acceptance diff

| Параметр | Значение |
|---|---|
| Целевой PR | A01 |
| Входные данные | Исправленный W01 + PR10 source heads4/currentmain snapshot |
| Точные изменения | Owner-approved nonrewriting merge #11→#10; refreshdocs/evidence; ancestor tests всех4heads. Сам merge вmain делает владелец. |
| Проверки | Все7Cargo commands+diffserial, test inventory assertions preserved, code-vs-doc hashes. |
| Ожидаемый результат | Один reviewable integration SHA с45 tests и exact source lineage. |
| Критерии завершения | Draft ready, исходные PR не переписаны; main неизменён до отдельного owner merge; old evidence retained. |

### W03. Закрепить инвентари и минимальный static plan/contract validator

| Параметр | Значение |
|---|---|
| Целевой PR | A02 |
| Входные данные | Этот bundle, raw112catalog/schema/source manifests, existing8SKLT |
| Точные изменения | Добавить reviewed manifests/ref integrity tests в verification/ и minimal docs; objectIDs прежние; дописать Remote/Render direct API dependency declarations. |
| Проверки | 112 set equality/schema/caps; testnames+sourceIDs; DAG/no unknown refs; SKLT graph drift. |
| Ожидаемый результат | Воспроизводимый source-only baseline, не runtime PASS. |
| Критерии завершения | Validator запускается без model/GPU/network/install, все ссылки/колонки присутствуют; no GLIF/adoption. |

### W04. Согласовать конкретный Windows qualification profile/ADR

| Параметр | Значение |
|---|---|
| Целевой PR | A03 |
| Входные данные | Makepad130be pinned Windows sources/runtime appendix + hard constraints |
| Точные изменения | Новый doc/windows-feasibility.md: точный app entry/readback/hot-reload-off/token/desktop/profile; A/B risks, exact budgets, prerequisites и forbidden calls. |
| Проверки | Static named source refs, no user-desktop/global-input imports/call paths; recipe dry review без запуска. |
| Ожидаемый результат | Одно минимальное проверяемое candidate решение или source-level NO-GO. |
| Критерии завершения | Все prerequisites проверяемы; отсутствие GPU/env остаётся NOT_RUN; никаких host изменений. |

### W05. Создать минимальный trusted app-owned frame fixture

| Параметр | Значение |
|---|---|
| Целевой PR | A03 |
| Входные данные | Approved W04, Makepad pin, public texture readback refs,7crate interface |
| Точные изменения | Opt-in fixture в MSS_SDK/tests/fixtures/native_frame_app: два поля, counter, nonce region, RenderBGRAu8 readback ticket; disabled network/dialog/plugins/hot-reload; no SDK copy. Вложенный fixture Cargo.toml содержит standalone [workspace], exact Makepad revision и собственный lockfile; не добавлять его неявно в root workspace. |
| Проверки | Targeted fmt/check и synthetic adapter contracts; live frame gate отдельно в W06. Отдельные cargo metadata/check/test --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --locked; root checks не заменяют это. Public entry/readback Signal ticket drain проверять источником, не обещать по имени Texture. |
| Ожидаемый результат | Source-reviewed fixture с явным Unsupported если public producer hook недоступен. |
| Критерии завершения | No upstreammods/globalinput; no fabricated pixels/capture success; ограниченные memory/frame specs. |

### W06. Первый контролируемый Windows app-origin frame experiment

| Параметр | Значение |
|---|---|
| Целевой PR | A03 |
| Входные данные | W05 + отдельно owner-approved физический Windows/GPU/run profile; fixed-fixture retained-handle/Job/bootstrap harness, ещё не production ProcessLease/API auth. |
| Точные изменения | Harness запускает только exact fixturebinary own Job/private object, измеряет30frames/nonce/readback/health/cleanup; source/OS/driver/pins/time в evidence. На этом этапе только read/capture и self-driven nonce, внешняя mutation закрыта до A06; обязательный named B case T-X12. Shared A tests только если выбран A, иначе честный NO-GO/NOT_RUN. |
| Проверки | Good frame + wrongbinding + capturetimeout + normal/Job cleanup; hosted comparative cases only if admitted. |
| Ожидаемый результат | GO либо конкретный NO-GO; никакого user desktop fallback. |
| Критерии завершения | Every PASS real renderer/process observation; no app started без run authorization; absent prerequisites NOT_RUN. |

### W07. Минимальный Core ProcessLease/epoch owner

| Параметр | Значение |
|---|---|
| Целевой PR | A04 |
| Входные данные | W04/W06 proof, currentCore API, broker primitive patterns reviewed как reference |
| Точные изменения | MSS_Core/windows owner module: epoch, retainedhandles, image/birth identity, suspendedJoblaunch, own-only cleanup/quarantine; dependency review exact Windows pin first. |
| Проверки | Generation/PID/image mismatch, assignmentfailure, childdeath, neighborpreservation; existing16Core tests. Runtime-profile inherited-handle canary T-X11 отдельно от broker profile. |
| Ожидаемый результат | Own process нельзя перепутать с logicalID/соседом. |
| Критерии завершения | Native evidence on approvedprofile; Core прежние publiccontracts preserved, no blanket foreign process access. |

### W08. Read-only authenticated SDK/API channel

| Параметр | Значение |
|---|---|
| Целевой PR | A05 |
| Входные данные | W07 ProcessLease, W05fixture, RequestContext auth-first contract |
| Точные изменения | Protected namedpipe handshake peeridentity+launchcapability; app-provided capabilities/state; derivingprincipal->context; disable rawRemoteHTTP. |
| Проверки | Wrongprincipal/PID/nonce/generation/targetcap, direct-port bypassnegative; no mutation route beforeledger. |
| Ожидаемый результат | Один actual read/frame producer связан с exact own app, forged requests denied. |
| Критерии завершения | No secretslogs; no secondregistry; unsupported actions explicit; actual channel deny not gateway-only mock. |

### W09. Reserved/dispatched/observed/unknown ledger до первой mutation

| Параметр | Значение |
|---|---|
| Целевой PR | A06 |
| Входные данные | W08 authenticated contexts + proposed requesttuple/generation |
| Точные изменения | Small bounded per-session ledger атомарно reserve; commandseq/duplicate/refusal/cancel/outcome; independent fixture counterread. В scope включён SDK trusted fixture action/counter+observer после ledger reserve для реального lost-reply case; до reserve никакой app mutation. |
| Проверки | Tworequests race, wronggeneration, seqMAX, lostreplyaftereffect, workerloss, cancel phases. |
| Ожидаемый результат | Не более одного effect и no automatic unknown replay. |
| Критерии завершения | Property/race+native fault cases source-bound; existingRemote NotDispatched path unchanged without executor. |

### W10. Первая безопасная registry/disabled-dispatcher reconciliation

| Параметр | Значение |
|---|---|
| Целевой PR | B00 |
| Входные данные | PR5baseb455/currentmain83 + PR7policy/catalog + infraaudit |
| Точные изменения | Разрешить только AGENTS overlap с сохранением строгих правил main/Cargo.lock; сохранить GOAL IDs, описатьstale refs; отдельныйпланcatalogNode/broker exactchecks, no enablement. |
| Проверки | Schema/GOAL/source/dependency validator; future B01 retain80model-free tests; enabledfalse/noVERIFIED. |
| Ожидаемый результат | Проверяемый diff реестра без потериconstraints и duplicateGOAL system. |
| Критерии завершения | Owner-controlled sourceupdateapproval; no Secrets/runner/dispatcher/main switch, all blocked prerequisites retained. |


---

Приложения входят в единый план. Полноту, ссылки, хеши и граф зависимостей проверяет локальная команда **node validate-plan.mjs**. Это проверка артефактов, а не запуск MSS или Toolkit. Существующие проектные тесты на различных SHA исходников не перезапускались. Синтаксис Mermaid здесь рассмотрен вручную по исходному тексту; разбор и отображение имеют статус NOT_RUN, поскольку парсер не установлен. Публикация в GitHub, Pages или PR не выполнялась.

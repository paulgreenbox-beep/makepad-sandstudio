import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {revisions as R,source,evidence,invariants,tests} from './plan-core.mjs';
import {backlog,risks,tasks,decisions} from './plan-backlog.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const save=(p,d)=>fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');
const snapshot=read('repository-snapshot.json'), runtime=read('runtime/runtime-test-inventory.json'),infra=read('infrastructure/infra-test-inventory.json'),parity=read('toolkit/toolkit-parity.json'),tkTests=read('toolkit/test-inventory.json');
const lastRecheck=fs.existsSync('final-github-recheck.json')?read('final-github-recheck.json'):null;
const cell=x=>String(Array.isArray(x)?x.join('; '):(x??'—')).replace(/\r?\n/g,'<br>').replace(/\|/g,'\\|').replace(/https:\/\/[^\s<>]+/g,u=>`[источник](${u})`);
const table=(headers,rows)=>'| '+headers.join(' | ')+' |\n|'+headers.map(()=>'---').join('|')+'|\n'+rows.map(r=>'| '+r.map(cell).join(' | ')+' |').join('\n')+'\n';
const link=(label,file,rev=R.integration,line)=>`[${label}](${source(file,rev,line)})`;
const invSummary=Object.fromEntries(['PASS','FAIL','BLOCKED','NOT_RUN','NOT_VERIFIED'].map(s=>[s,invariants.filter(i=>i.status===s).length]));
fs.mkdirSync('evidence',{recursive:true});
const checkout=path.resolve('..','mss-integration-pr1-4');
for(const [rev,p,out] of [
 [R.integration,'doc/cronica/20261030-integration-pr1-4.json','pr10-integration.json'],
 ['6998cef53077eab021f129e583d4979e2e70e297','doc/cronica/20261030-core-pr1.json','pr1-core.json'],
 [R.broker,'native-check-broker/evidence/20261030-crash-user32.json','pr9-crash-user32.json'],
 [R.dispatcher,'goals/events/MSS-004-20261030121543-CODEX_DISPATCH_TESTS.json','pr7-dispatcher-manual.json']
]) fs.writeFileSync('evidence/'+out,execFileSync('git',['show',rev+':'+p],{cwd:checkout}));
for(const [p,out] of [['../mss-pr11-windows-evidence-192b81a/summary.json','pr11-windows-summary.json'],['../mss-pr11-windows-evidence-192b81a/report.md','pr11-windows-report.md']]) fs.copyFileSync(p,'evidence/'+out);
// Plan data is independent from the immutable historical development evidence.
const evidenceAlias={...evidence,remote:'evidence/pr11-windows-summary.json'};
for(const i of invariants)if(i.evidence===evidence.remote)i.evidence=evidenceAlias.remote;
save('invariants.json',{schema:'mss-master-invariants-v1',as_of:snapshot.captured_at,scope:'Current statuses are scoped to cited logical/model/native-fixture evidence; not whole product acceptance',invariants});
save('proposed-tests.json',{schema:'mss-master-proposed-tests-v1',execution_during_planning:false,tests});
save('pr-backlog.json',{schema:'mss-master-pr-backlog-v1',created_or_modified_prs:0,backlog});
save('risks-and-decisions.json',{schema:'mss-master-risk-decisions-v1',risks,decisions});
save('first-ten-tasks.json',{schema:'mss-first-work-packages-v1',authorization:'Plan only; every implementation/host run/merge requires separate owner grant',tasks});
const combined={schema:'mss-complete-test-inventory-index-v1',scope:'Named MSS cases across different unmerged branches, never a single integrated test run; Toolkit declarations listed separately',current_main_behavioral_tests:0,mss_unique_named_cases:runtime.tests.length+infra.tests.length,runtime_unique_cases:runtime.tests.length,infra_unique_cases:infra.tests.length,runtime_inventory:'runtime/runtime-test-inventory.json',infrastructure_inventory:'infrastructure/infra-test-inventory.json',toolkit_inventory:'toolkit/test-inventory.json',toolkit_counts:tkTests.counts,scenario_registry:'toolkit/scenario-registry.json',test_reruns_during_planning:0};
save('existing-tests-index.json',combined);

const modules=[
 ['MSS_Core','Status NotImplemented','1,10','Логические RegistryId/AgentId/SessionId с областью действия; поколение, владелец, выбор и закрытие','Core: 12 тестов в #1, 16 в #10/#11; только логическая модель','Эпоха исполнения, ProcessLease, запуск, Job, идентичность, жизненный цикл и восстановление','std; только API потребляет полномочия Core','P0: внешняя идентичность и время жизни','P1',source('MSS_Core/src/lib.rs')],
 ['MSS_API','Каркас статуса','2,10','Заимствованный реестр Core; авторизация до отказа по классу или имени; отмена до допуска','6 модульных тестов PASS в #10/#11','Внешняя идентичность, разрешения операций, настоящие исполнители, работоспособность, свидетельства и сетевой протокол','Core; без дублирования реестра','P0: подмена вызывающей стороны при прямом внешнем доступе','P1',source('MSS_API/src/lib.rs')],
 ['MSS_Remote','Каркас статуса','3,10,11','Типизированные Read/Focus/Text с проверкой формата и лимитов; всегда NotDispatched; проверка краевых пробелов в #11','5 PASS + 1 FAIL в #11; форматирование — FAIL','Аутентифицированный канал приложения, семантическая цель/WidgetId, защита от повторов, результат и чтение состояния','API/Core','P1: неуспешный тест; P0 до первого нативного изменения состояния','P1',source('MSS_Remote/src/lib.rs',R.remote)],
 ['MSS_Render','Каркас статуса','4,10','Авторизованный кеш переданных PNG; точные ID, последовательности и освобождение ресурсов; ограниченный декодер и квоты','9 модульных и 8 публичных композиционных тестов PASS в #10/#11; синтетические данные','Аутентификация источника, захват, время и эпоха рендерера, поток, обратное давление и реальный бюджет памяти','API/Core; закреплённый zune; Remote только для разработки','P0: нет доверенного источника; P2: ограничения декодера и профиля','P1',source('MSS_Render/src/lib.rs')],
 ['MSS_SDK','Каркас статуса','Нет реализации','Только ImplementationStatus','0 поведенческих тестов','Явно подключаемые канал приложения, разрешения, состояние, действия, работоспособность и источник кадров','Зависимостей Cargo пока нет; API запланирован в SKLT','P1: нет границы доверия приложения','P1',source('MSS_SDK/src/lib.rs')],
 ['MSS_MCP','Каркас статуса','Нет реализации','Только ImplementationStatus','0 поведенческих тестов','Стандартные жизненный цикл MCP, авторизация и инструменты поверх API; совместимость клиентов','Зависимостей пока нет; API запланирован','P1: не допустить второго реестра и политики','P3',source('MSS_MCP/src/lib.rs')],
 ['MSS_Desktop','Иллюстративная оболочка Makepad','#10 наследует исходники main','Кнопки, подписи и заглушка отсутствующего кадра; связи с backend нет','Скомпилирован в #10; GUI NOT_RUN; 0 поведенческих тестов','Настоящие список сессий, кадры, статусы, ошибки, отмена и владение ресурсами через API','Точный Makepad 130be; API/Render запланированы','P2: статический просмотр может создать ложное впечатление приёмки','P2',source('MSS_Desktop/src/main.rs')],
 ['MSS_Skills','README + SKLT','Нет устанавливаемого пакета','Только инструкции; нет полномочий инструментов или учётных данных','Только чтение исходников','Версионируемые безопасные примеры разрешений, сессий, API и MCP','Запланированы API/MCP','P3: расхождение инструкций с реализацией','P3',source('MSS_Skills/README.md')],
 ['GOAL Registry','Отсутствует','#5; унаследован в #7/#9','Схема, манифест, каталог и события MSS001…004; статусы и зависимости','Статические исходники; нужен новый валидатор; ссылки исторические','Разрешить конфликт AGENTS; утвердить GOAL и объём Issues 6/8; согласовать каталог','Только существующий формат; ID SKLT сохраняются','P1: устаревшие свидетельства, исходники и команды','P1',source('goals/manifest.json',R.broker)],
 ['Codex Dispatcher','Отсутствует','#7; унаследован в #9','Авторизация события владельца, объём, резервирование задачи, ветка, свидетельства и Draft PR; политика отключена','80 именованных тестов без модели — PASS; реальные Actions — NOT_RUN','Квалификация runner, broker и полномочий; недостающая команда проверки, формат свидетельств и отделение collect','GOAL 5 → Broker 9; секрет OPENAI не устанавливается планом','P0: неквалифицированное исполнение при включении','P1',source('scripts/codex-issue/policy.mjs',R.dispatcher)],
 ['Native Check Broker','Отсутствует','#9 / Issue 8','Строгий протокол; производственная точка входа всегда блокирует; нативные пробы отдельно','39 именованных тестов Rust: 37 PASS / 2 NOT_RUN; только примитивы и стенды; USER32 заблокирован','Квалификация производственных вызывающей стороны, подготовки исходников, идентичностей, ACL, WFP, свидетельств и квот','Отдельный Cargo workspace; PR7/5; независимый физический хост','P0: производственные проверки не завершены','P0',source('native-check-broker/src/main.rs',R.broker)]
];
save('component-inventory.json',{schema:'mss-component-inventory-v1',modules:modules.map(([module,current_main,existing_pr,implementation,verification,missing_code,dependencies,risk,priority,source])=>({module,current_main,existing_pr,implementation,verification,missing_code,dependencies,risk,priority,source}))});

const invMd='# Формальный каталог инвариантов\n\nСтатусы относятся к узкой указанной границе, не ко всему MSS. У каждого правила есть фальсифицирующая проверка. Будущие тесты не исполнялись.\n\n'+table(['Invariant ID','Formal Rule','Existing Implementation','Violation Scenario','Required Test','Evidence','Status'],invariants.map(i=>[i.id,i.formal_rule,i.existing_implementation,i.violation_scenario,i.required_tests,i.evidence,i.status]));
fs.writeFileSync('invariant-catalog.md',invMd);
fs.writeFileSync('missing-tests.md','# Недостающие/расширяемые проверки\n\nВсе строки — будущая работа, **NOT_RUN**. Наличие existing похожего теста не даёт новому SHA PASS.\n\n'+table(['Test ID','Component','Scenario','Preconditions','Expected Result','Execution Environment','Evidence','Priority','Target PR'],tests.map(t=>[t.id,t.component,t.scenario,t.preconditions,t.expected_result,t.execution_environment,t.evidence_required,t.priority,t.target_pr])));
fs.writeFileSync('ordered-pr-backlog.md','# Упорядоченный PR backlog\n\nВсе пакеты — предложения. PR/branches не создавались; существующие ветки не менялись. Имена A/B — planning IDs, не новые GOAL IDs. Приоритет/зависимости/merge gates обязательны. Оценки S/M/L/XL условны, не сроки.\n\n'+backlog.map(p=>`## ${p.id} — ${p.title}\n\n`+table(['Поле','Значение'],[['Goal',p.goal],['Base',p.base],['Depends On',p.depends_on.length?p.depends_on:'—'],['Files',p.files],['Required Code',p.required_code],['Invariants',p.invariants],['Tests',p.tests],['Acceptance',p.acceptance],['Risks',p.risks],['Size',p.size+' — '+p.size_assumptions],['Merge Gate',p.merge_gate],['Regressions',p.regression_risks]])).join('\n'));
fs.writeFileSync('first-ten-tasks.md','# Первые десять инженерных задач\n\nЭто готовые work packages, а не разрешение исполнять их в рамках PLAN FIRST. Новая owner задача должна назвать пакет/approved scope. Никаких автоматических Issues/веток/PR.\n\n'+tasks.map(t=>`## ${t.id} — ${t.title}\n\n`+table(['Поле','Значение'],[['Target PR',t.target_pr],['Входные данные',t.inputs],['Точные изменения',t.exact_changes],['Инварианты',t.invariants],['Тесты',t.tests],['План проверок',t.test_plan],['Ожидаемый результат',t.expected_result],['Definition of Done',t.definition_of_done]])).join('\n'));

let existing='# Существующие тесты: полный реестр MSS\n\n**Не единый test run.** Разные неслитые source деревья и разные уровни evidence. 164 именованных случая =45 runtime +119 infrastructure. Toolkit имеет отдельный declaration inventory; его suite здесь NOT_RUN. Подробные cfg/ignore/blob/log hashes в JSON.\n\n## Runtime по каждой ревизии\n\n';
const runtimeRows=[];
for(const t of runtime.tests)for(const rev of t.revisions)if(rev.present) runtimeRows.push([t.harness_name,rev.path+':'+rev.line,rev.source_sha,rev.result,t.evidence_level,rev.result_source??rev.note]);
existing+=table(['Exact Test Name','Location','Source SHA','Result','Evidence Level','Result Reference'],runtimeRows);
existing+='\n## Standalone Broker и dispatcher\n\n'+table(['Exact Test Name','Location','Source SHA','Result','Evidence Level','Evidence'],infra.tests.map(t=>[t.name,t.file+':'+t.line,t.source_commit,t.status,t.evidence_level,t.evidence?.published_file+' @ '+t.evidence?.published_at_commit+'; '+t.evidence?.log_sha256]));
existing+='\n## Toolkit baseline\n\nПолные **210 Rust +116 Node declarations** с точными file/line/source URL: [test-inventory.json](toolkit/test-inventory.json). Это declaration count, не число expanded/runtime cases; cfg/dynamic expansion не выполнялись. Все execution status NOT_RUN в этом аудите. Все checked-in сценарии: [44 пути](toolkit/scenario-registry.json), включая43v1 scripts и1suite;13 sample-not-run profiles не доказанная full execution suite. Существующие shell/runner/generated-script drivers тоже перечислены, не отброшены.\n';
fs.writeFileSync('existing-test-inventory.md',existing);

const rootGates=[
 ['G-ROOT-01','cargo metadata --format-version 1 --locked','Полный граф зависимостей; --offline только после проверки наличия кеша.'],
 ['G-ROOT-02','cargo fmt --all -- --check','Только собственный workspace; исходные внешние проекты не форматировать.'],
 ['G-ROOT-03','cargo check --workspace --all-targets --locked','Компиляция всех целей сборки, а не приёмка исполнения.'],
 ['G-ROOT-04','cargo test --workspace --all-targets --locked','Сохранить все именованные тесты; --no-fail-fast допустим для полной диагностики, не для сокрытия FAIL.'],
 ['G-ROOT-05','cargo clippy --workspace --all-targets --locked -- -D warnings','Не добавлять подавление предупреждений вместо исправления соответствующих исходников.'],
 ['G-ROOT-06','cargo build --workspace --locked','Артефакт debug-сборки не доказывает работу просмотра.'],
 ['G-ROOT-07','cargo build --workspace --release --locked','Обязательная проверка этапа один раз после узких проверок, а не после каждой правки.'],
 ['G-ROOT-08','git diff --check <reviewed-base> HEAD','Проверяет реальные предлагаемые изменения, а не только пустую разницу рабочего дерева.']
];
const brokerGates=[
 ['G-BRK-01','cargo metadata --manifest-path native-check-broker/Cargo.toml --format-version 1 --locked','Граф зависимостей отдельного проекта.'],
 ['G-BRK-02','cargo fmt --manifest-path native-check-broker/Cargo.toml -- --check','Форматирование исходников.'],
 ['G-BRK-03','cargo check --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --locked','Производственный профиль с отказом по умолчанию.'],
 ['G-BRK-04','cargo test --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --locked','20 исторических тестов профиля по умолчанию; повторить на новом точном SHA.'],
 ['G-BRK-05','cargo check --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --features native-probes --locked','Feature фиксированного тестового стенда Windows.'],
 ['G-BRK-06','cargo test --manifest-path native-check-broker/Cargo.toml --features native-probes --lib --locked -- --test-threads=1','24 исторических теста библиотеки; они не дают производственных полномочий.'],
 ['G-BRK-07','cargo test --manifest-path native-check-broker/Cargo.toml --features native-probes --test native_windows --locked -- --test-threads=1','Исторически: 10 активных PASS и 2 ignored NOT_RUN; общая нативная приёмка — BLOCKED.'],
 ['G-BRK-08','cargo clippy --manifest-path native-check-broker/Cargo.toml --workspace --all-targets --all-features --locked -- -D warnings','Обязательная будущая строгая проверка lint; текущий статус NOT_RUN при отсутствии привязанных свидетельств.'],
 ['G-BRK-09','cargo build --manifest-path native-check-broker/Cargo.toml --workspace --locked','Бинарные файлы профиля по умолчанию.'],
 ['G-BRK-10','cargo build --manifest-path native-check-broker/Cargo.toml --workspace --all-features --release --locked','Артефакт этапа; сама сборка не запускает тестовый процесс.']
];
const nativeGates=[
 ['G-NATIVE-01','Квалификация защиты процессов, каналов, ACL, сети, исходников и свидетельств','B02–B06; точный физический хост и рецензент безопасности; все обязательные доказательства без имитаций.'],
 ['G-GPU-01','A03: сравнение A/B с одним дочерним процессом; A08: настоящие кадры, действия и освобождение ресурсов двух приложений','Физические GPU, драйвер и профиль; настоящее чтение кадра, состояния и работоспособности; доказательство отсутствия запрещённого ввода.'],
 ['G-VIEWER-01','A09: приёмка выбранного нативного кадра и UI','Собственный рабочий стол просмотра и трасса рендеринга; без зависимости от рабочего стола пользователя.'],
 ['G-TOOLKIT-01','112 проверок операций и полные неизменённые профили Script/Scheduler/reliability/evidence','Нужны точный SHA Toolkit .deps и сочетание параметров среды; файлов примеров недостаточно для полной приёмки.'],
 ['G-ACTIVATE-01','Независимое одобрение, бюджет и включение владельцем, один разрешённый пробный запуск','Только после B07; сейчас BLOCKED; enabled, Secrets и политики main на этом этапе не менять.']
];
const fixtureGates=[
 ['G-FIX-01','cargo metadata --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --format-version 1 --locked','Будущий standalone fixture: свой [workspace]/lock и exact Makepad pin; не покрывается root metadata.'],
 ['G-FIX-02','cargo check --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --all-targets --locked','Проверка public app entry/readback hooks; не запуск приложения.'],
 ['G-FIX-03','cargo test --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --all-targets --locked','Только имеющиеся fixture unit cases. Нулевой suite не подтверждает GPU; T-X12 остаётся отдельной живой проверкой.']
];
save('ci-gates.json',{schema:'mss-ci-gates-design-v1',execution_enabled:false,root:rootGates,broker:brokerGates,standalone_fixture:fixtureGates,node:[['G-NODE-01','node --test scripts/codex-issue/test/dispatcher.test.mjs','Сохранить все 80 случаев и добавить отрицательные проверки каталога/свидетельств.'],['G-WORKFLOW-01','Закреплённый YAML parser/actionlint либо эквивалентная проверка без модели; здесь ничего не устанавливается','Проверить trigger/actor, exact action SHA, права, timeouts, отсутствие merge/pull_request_target; исполнение GitHub engine — отдельный уровень.']],native:nativeGates});

const prShort=backlog.map(p=>[p.id,p.title,p.depends_on,p.size,p.merge_gate]);
const riskTable=table(['ID','Priority','Finding','Source','Mitigation / Invariants'],risks.map(r=>[r.id,r.priority,r.finding,r.source,r.mitigation+' '+r.invariants.join(', ')]));
const graph=`flowchart LR
  P11["#11 исправление тестовых строк"] --> P10["#10 принятая база; история #1-4 сохранена"]
  P10 --> A02["A02 контракты и проект отключённого CI"]
  A02 --> A03["A03 доверенный эксперимент Windows GPU"]
  A03 --> A04["A04 владелец процессов"]
  A04 --> A05["A05 аутентифицированные SDK/API"]
  A05 --> A06["A06 повторы и результат"]
  A05 --> A07["A07 доверенный поток кадров"]
  A06 --> A08["A08 PoC двух приложений"]
  A07 --> A08
  A08 --> A09["A09 Desktop"]
  A08 --> A10["A10 процессы проверок и свидетельства"]
  A08 --> A11["A11 MCP и SDK"]
  A10 --> A12["A12 неизменённый Toolkit runner"]
  A11 --> A12
  B00["B00 согласование существующего #5"] --> B01["B01 существующий #7 остаётся отключённым"]
  B01 --> B02["B02 полномочия #9"]
  B02 --> B03["B03 неизменяемые исходники"]
  B03 --> B04["B04 проверки ОС и USER32"]
  B04 --> B05["B05 доверенные свидетельства"]
  B05 --> B06["B06 квалификация физического CI"]
  A02 --> B06
  B06 --> B07["B07 пробный запуск только владельцем"]
  A09 --> A13["A13 полная приёмка продукта"]
  A12 --> A13
  B06 --> A13`;
fs.writeFileSync('dependencies.mmd',graph+'\n');

const body=`# MSS MASTER IMPLEMENTATION PLAN

Русский инженерный план. Срез: **${snapshot.captured_at}**. Режим **PLAN FIRST / аудит исходников**. Комплект содержит документацию, данные и локальные анализаторы. Файлы проекта, ветки, PR, исходные репозитории, Secrets, настройки runner и режим dispatcher не менялись. Новые сборки, проектные тесты, приложения с GUI и пробные вызовы модели не запускались. Мониторинг остаётся PAUSED.

Повторная сверка GitHub: **${lastRecheck?.rechecked_at??'NOT_RUN'}**, изменения относительно снимка: **${lastRecheck?.unchanged===true?'нет':'требуют анализа'}**. Подробности: [final-github-recheck.json](final-github-recheck.json).

## 1. Executive Summary

В main пока находится архитектурный каркас с иллюстративной оболочкой Makepad; логическая основа реализована в ещё не слитых PR. В PR #10 совместно проверены Core/API/Remote/Render: **44 теста Rust — PASS**. Процессы приложений, нативный ввод и захват кадров, MCP и исполнитель Toolkit ещё отсутствуют. PR #11 добавляет проверку адресов, однако на его точном SHA получены **44 PASS / 1 FAIL и fmt FAIL**: Unicode-символы в тестовых строках экранированы дважды. Источники: [свидетельства интеграции](evidence/pr10-integration.json), [результаты PR #11 на Windows](evidence/pr11-windows-summary.json), [место ошибки](${source('MSS_Remote/src/lib.rs',R.remote,352)}). Прежняя запись «PR11 NOT_RUN» уже не отражает текущий результат.

Имеются 80 тестов Dispatcher без вызовов модели и 37 активных именованных тестов Broker на Rust. При этом производственная точка входа **всегда BLOCKED**; два пропущенных нативных теста с невыполненными предпосылками остаются NOT_RUN, а обязательная проверка привязки USER32 — BLOCKED. [Исходник Broker](${source('native-check-broker/src/main.rs',R.broker)}) и [нативные свидетельства с привязкой к исходникам](evidence/pr9-crash-user32.json) не подтверждают полную безопасность нативного исполнения или приёмку Toolkit.

Кратчайший безопасный путь: исправить и проверить существующий PR #11 → принять PR #10 с сохранением истории → провести эксперимент с кадром от одного приложения на проверенных исходниках и хосте → добавить минимальные механизмы процессов, каналов, учёта команд и кадров → проверить **два настоящих процесса приложений**, два детерминированных процесса клиентов-агентов с раздельными учётными данными и независимые процессы проверки → затем подключить просмотр, MCP и полный Toolkit. Общая инфраструктура расширений и оформление оболочки не нужны на этом критическом пути.

Главная новая архитектурная находка: закреплённая версия Makepad уже содержит **Windows hosted D3D11** наряду с hosted-кодом для Linux. Однако WebSocket, build-ID, именованные поверхности, дескрипторы безопасности по умолчанию и игнорируемые результаты работы mutex не доказывают аутентификацию и восстановление MSS. Предпочтение первому варианту с принадлежащим приложению ReadBack и защищённым каналом pipe остаётся **условным** до фактического решения GO по A03. Если нет поддерживаемой публичной точки входа или результата GPU без зависимости от рабочего стола пользователя, требуется NO-GO. Скрытый обходной путь недопустим. [Полный аудит исходников и ссылки на Microsoft API](runtime/runtime-audit.md).

Комплект включает **112/112** операций, **54** инварианта с проверяемыми условиями нарушения, **${tests.length}** будущих сквозных проверок, ещё 112 групп приёмки отдельных операций, **22** связанных зависимостями пакета PR и 10 подготовленных инженерных задач. Все предлагаемые проверки исполнения имеют статус NOT_RUN. Локальный валидатор артефактов проверяет полноту и связность плана; он не проверяет работающую среду MSS.

## 2. Repository and PR Snapshot

Главная ветка: **${R.main}**. Все 9 указанных PR открыты как Draft и не слиты. GitHub сообщает о конфликте у PR #5; остальные допускают слияние относительно **своих баз**, которые могут отличаться от main. Это не означает одобрения PR или изменения их готовности. [Машиночитаемый снимок](repository-snapshot.json).

${table(['PR','Название','HEAD SHA','Base / SHA в ответе PR','Состояние / конфликт'],snapshot.prs.map(p=>['#'+p.number,p.title,p.head_sha,p.base+' / '+p.base_sha,p.state+'; Draft='+p.draft+'; mergeable='+p.mergeable]))}

Столбец «Base / SHA в ответе PR» точно передаёт метаданные GitHub и не обозначает текущий HEAD базовой ветки. Например, у PR #2 base.sha — 75e3907 при текущем HEAD базовой ветки 6998; у PR #5 base.sha — b455 при текущем main 83ff. Их фактические merge-base независимо прочитаны как 75e3907 и b455. Текущие вершины базовых веток учитываются отдельно в снимке.

Фактическая цепочка веток: PR #1 содержит текущий main; PR #2 основан на прежнем Core 75e3907; PR #3 и #4 — параллельные ветки поверх PR #2; PR #10 сохраняет историю всех 4 исходных веток; PR #11 основан на PR #10. Отдельная цепочка — #5 → #7 → #9. Единственное пересечение изменений main и PR #5 относительно merge-base — AGENTS.md. Наличие старой вершины ветки не даёт права удалить добавленный в main Cargo.lock. [Разбор истории и конфликта](infrastructure/infrastructure-audit.md).

Issues: **#6 open/agent-ready/unassigned** — исследование реализуемости; **#8 open/agent-blocked** — предпосылки производственного Broker. Автоматическое исполнение не запускается; метка готовности сама по себе не предоставляет полномочий. Тексты Issues сохранены в снимке и прочитаны как требования, а не как команды оболочки или разрешения. Последние комментарии владельца в PR #3 и #10 направляют к PR #11; новых рецензий и одобрений нет. [Issue #6](https://github.com/paulgreenbox-beep/makepad-sandstudio/issues/6), [Issue #8](https://github.com/paulgreenbox-beep/makepad-sandstudio/issues/8).

В GitHub Actions total_runs=0; у HEAD всех 9 PR число check-runs и status contexts равно 0. Состояние combined state pending при 0 contexts означает отсутствие свидетельств CI и не доказывает запуск или неуспешное завершение задания. [Запуски проверок](check-runs.json), [статусы коммитов](commit-statuses.json). Локальные результаты Cargo и Node сохранены отдельно.

Закреплённые исходные версии: Makepad dev = MSS **${R.makepad}**; Toolkit main **${R.toolkit}**; tools2 main **${R.tools2}** с целевой версией Makepad 71c9ddcbb9c01dd208f99621fdd71024a5d35c65. Корневой проект Toolkit использует .deps/makepad/widgets, для которого SHA восстановить не удалось. [Манифест версий](toolkit/version-baselines.json), [указатель исходников](runtime/source-reference-manifest.json). Совместимость различных сочетаний версий не объявлена.

## 3. Complete Component Inventory

${table(['Модуль','Текущий main','Существующий PR','Реализация','Проверка','Недостающий код','Зависимости','Риск','Приоритет'],modules.map(m=>m.slice(0,9)))}

Точные публичные интерфейсы, строки исходников и состояния по семи ревизиям приведены в [аудите среды исполнения](runtime/runtime-audit.md) и [манифесте исходников](runtime/source-reference-manifest.json). Прочитаны исходники каждого крейта, включая Cargo, README, SKLT и инструкции skills. Корневой workspace содержит 7 крейтов; MSS_Skills — документация, а не восьмой крейт Rust. Desktop main.rs содержит код нативного интерфейса, но ещё не показывает работающие дочерние приложения.

Владелец нативных процессов, планировщик исполнения и процессы агентов отсутствуют. API не создаёт второй реестр; RequestContext пока считается доверенным входом логической модели. В Remote нет механизма доставки команд и защиты от повторного исполнения. FrameStore принимает переданные извне байты после логической авторизации, не подтверждая их происхождение от рендерера. Перечисления статусов SDK/MCP — каркас; README Skills не предоставляет полномочий. GOAL, dispatcher и broker существуют только в своей цепочке веток. [Машиночитаемый перечень компонентов](component-inventory.json).

## 4. Architecture and Trust Boundaries

Предлагаемый путь данных: аутентифицированный внешний субъект → MCP/Desktop → единый MSS_API → идентичность и владение ресурсами в Core, исполнитель и журнал команд в Remote → явно подключённый SDK приложения в его собственном потоке событий → независимое наблюдение состояния, работоспособности и кадров → доставка кадров с лимитами и сохранением свидетельств в Render → область выбранного приложения в Desktop. Значения agent_id, PID, WidgetTarget, номер порта и имя файла не являются учётными данными.

Полномочия на ресурсы принадлежат Core и контроллеру; семантика GUI-действий и постусловия — API и адаптеру Toolkit; семантическое состояние приложения и захват кадров — SDK. Render проверяет источник кадра, сессию, свежесть, формат и квоты. MCP, Skills и Viewer не создают отдельные реестры политик или сессий. Доверенный управляющий слой необходимо отделить от недоверенных данных Issues, агентов, PR и приложений реальными границами ОС и каналов связи. Инструкции в запросе модели сами по себе изоляцию не обеспечивают.

${table(['Модуль','Ответственность','Полномочия / граница','Недопустимые действия'],[
 ['Core','Сессии, процессы, Job, владение ресурсами и жизненный цикл','Сохранённые дескрипторы собственных ресурсов и точное поколение','Семантика GUI, поиск и завершение чужих процессов'],
 ['API','Авторизация, разрешения, координация и результаты','Контекст из проверенной идентичности и политика','Доверие к AgentId от клиента или дублирование реестра'],
 ['Remote','Типизированная доставка команд, защита от повторов и чтение результата','Аутентифицированная привязка приложения и журнал команд','Глобальный ввод или автоматический повтор при неизвестном результате'],
 ['Render','Подлинность и свежесть кадров, квоты и владение ресурсами','Источник, канал, процесс и эпоха рендерера','Вывод о подлинности кадра по сигнатуре PNG'],
 ['SDK','Семантические действия, состояние, работоспособность и чтение результата в приложении','Явно подключённый поток приложения и источник разрешённых возможностей','Копирование или форк всего Makepad SDK'],
 ['MCP','Отображение протокола в общий API','Проверенные полномочия клиента','Отдельные бизнес-правила поставщика или передача дескрипторов ОС'],
 ['Desktop','Вкладки, статусы и текущий кадр собственного приложения','Авторизация через API; владение только ресурсами просмотра','Перевод в foreground или обход через глобальный физический ввод'],
 ['Skills','Версионируемые безопасные инструкции','Без учётных данных и выдачи разрешений','Скрытый обход ограничений или повышение статуса'],
 ['CheckBroker','Проверки утверждённых неизменяемых исходников','Независимые полномочия на исполнение и выпуск свидетельств','Ослабление защищённого профиля ради использования как среды GUI']])}

Структурное исследование корня PR #10 вернуло SKLT_ONLY: 8 модулей, объектов и файлов, 0 GLIF, write_enabled=false. Это только наблюдение структуры. Идентификаторы mss.core/api/remote/render/sdk/mcp/desktop/skills сохраняются. Прямые зависимости Remote/Render от API в Cargo описаны шире, чем в текущем SKLT; запланированные дополнительные связи нельзя удалять лишь потому, что реализация ещё отсутствует. [Декларации Dungeon](${source('doc/dungeon.md')}), [SKLT Render](${source('MSS_Render/mss_render.sklt')}). Подключение к управляемому режиму, индексирование и проекция не выполнялись.

**Нужны два профиля:** защищённый CheckBroker без GUI для потенциально враждебного кода сборки и тестов и отдельно проверенный профиль исполнения Makepad. Нельзя ослаблять токен Broker или проверки Win32k/USER32 ради рендеринга. Частные рабочие столы, адресация ввода, Job и раздельные процессы сами по себе не изолируют файловую систему, сеть или все ресурсы ОС. [SECURITY](${source('SECURITY.md')}), [аудит Broker](infrastructure/infrastructure-audit.md).

## 5. Findings and Risk Register (P0/P1/P2/P3)

P0 — обязательное условие безопасности и квалификации перед изменяющими состояние действиями или включением автоматизации; P1 — препятствие функциональной интеграции или согласованию исходников; P2 — надёжность, структура и просмотр; P3 — отложенная интеграция поставщиков и документация. Многие риски P0 сейчас сдерживаются отключённым режимом с отказом по умолчанию. Это запрет на включение до проверки, а не утверждение об уже произошедшем инциденте.

${riskTable}

Дополнительно: каталог Toolkit различает set_value и input, но исходники reliability используют общий маршрут verified_input. Название маршрута не доказывает способ исполнения: нужен независимый критерий проверки результата. Совпадение внутреннего маршрута не разрешает подменять операции. [Аудит Toolkit](toolkit/README.md). Историческая запись об оборудовании не подтверждает физический runner или отсутствие виртуализации; функции хоста на этом этапе не менялись.

## 6. Formal Invariant Catalog

Полный [каталог из 54 строк](invariant-catalog.md) и [JSON](invariants.json) содержат формальное правило, существующую реализацию, сценарий нарушения, обязательную проверку, свидетельства и статус. Распределение статусов в указанных границах: ${Object.entries(invSummary).map(([k,v])=>k+'='+v).join(', ')}. PASS логической модели или собственного тестового процесса не переносится на нативную среду, продукт или производственную эксплуатацию.

${table(['Invariant ID','Формальное правило','Обязательный тест','Текущий статус'],invariants.map(i=>[i.id,i.formal_rule,i.required_tests,i.status]))}

Для каждой строки полный каталог задаёт конкретный контрпример и ожидаемое наблюдение. Утверждение об изоляции требует проверки идентичности, отказов доступа через ACL и каналы, жизненного цикла процессов и ресурсов, а также негативных сценариев.

## 7. Complete Toolkit Operation Parity Matrix

Повторный подсчёт точного operations.json дал **112** операций; прежнее количество не менялось. SHA256 исходного каталога: **${parity.catalog_sha256}**; Git blob и источник сохранены. Полное приложение содержит **112 строк**: [toolkit-operations-appendix.md](toolkit/toolkit-operations-appendix.md). Нормативные данные для машинной проверки: [toolkit-parity.json](toolkit/toolkit-parity.json), исходные [каталог](toolkit/operations.raw.json) и [схема](toolkit/schema.raw.json).

Для каждой операции указаны точное имя, обязательные и необязательные параметры, признаки каталога, capability и схема. Признаки изменения состояния, идемпотентности и физического ввода рассматриваются независимо; отсутствие сведений означает NOT_VERIFIED, а не false. Классификация эффектов по исходникам отделена от нормативных гарантий; без исполнения фактический способ остаётся NOT_VERIFIED. Текущий эквивалент MSS — UNSUPPORTED, реализация NOT_IMPLEMENTED, проверка NOT_VERIFIED. Заданы конкретные PLANNED-проверки независимых постусловий и отказов, ссылки на базовые сценарии, исходники и тесты, а также недостающие проверки MSS. Идентификаторы TK-OP-001…112 включают CONTRACT/EFFECT/FAILURE/ISOLATION и контрольный этап A13. Текстовые упоминания и предполагаемые ошибки служат навигацией; это **не подтверждённое перечисление ошибок и не доказательство покрытия**.

Общая схема с additionalProperties=true не задаёт полный формальный тип каждого аргумента операции: нормативным источником остаются соответствующие валидаторы Rust. Гарантии, которых нет в исходниках или результатах исполнения, не добавлены как факты. Наличие 43 сценариев v1, 1 набора suite и 13 профилей sample-not-run не означает выполнения всей базовой программы приёмки. Публичные композиции runner, generated, inline и shell сохранены в области инвентаризации. [Указатель исходников и тестов](toolkit/test-inventory.json).

Недопустимые отождествления: set_value≠input, click≠set_value, ACK≠фактический эффект, скриншот≠независимое постусловие, компиляция≠совместимость при исполнении. Все 112 операций остаются целевым критерием, даже если некоторые оконные сценарии или операции физического ввода окажутся невозможны при действующих ограничениях. В таком случае требуются UNSUPPORTED/BLOCKED и статус полного паритета NOT_VERIFIED; выборочное удаление или пропуск тестов недопустимы.

## 8. Existing Test Inventory

[Полный именованный реестр](existing-test-inventory.md), [JSON среды исполнения](runtime/runtime-test-inventory.json), [JSON инфраструктуры](infrastructure/infra-test-inventory.json), [общий указатель](existing-tests-index.json). Каждая текущая или историческая запись содержит имя, файл и строку, SHA исходников, результат, уровень свидетельства и ссылку. Для инфраструктуры также сопоставлены точные Git blobs, cfg, ignore и журналы.

${table(['Срез','Тесты в исходниках','Что действительно подтверждено'],[
 ['main 83ff501','0 поведенческих тестов Rust','Каркас и скомпилированный иллюстративный Desktop; нативное исполнение и GUI — NOT_VERIFIED'],
 ['PR1','12 Core','Исторический результат Core: 12 PASS на точных исходниках; семь исходных тестов сохранены'],
 ['PR2','Всего 9 = Core 7 + API 2','Перечень из исходников; исполнение этой ветки не выдаётся за запуск PR10'],
 ['PR3','Всего 11 = Core 7 + API 2 + Remote 2','Перечень из исходников; исходные утверждения тестов сохранены'],
 ['PR4','Всего 12 = Core 7 + API 2 + Render 3','Перечень из исходников; исходная проверка сигнатуры не доказывает целостность PNG'],
 ['PR10','44 = Core 16 / API 6 / Remote 5 / Render 9 / композиция 8','Логические тесты на точном 352e2c3 — PASS; восемь команд — PASS; 8863 меняет только документацию, код идентичен'],
 ['PR11','45','Фактический результат 192b81a: 44 PASS / 1 FAIL / 0 ignored; fmt FAIL; в аудите ошибка не исправлялась'],
 ['PR5/7/9: инфраструктура','119 уникальных именованных тестов = 39 Rust + 80 Node','37 Rust PASS / 2 NOT_RUN и 80 Node PASS на своих исходниках; это не единый интеграционный запуск'],
 ['Исходный Toolkit','210 деклараций Rust + 116 Node','Статическая инвентаризация всех исходников; развёртывание динамических и cfg-тестов не выполнялось; все исполнения в аудите — NOT_RUN']])}

Всего в разных ветках **164 именованных тестовых случая MSS**. Их исторические PASS нельзя объединять в утверждение о едином успешно выполненном наборе: они принадлежат разным деревьям исходников. При заблокированной приёмке USER32 успешно проходят утверждения об отказе; это не PASS фактической привязки рабочего стола. Два ignored-теста WFP/symlink сохранены со статусом NOT_RUN и своими предпосылками. [Нативные свидетельства](evidence/pr9-crash-user32.json), [история Node и ручной проверки](evidence/pr7-dispatcher-manual.json). В этой фазе PLAN FIRST новых запусков проектных тестов — 0; хеши прежних журналов и идентичность исходников сверены повторно.

## 9. Missing Tests and Verification Matrix

Все ${tests.length} будущие или расширяемые проверки приведены в [полной таблице](missing-tests.md) и [JSON](proposed-tests.json); дополнительно заданы 112 групп операций в матрице паритета. Для каждой проверки указаны сценарий, предпосылки, ожидаемый результат, среда, свидетельства, приоритет, целевой PR и ссылки на инварианты.

${table(['Уровень','Основная область','Обязательные примеры / IDs'],[
 ['1. Статические проверки','Закреплённые версии, схемы, каталог, GOAL, SKLT, CI и метаданные доверия','T-X01/X02; INV-STRUCT/CATALOG/CI; граф зависимостей и привязка к исходникам'],
 ['2. Модульные тесты и свойства Rust','Исчерпание ID, поколения, авторизация и отказ, отмена, лимиты журнала и декодера','Сохранить текущие тесты; детерминированные последовательности и барьеры конкурентного исполнения, без обхода производственной авторизации'],
 ['3. API/Remote/Render','Владелец, чужая или устаревшая сессия, заполненный кеш, неверные данные, отмена','Сохранить 8 публичных интеграционных тестов; добавить реальные идентичности, источники кадров и сбои исполнителя'],
 ['4. Нативные процессы','Собственный ProcessLease, приостановленный Job, идентичности дочернего процесса и процесса тестирования','Подмена PID, времени создания и образа; список дескрипторов; закрытие A при продолжающей работу B'],
 ['5. Безопасность Windows и освобождение ресурсов','Токен, ACL, WFP, reparse, исходники, свидетельства, USER32, потеря управляющего процесса','B02–B06; предпосылки существующих ignored-тестов не заменять имитацией'],
 ['6. Адресованный ввод Makepad','Семантические возможности в потоке приложения, чтение результата и работоспособности','INV-INPUT/CMD/AUTH, T-X03/X04; без глобального ввода'],
 ['7. Настоящий рендерер','Реальные кадры с nonce, источник, сброс, свежесть, mutex и нагрузка на декодер','INV-RENDER-02…08; проверки синтетических PNG остаются отдельными'],
 ['8. Область просмотра Desktop','Выбранный текущий кадр, устаревание, ошибка и освобождение ресурсов','INV-DESKTOP-01; отдельное собственное тестовое приложение просмотра'],
 ['9. MCP/Toolkit','Общие контексты API, неизвестные инструменты, сохранение семантики сценариев и отчётов','T-X07/X09; TK-OP-001…112; платные пробные вызовы клиентов — отдельно'],
 ['10. Параллельность, отказы и безопасность','Гонки, повторы, потерянные ответы, аварии, ресурсы и смешение свидетельств','T-X03/X04/X05/X08/X10; точная классификация неизвестного результата и освобождение ресурсов']])}

Требуемые свидетельства: исходники, команда и среда; фактическое наблюдение и работоспособность приложения; идентичность процесса, канала и кадра каждой сессии; SHA256 неизменяемых артефактов; результат освобождения ресурсов и перечень оставшихся ресурсов. Синтетическая модель, реальный собственный примитив ОС и работающее приложение Makepad учитываются раздельно. Объявление тестовой функции само по себе не подтверждает покрытие или результат.

## 10. Required Code and Architecture Changes

Минимальный дополнительный код сгруппирован по ответственным и PR в [22 подробных карточках](ordered-pr-backlog.md). Каждая объясняет, почему имеющегося кода недостаточно, и задаёт файлы, интерфейсы, ссылки на инварианты и тесты, критерии приёмки и риски регрессий. Существующие реестр, API, механизмы отказа и кеш не переписываются. Общая инфраструктура расширений и оркестрации вводится только при обоснованной необходимости.

${table(['Область','Нужное расширение','Что переиспользовать','Проверка регрессий'],[
 ['Идентичность и жизненный цикл','RuntimeSessionKey(epoch), ProcessLease/Identity; явный запуск, Job, сроки завершения и карантин','Непрозрачные ID, владелец и поколение Core; реестр числовых PID недостаточен','Исходные 16 тестов Core и нативные проверки своих и соседних процессов'],
 ['Авторизация и связь с приложением','Контекст из проверенной идентичности, начальная привязка приложения и клиента, семантические разрешения','Единый заимствованный API/Core; явно подключаемые публичные точки Makepad через SDK','Отказы для чужих и устаревших сессий, неверного узла и прямого обхода; AgentId из канала не считать доверенным'],
 ['Исполнитель','Ограниченный журнал резервирования, доставки и результата команд; чтение результата и работоспособности','Типизированные намерения Remote и отказ для неверного формата; без автоматического повтора','Гонки, отмена и неизвестный результат до разрешения изменяющих состояние команд'],
 ['Рендерер','Доверенный источник, время, эпоха, шаг строки, хеш и поток с лимитами','Допуск кадров, освобождение ресурсов, последовательности FrameStore и закреплённый декодер','Настоящий кадр приложения; сброс, переполнение потока и бюджет декодера'],
 ['Процессы проверок и свидетельства','Независимые процессы тестирования, адаптеры планировщика Toolkit, защищённые манифесты','Существующие runner, reliability и economy Toolkit; неизменяемые исторические записи','Потеря процесса проверки, работоспособность, сокрытие секретов и подделка свидетельств'],
 ['Клиентские интерфейсы','Тонкие адаптеры просмотра, MCP и skills поверх действующего API','Имеющаяся оболочка Desktop; общая политика без дублирования','Выбранный настоящий кадр, разрешения клиента и отказы'],
 ['Инфраструктура','Полномочия, подготовка исходников, WFP, ACL, свидетельства и разделение управления','Отключённый dispatcher, производственный отказ Broker и пробы с привязкой к исходникам','Отдельный Broker, 80 тестов Node и независимая квалификация безопасности']])}

Решения без изменения кода: оставить dispatcher отключённым; сохранить полный паритет как цель и все ограничения; выбрать условный эксперимент B и сравнительный вариант A; сохранить единую схему GOAL; не переносить PASS нативного тестового процесса на продукт. Добавление зависимостей или изменение точки входа SDK допускается только в отдельно рассмотренном объёме реализации с анализом точной версии, лицензии, features и платформ.

## 11. Windows Two-Session Feasibility Decision

**Вердикт: исходники дают кандидатов на реализацию; разрешение GO для исполнения — NOT_VERIFIED, живой PoC — NOT_RUN.** Предварительно выбран минимальный PoC B: два собственных процесса приложений Makepad, каждый со своим чтением RenderBGRAu8 из рендерера, защищённым каналом команд и кадров, отдельными учётными данными и клиентами-агентами. Вариант A — общая поверхность D3D дочернего hosted-приложения Windows — остаётся сравнительным экспериментом. Он не становится основным производственным путём до проверки аутентификации, ACL и mutex. [Точные API, файлы, строки и источники ОС](runtime/runtime-audit.md).

${table(['Критерий','A: поверхность дочернего hosted-приложения','B: кадры GPU от самого приложения'],[
 ['Пути в исходниках','windows.rs/stdin-loop → Studio WebSocket; HostSwapchain/sharedBGRAu8; именованные поверхности D3D NT','Кандидат — захват StandaloneRemote/g либо явно подключённые RenderBGRAu8, Texture::read_back и очередь чтения Cx'],
 ['Наличие в Windows','Код существует на точном 130be1d; прежний обзор только Linux был неполным','API чтения присутствуют; точная точка входа приложения для частного или заэкранного исполнения требует эксперимента'],
 ['Ввод','Сообщения Studio адресованы конкретному приложению; WS/build id не обеспечивают аутентификацию','SDK в потоке приложения, объявленные семантические ID и аутентифицированная привязка pipe'],
 ['Происхождение кадра','Нужна проверка привязки поверхности, дочернего процесса и сборки, а также фактического успеха mutex; импортёр может игнорировать числовой дескриптор','Заявка чтения, сессия, процесс, эпоха рендерера, полный буфер и хеш, а также независимое состояние'],
 ['Производительность','Возможны малые затраты копирования, но есть риски keyed mutex и времени жизни; измерений нет','Затраты CPU на чтение, копирование и PNG; предел эксперимента 800x600@5fps не является измеренной производительностью'],
 ['Пробелы безопасности','Дескриптор безопасности по умолчанию, предсказуемые имена, WS без аутентификации, игнорирование AcquireSync; восстановление после потери узла не доказано','Нужны реализация и проверка отдельного ACL канала pipe, привязки узла и публичной точки источника кадров; одного шлюза недостаточно'],
 ['Совместимость','SharedBGRAu8 не равнозначен обычному чтению RenderBGRA; сочетание hosted/g не проверено','Совместимость узкого профиля PNG MSS с настоящим кодировщиком требует измерений; полного паритета захвата Toolkit нет'],
 ['Решение','Только сравнение; NO-GO, если гарантии недостижимы без запрещённых изменений SDK','Предпочтительный условный первый этап; NO-GO при отказе публичной точки входа, GPU без рабочего стола пользователя, аутентификации или проверки происхождения']])}

Будущий протокол с ограниченным объёмом исполнения (ещё не выполнен):

1. Зафиксировать неизменяемое сочетание исходников, toolchain, приложения, профиля и зависимостей. Оператор отдельно разрешает запуск только доверенных тестовых приложений. Квалифицировать физический Windows-хост, GPU, драйвер и профиль исполнения. Ради теста нельзя открывать, переключать или наблюдать обычный рабочий стол пользователя.
2. Начать с контроллера и одного доверенного тестового приложения: область с nonce, счётчик и два поля. Исключить плагины, горячую перезагрузку, диалоги и сетевой обходной путь. Проверить исходники публичной точки выдачи кадров; если она требует переписывания upstream, результат — явный NO-GO. Локальная начальная привязка к ОС в стенде A03 не является производственной аутентификацией A04/A05.
3. Для узкого фиксированного стенда сохранить дескрипторы процесса, запись запуска Job и начальной привязки; это ещё не Core ProcessLease. Явно задать executable/argv/env/cwd, поместить приостановленный процесс в Job до возобновления, ограничить наследование дескрипторами начальной привязки и кадров. Проверить точные PID, время создания, образ и рабочий стол; задать сроки и защищённый pipe.
4. Предлагаемые консервативные лимиты: 800x600, 30 кадров при 5 fps, 2 MiB закодированных данных на кадр, одна незавершённая заявка чтения; запуск — 10 s, запрос — 2 s, полное время — 90 s. Это проект допуска и проверки, **не текущее измерение**. Принудительные лимиты CPU/RAM, дочерних процессов и вывода, их наблюдение и нагрузочные проверки рассматриваются отдельно.
5. В A03 разрешены только чтение и захват кадров; nonce изменяется самим тестовым приложением. Нужны реально отрисованные пиксели nonce, независимые состояние и работоспособность, эпоха кадра, последовательность, время и хеш; статический скриншот недостаточен. Внешние команды изменения состояния и сценарии потерянного ответа допустимы только после журнала A06; неизвестный результат не разрешает повтор.
6. Проверить неверный источник, чужого агента, устаревшее поколение, неверный кадр, тайм-аут, сброс рендерера и аварию. Нормальное завершение и принудительное ограничение своим Job учитывать раздельно. Сохранённые дескрипторы должны сигнализировать завершение; ресурсы, права владения и каналы освобождаются либо переводятся в карантин.
7. После GO для одного приложения и реализации необходимых A04–A07 повторить проверку для **двух дочерних процессов приложений**, двух процессов клиентов-агентов и собственных процессов тестирования. У каждого должны быть отдельные nonce, учётные данные и рабочие каталоги. Закрыть или аварийно завершить A, пока B продолжает выдавать кадры и выполнять действия. Это A08 — первая полная приёмка двух сессий, которую нельзя заменить декларацией потоков контроллера.

Решение GO требует свидетельств настоящего кадра, отсутствия запрещённого ввода, проверенных идентичностей и процессов, работоспособности, постусловий и освобождения ресурсов на точном профиле. Предпосылки отсутствуют — NOT_RUN; проверка начата, но предпосылка не позволяет выполнить контракт — BLOCKED; наблюдается неверный эффект, кадр или утечка — FAIL. Недопустимы скрытый перевод в foreground, SendInput, ослабление Win32k, VM или подмена скриншотом и имитацией. Эксперимент возможностей Windows не квалифицирует Broker для исполнения враждебного кода.

## 12. Native Broker Security Gaps

Цепочка #5 → #7 → #9 независима от среды исполнения GUI. Полная [матрица 15 границ безопасности](infrastructure/infrastructure-audit.md) разделяет протокол, модель, исходники, конфигурацию и свидетельства реальных примитивов ОС на фиксированных стендах. Текущая производственная точка входа отказывает даже при корректном JSON; в политике enabled=false, isolation.approved=false, scopes пусты, runner и закреплённые версии не настроены. [Политика](${source('.github/codex-issue-policy.json',R.dispatcher)}).

До производственного включения обязательны следующие проверки:

${table(['Граница','Имеющиеся ограниченные свидетельства','Недостающая обязательная проверка'],[
 ['Полномочия вызывающей стороны','TypedExecutionBinding и контроллеры фиксированных стендов','Аутентификация вызывающей стороны, узла и токена средствами ОС; защищённые разрешения; процесс исполнения не может выдать себя за контроллер'],
 ['Подготовка исходников','Типизированные данные ExecutionBinding/BoundRequest; защищённый механизм подготовки исходников отсутствует','Доверенный импорт точного дерева; неизменяемые исходники, зависимости и команды; отсутствие обходов через .git/config, hooks, reparse и TOCTOU'],
 ['Защита исполняемого окружения','Примитив запрета совместного доступа к образу и родительским каталогам','Точные путь, хеш и файловая идентичность; защита toolchain, DLL, окружения и конфигурации при враждебной сборке'],
 ['Токен, Job и дескрипторы','Нативные проверки restricted token, low IL, атрибутов Job и дочернего процесса стенда','Раздельные идентичности исполнения, запрет доступа между сессиями; гонки запуска, наследование дескрипторов и нагрузка потомками'],
 ['Файловая система','ACCESS_DENIED для частного и соседнего ресурсов в тестовом стенде','Два настоящих изолированных субъекта и корня исполнения; reparse, hardlink, ADS, регистр имён и гонки ACL'],
 ['Сеть','Тест WFP пропущен; есть только требования политики','Фактическое применение ограничений ОС для IPv4/IPv6/TCP/UDP/DNS и потомков; разрешённые и запрещённые собственные конечные точки'],
 ['Повторы, вывод и квоты','Модель AttemptFence, чтение настроенных лимитов Job и усечение stdout','Защищённые атомарные заявки; фактические лимиты CPU/RAM, процессов, диска и вывода под нагрузкой, включая удерживаемые pipe'],
 ['Авария и освобождение ресурсов','Наблюдалось исчезновение собственного рабочего стола фиксированного стенда','Общее восстановление, карантин и параллельное освобождение ресурсов за пределами одного стенда'],
 ['USER32','PostREADYQueryUnavailable возвращает NULL/error0; обязательная проверка отклоняет результат','Наблюдение фактической привязки рабочего стола точного потока; недоступность остаётся BLOCKED, без ослабления проверки'],
 ['Полномочия на свидетельства','Валидаторы хешей и формата привязок; производственных свидетельств нет','Защищённые подписант, канал и хранилище; проверка реальных байтов, исходников, nonce и подлинности, а не доверие к JSON процесса исполнения'],
 ['Разделение управления, модели и публикации','Закреплённый workflow, разрешения и проект разделения','Защитить collect/upload после модели в том же задании либо перенести их к отдельной доверенной стороне; квалифицировать реальный физический хост'],
 ['Развёртывание и пробный запуск','Отключённые флаги и требования к владельцу','Независимое одобрение безопасности; Secrets, регистрация, области доступа, версии и бюджет под контролем владельца; один ограниченный пробный запуск до широкого включения']])}

SHA256 подтверждает целостность, но не подлинность. Job, low IL и частный рабочий стол — отдельные примитивы, не полная граница изоляции ОС. Несовместимость или недоступность обязательной проверки USER32 означает NO-GO. Разрешённый альтернативный проект потребует независимого рассмотрения и новых свидетельств; удаление негативного теста проблему не решает. [Обоснование по Microsoft и исходникам](runtime/runtime-audit.md).

Отдельные проблемы интеграции: самостоятельный Cargo-проект Broker не входит в корневой workspace; проверка каталога Node отсутствует в allowed_commands; ссылки ручных локальных свидетельств несовместимы с автоматической схемой sha256. При отсутствии управляющего runner workflow останется в очереди и сам не сможет написать комментарий BLOCKED. Режим unsafe codex-action на Windows и закрепление action не квалифицируют хост. Установка CLI и proxy, цепочка поставки, идентичности и последующие шаги задания требуют отдельного рассмотрения. [Актуальная официальная документация и аудит закреплённого action](infrastructure/infrastructure-audit.md).

## 13. Dependency Graph

\
~~~mermaid
${graph}
~~~

Нормативный машиночитаемый источник — [pr-backlog.json](pr-backlog.json). Валидатор проверяет отсутствие циклов и неизвестных ссылок, а также наличие ссылок на инварианты и тесты. Диаграмма служит кратким представлением для рецензирования и не является трассой исполнения. A00 и B00 можно готовить параллельно; A06 и A07 — параллельно после A05; A09, A10 и A11 — частично параллельно после A08. Проекты B02 и B03 согласуются между собой; фактическое применение ограничений в B04 требует обоих. Свидетельства B05 и квалификация физического хоста B06 следуют последовательно. Любой конфликт в общем файле требует отдельного рассмотрения владельцем.

## 14. Ordered PR Backlog

Все 22 карточки с точными Goal/Base/DependsOn/Files/RequiredCode/Invariants/Tests/Acceptance/Risks/Size/MergeGate приведены в [ordered-pr-backlog.md](ordered-pr-backlog.md) и [JSON](pr-backlog.json). Существующие PR #1–#4 нельзя переписывать или дублировать: их работа уже включена в PR #10. PR #5, #7 и #9 следует дорабатывать в их цепочке только после отдельного разрешения; конкурирующие реализации не создаются.

${table(['PR ID','Название','Зависит от','Объём','Условие слияния'],prShort)}

S — узкое изменение; M — несколько связанных контрактов; L — нативная или платформенная интеграция с проверкой отказов; XL — крупный этап испытаний, который нужно разбить на PR по операциям и профилям. Это оценки объёма при указанных предпосылках, а не обещание календарных сроков.

## 15. Milestones and Critical Path

${table(['Этап','Критерий завершения','Блокирующие условия / параллельность'],[
 ['M0. Достоверная основа плана','Этот проверенный комплект: согласованы 112 строк, все 9 PR, 2 Issues, реестры тестов, риски и зависимости','Завершена проверка только артефактов плана; реализация не принята'],
 ['M1. Логическая основа в main','A00/A01; 45 тестов и все корневые проверки на точном новом SHA; рецензия владельца','Ошибка PR11 и ручное разрешение на слияние; B00 можно готовить параллельно'],
 ['M2. Один настоящий доверенный кадр','A02/A03: публичная точка входа, физический Windows/GPU, начальная привязка стенда и порядок освобождения ресурсов; решение GO','Нет квалифицированного физического профиля или точки входа — NO-GO/NOT_RUN; оформление UI отложено'],
 ['M3. Минимальные защищённые механизмы приложения','A04/A05, затем A06 и A07','Журнал до изменения состояния; источник кадров до просмотра; инфраструктурная линия B проектируется независимо'],
 ['M4. Первый PoC двух сессий','A08: два настоящих приложения, клиенты и процессы проверки; чужая сессия, устаревание, неизвестный результат, авария и освобождение ресурсов','M1 → M2 → A04 → A05 → (A06 || A07) → A08 — кратчайший путь к полному PoC'],
 ['M5. Прикладные адаптеры','A09: просмотр; A10: процессы проверок и свидетельства; A11: MCP; затем A12: Runner','Только подтверждённые API и данные; без второго реестра или общей инфраструктуры планировщика'],
 ['M6. Полная приёмка продукта','A13: все 112 операций, неизменённые наборы тестов, нативные GUI/GPU, отказы и безопасность','Недоказанные эквиваленты физического ввода и сочетания версий блокируют утверждение полного паритета'],
 ['MI. Квалификация инфраструктуры','B00 → B01 → B02 → B03 → B04 → B05 → B06','P0: полномочия, WFP, USER32, исходники, свидетельства и физический хост; отдельно от среды приложений'],
 ['MA. Включение под контролем владельца','B07: независимая рецензия, бюджет владельца и один пробный запуск','Автоматическое включение запрещено; успешный CI или вызов модели не равен M6']])}

Эксперимент с одним приложением предшествует полноценному PoC двух приложений: он уточняет порядок реализации, сохраняя исходную цель. До механизмов владения процессами, авторизации, журнала команд и доверенного источника кадров нельзя доказать безопасность двух управляемых сессий. Минимальный объём ограничен доверенными тестовыми приложениями и существующими публичными точками интеграции. Оформление MCP, особенности поставщиков и общая инфраструктура расширений не включаются в критический путь.

## 16. CI and Acceptance Gates

Корневой workspace, отдельный Broker, Node и живые проверки имеют разные области применения. **Нельзя использовать GitHub-hosted runner на VM, Docker, WSL/WSLC, Hyper-V или исполнение в VM.** Автоматическое исполнение недоверенных PR отключено до независимой квалификации физического runner. Метки workflow и флаги сами по себе ничего не доказывают. Для рассмотренных исходников допустимы отдельно разрешённые ручные запуски с точной привязкой к коду; их свидетельства не считаются статусом GitHub CI.

${table(['Проверка','Точная команда','Область / толкование'],rootGates)}

Тяжёлые команды Cargo выполнять последовательно. Сначала — именованный или модульный тест изменённого компонента, затем — интеграция с потребителями, после этого — обязательные проверки этапа. Lockfile и закреплённые версии сохраняются; offline возможен только с заранее заполненным кешем. Отсутствие зависимости, toolchain или профиля явно даёт BLOCKED/NOT_RUN и не разрешает молчаливый пропуск. Новый SHA после слияния требует повторной проверки кода. Более поздний коммит только с документацией связывается с проверенным кодом через точное сравнение Git blobs, а не через текст описания коммита.

${table(['Проверка отдельного Broker','Команда','Толкование'],brokerGates)}

Будущий fixture-пакет не входит в семь корневых members и не должен оставаться непроверенным из-за зелёного root workspace:

${table(['Проверка standalone fixture','Команда','Толкование'],fixtureGates)}

Проверка Node:

~~~text
node --test scripts/codex-issue/test/dispatcher.test.mjs
~~~

Сохранить 80 тестовых случаев; добавить негативные проверки каталога, свидетельств и полномочий. Workflow проверять закреплённым валидатором YAML/actionlint без вызовов модели. Если валидатор не установлен, результат — NOT_RUN; его установку необходимо разрешить отдельно. Скрытое скачивание недопустимо. Фактическое исполнение workflow движком GitHub — NOT_RUN.

${table(['Проверка со свидетельствами','Область исполнения','Критерий приёмки'],nativeGates)}

Независимый проверяющий подтверждает точные запрос, исходники, проверку, профиль и идентичность; реальные байты и хеши артефактов; итог тестов, работоспособность, постусловия, освобождение ресурсов и отсутствие пропущенных обязательных проверок. Агент-исполнитель не вправе самостоятельно переводить GOAL в VERIFIED. Нынешние 80 тестов Node, 44 теста Rust и пробы отдельных возможностей не разрешают производственное включение.

## 17. Blockers and Explicit Decisions Required

${table(['ID','Решение','Условие / кто подтверждает'],decisions.map(d=>[d.id,d.decision,d.qualification]))}

Необходимые внешние условия: квалифицированный физический Windows-хост, GPU и профиль исполнения; независимо подготовленные идентичности службы и процессов исполнения, ACL и WFP; закреплённая локальная версия SDK Toolkit; рассмотренные зависимости MCP/SDK; защищённые toolchain, исходники и полномочия на свидетельства. Владелец задаёт обязательных рецензентов, перечень runner, Secrets и бюджет API. В этой фазе перечисленные настройки не менялись. Если формальный контракт технически несовместим с запретами, следует зафиксировать NO-GO и отдельное решение по проекту; превращать этот результат в PASS нельзя.

Первый пакет реализации сейчас блокируют тестовые строки и форматирование PR #11. Производственное включение блокируют нативные полномочия, USER32, WFP, защита исходников, свидетельств и хоста. Отсутствующий код нельзя заменять PASS на имитации. Выключенный мониторинг не возобновлять; этот план не разрешает забирать Issue в работу или запускать Codex без участия владельца.

## 18. First Executable Work Package

**W01/A00 — минимальная поправка существующего PR #11**, только после отдельного разрешения владельца. Входные данные: текущий 192b81a и сохранённый FAIL. Объём: тестовые строки в MSS_Remote/src/lib.rs, строка 352, и rustfmt. Не менять защитную проверку, утверждения тестов, NotDispatched, авторизацию, последовательности или SDK. Ожидаемый результат — корректная тестовая строка Unicode. Сначала выполнить именованный регрессионный тест, затем проверки Remote, всего workspace, форматирования исходников, check, Clippy и обязательные интеграционные проверки этапа. Результат привязать к новому точному SHA и свидетельствам; исходный FAIL сохранить в истории.

Десять конкретных задач с входными данными, точными изменениями, тестами, ожидаемым результатом и критериями завершения приведены в [first-ten-tasks.md](first-ten-tasks.md) и [машиночитаемом JSON](first-ten-tasks.json). Повторная полная инвентаризация для них не требуется, однако перед изменениями исполнитель обязан заново проверить базовый SHA, разрешённый объём и предпосылки.

${tasks.map(t=>`### ${t.id}. ${t.title}\n\n`+table(['Параметр','Значение'],[['Целевой PR',t.target_pr],['Входные данные',t.inputs],['Точные изменения',t.exact_changes],['Проверки',t.test_plan],['Ожидаемый результат',t.expected_result],['Критерии завершения',t.definition_of_done]])).join('\n')}

---

Приложения входят в единый план. Полноту, ссылки, хеши и граф зависимостей проверяет локальная команда **node validate-plan.mjs**. Это проверка артефактов, а не запуск MSS или Toolkit. Существующие проектные тесты на различных SHA исходников не перезапускались. Синтаксис Mermaid здесь рассмотрен вручную по исходному тексту; разбор и отображение имеют статус NOT_RUN, поскольку парсер не установлен. Публикация в GitHub, Pages или PR не выполнялась.
`;
fs.writeFileSync('MSS_MASTER_IMPLEMENTATION_PLAN.md',body.replace(/\\\n/g,'\n'));
console.log(JSON.stringify({generated:true,invariants:invariants.length,tests:tests.length,prs:backlog.length,operations:parity.operation_count,mss_named_cases:combined.mss_unique_named_cases}));

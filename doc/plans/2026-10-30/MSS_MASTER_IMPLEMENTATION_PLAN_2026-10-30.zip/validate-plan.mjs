// Offline validation of planning artifacts only. Never runs Cargo, apps or project tests.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)); process.chdir(root);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const sha=(bytes,algorithm='sha256')=>crypto.createHash(algorithm).update(bytes).digest('hex');
const nonempty=(s,label)=>assert(typeof s==='string'&&s.trim(),label);
const unique=(a,label)=>assert.equal(new Set(a).size,a.length,label);
const snapshot=read('repository-snapshot.json');
assert.deepEqual(snapshot.prs.map(p=>p.number).sort((a,b)=>a-b),[1,2,3,4,5,7,9,10,11]);
assert.deepEqual(snapshot.issues.map(i=>i.number).sort((a,b)=>a-b),[6,8]);
for(const p of snapshot.prs){assert.match(p.head_sha,/^[a-f0-9]{40}$/);assert.match(p.base_sha,/^[a-f0-9]{40}$/);assert.equal(p.state,'open');assert.equal(p.draft,true);}
assert.equal(snapshot.github_actions.total_count,0,'Snapshot must be explicit about absent Actions evidence');
const checks=read('check-runs.json');for(const r of checks.rows)assert.equal(r.total_count,0);
const invariants=read('invariants.json').invariants,tests=read('proposed-tests.json').tests,backlog=read('pr-backlog.json').backlog,tasks=read('first-ten-tasks.json').tasks;
const im=new Map(invariants.map(i=>[i.id,i])),tm=new Map(tests.map(t=>[t.id,t])),pm=new Map(backlog.map(p=>[p.id,p]));
unique([...im.keys()],'duplicate invariants');assert.equal(im.size,invariants.length);
assert.equal(tm.size,tests.length,'duplicate tests');assert.equal(pm.size,backlog.length,'duplicate PR packages');
const states=new Set(['PASS','FAIL','BLOCKED','NOT_RUN','NOT_VERIFIED']);
for(const i of invariants){
 for(const k of ['formal_rule','existing_implementation','violation_scenario','evidence'])nonempty(i[k],i.id+':'+k);
 assert(states.has(i.status),i.id+' result vocabulary');assert(i.required_tests.length>0,i.id+' no falsifier');
 for(const id of i.required_tests){assert(tm.has(id),i.id+' unknown test '+id);assert(tm.get(id).invariants.includes(i.id),i.id+' asymmetrical test link '+id);}
}
for(const t of tests){
 for(const k of ['scenario','preconditions','expected_result','execution_environment','priority','target_pr'])nonempty(t[k],t.id+':'+k);
 assert.equal(t.status,'NOT_RUN',t.id+' proposed test must not pretend executed');assert(pm.has(t.target_pr),t.id+' unknown PR');
 assert(t.invariants.length>0&&t.evidence_required.length>0,t.id+' empty contract');
 for(const id of t.invariants)assert(im.has(id),t.id+' unknown invariant '+id);
}
for(const p of backlog){
 for(const k of ['title','goal','base','required_code','acceptance','risks','size','size_assumptions','merge_gate','regression_risks'])nonempty(p[k],p.id+':'+k);
 assert(p.files.length&&p.invariants.length&&p.tests.length,p.id+' incomplete change-to-proof contract');assert(['S','M','L','XL'].includes(p.size));
 assert.equal(p.implementation_status,'PLANNED_NOT_STARTED');
 for(const id of p.invariants){assert(im.has(id),p.id+' unknown invariant '+id);assert(p.tests.some(t=>tm.get(t)?.invariants.includes(id)),p.id+' invariant without linked test '+id);}
 for(const id of p.tests)assert(tm.has(id),p.id+' unknown test '+id);
 for(const d of p.depends_on)assert(pm.has(d),p.id+' unknown dependency '+d);
}
const visiting=new Set(),visited=new Set(),order=[];
function visit(id){assert(!visiting.has(id),'PR dependency cycle at '+id);if(visited.has(id))return;visiting.add(id);for(const d of pm.get(id).depends_on)visit(d);visiting.delete(id);visited.add(id);order.push(id);}
for(const p of backlog)visit(p.id);
assert.equal(tasks.length,10);unique(tasks.map(t=>t.id),'duplicate tasks');
for(const t of tasks){for(const k of ['inputs','exact_changes','test_plan','expected_result','definition_of_done','authorization'])nonempty(t[k],t.id+':'+k);assert(pm.has(t.target_pr));assert.equal(t.status,'PLANNED_NOT_STARTED');}
// Explicit independent-review corrections must remain represented.
for(const id of ['T-X11','T-X12','T-X13','T-X14'])assert(tm.has(id),'Missing peer-review correction '+id);
assert.equal(tm.get('T-X12').target_pr,'A03');assert.equal(tm.get('T-X13').target_pr,'B06');assert.equal(tm.get('T-X14').target_pr,'B06');
assert(!invariants.some(i=>/SourceRegistry|ControllerAuthority|ReplayFence/.test(i.existing_implementation)),'Invented existing components');
assert.match(im.get('INV-RENDER-08').formal_rule,/Если/,'Shared-surface requirement must be conditional');
assert.equal(im.get('INV-CMD-01').status,'FAIL');assert.equal(im.get('INV-PROC-07').status,'BLOCKED');
const rawBytes=fs.readFileSync('toolkit/operations.raw.json'),catalog=JSON.parse(rawBytes),parity=read('toolkit/toolkit-parity.json');
assert.equal(catalog.operations.length,112);assert.equal(parity.operations.length,112);assert.equal(parity.catalog_sha256,sha(rawBytes));
assert.equal(parity.catalog_sha256,'ffaaba15ddc2ee57c7eaf001383ee2bd285d324d640a49eed390eb4fcf339470');
unique(parity.operations.map(o=>o.name),'duplicate operation');
const original=new Map(catalog.operations.map(o=>[o.name,o]));
const tkTests=read('toolkit/test-inventory.json'), tkTestIDs=new Set(tkTests.tests.map(t=>t.id)),scenarios=read('toolkit/scenario-registry.json'),scenarioIDs=new Set(scenarios.scenarios.map(s=>s.id));
for(const o of parity.operations){
 assert.deepEqual(o.catalog_record_exact,original.get(o.name),o.name+' catalog drift');
 assert.deepEqual(o.argument_schema.catalog_required_exact,original.get(o.name).required??[]);
 for(const flag of ['capability','mutation','idempotency','physical_input','scheduler_classification']){
  if(Object.hasOwn(original.get(o.name),flag)){assert.equal(o[flag].status,'DECLARED');assert.deepEqual(o[flag].value,original.get(o.name)[flag]);}
  else{assert.equal(o[flag].status,'NOT_VERIFIED');assert.equal(o[flag].value,null);}
 }
 assert.equal(o.mss_equivalent.execution_status,'UNSUPPORTED');
 assert.equal(o.mss_equivalent.implementation_status,'NOT_IMPLEMENTED');
 assert.equal(o.mss_equivalent.verification_status,'NOT_VERIFIED');
 nonempty(o.planned_independent_success_postcondition.observation_ru,o.name+' postcondition');
 nonempty(o.failure_classification.operation_specific,o.name+' failure');
 assert.equal(o.planned_test_status,'NOT_RUN');assert.equal(o.planned_acceptance_gate,'A13');assert.match(o.planned_test_id,/^TK-OP-\d{3}$/);
 for(const s of o.baseline_test_mapping.scenario_occurrences)assert(scenarioIDs.has(s.scenario_id));
 for(const t of o.baseline_test_mapping.test_declaration_ids)assert(tkTestIDs.has(typeof t==='string'?t:t.id));
}
unique(parity.operations.map(o=>o.planned_test_id),'duplicate operation acceptance ID');
assert.equal(scenarios.scenarios.length,44);assert.equal(scenarios.scenarios.filter(s=>s.document_kind==='public_script_v1').length,43);assert.equal(scenarios.scenarios.filter(s=>s.explicit_not_run_sample).length,13);
for(const s of scenarios.scenarios)assert.equal(s.execution_status,'NOT_RUN');
assert.equal(tkTests.counts.rust_test_declaration,210);assert.equal(tkTests.counts.node_test_declaration,116);for(const t of tkTests.tests)assert.equal(t.execution_status,'NOT_RUN');
let sourceTextCount=0;
for(const f of read('toolkit/source-bundle.json').files){assert(!f.error,f.path+' source fetch error');const bytes=Buffer.from(f.content,'utf8');const gitBlob=sha(Buffer.concat([Buffer.from('blob '+bytes.length+'\0'),bytes]),'sha1');assert.equal(gitBlob,f.sha,f.path+' exact Git blob mismatch');sourceTextCount++;}
assert.equal(sourceTextCount,161);
const rt=read('runtime/runtime-test-inventory.json'),infra=read('infrastructure/infra-test-inventory.json');
assert.equal(rt.tests.length,45);assert.equal(infra.tests.length,119);unique(rt.tests.map(t=>t.id),'runtime IDs');unique(infra.tests.map(t=>t.id),'infra IDs');
for(const t of rt.tests)for(const rev of t.revisions)if(rev.present){assert(states.has(rev.result),t.id+' runtime result');assert.match(rev.source_sha,/^[a-f0-9]{40}$/);assert(rev.line>0&&rev.path);}
for(const t of infra.tests){assert(states.has(t.status));assert.match(t.source_commit,/^[a-f0-9]{40}$/);assert(t.line>0&&t.file&&t.evidence_level);assert.equal(t.evidence.execution_during_this_audit,false);assert.equal(t.evidence.local_log_hash_verified,true);}
assert.equal(infra.tests.filter(t=>t.status==='NOT_RUN').length,2);
const pr10=read('evidence/pr10-integration.json'),pr11=read('evidence/pr11-windows-summary.json');
assert.equal(pr10.summary.tests_passed,44);assert.equal(pr10.source_commit,'352e2c317de74c67e61fa38371a99be54c606c10');
assert.equal(pr11.source_commit,'192b81ac83cfa3945318804430af25b3795609ad');assert.equal(pr11.workspace_tests.passed,44);assert.equal(pr11.workspace_tests.failed,1);assert.equal(pr11.result,'FAIL');
assert.equal(read('ci-gates.json').execution_enabled,false);
const doc=fs.readFileSync('MSS_MASTER_IMPLEMENTATION_PLAN.md','utf8');
assert.equal((doc.match(/^## \d+\./gm)||[]).length,18);for(const n of Array.from({length:18},(_,i)=>i+1))assert(doc.includes('## '+n+'.'));
for(const term of ['PLAN FIRST','NOT_VERIFIED','OUTCOME_UNKNOWN','112','PAUSED','USER32'])assert(doc.includes(term));
assert.equal((doc.match(/^### W\d{2}\./gm)||[]).length,10);
const finalReadback=read('final-github-recheck.json');assert.equal(finalReadback.unchanged,true,'GitHub snapshot drift requires new audit');
const review=read('infrastructure/final-review.json');
for(const f of review.inspected_plan_file_hashes)assert.equal(sha(fs.readFileSync(f.file)),f.sha256,'Reviewed artifact changed: '+f.file);
assert.deepEqual(review.resolved_findings.map(f=>f.id).sort(),['SEC-01','SEC-02','SEC-03','SEC-04']);
assert(review.resolved_findings.every(f=>f.result==='RESOLVED'),'Open independent security review finding');
const markdownFiles=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(p.endsWith('.md'))markdownFiles.push(p);}}
walk('.');let localLinks=0;
for(const f of markdownFiles){const text=fs.readFileSync(f,'utf8');for(const m of text.matchAll(/\]\(([^)]+)\)/g)){let target=m[1].replace(/^<|>$/g,'');if(/^(https?:|codex:|#)/.test(target))continue;target=decodeURIComponent(target.split('#')[0]);if(/^[A-Za-z]:[\\/]/.test(target))continue;assert(fs.existsSync(path.resolve(path.dirname(f),target)),f+' broken local link '+target);localLinks++;}}
const result={schema:'mss-master-plan-artifact-validation-v1',result:'VALID',meaning:'Planning artifact completeness, exact catalog/source hashes and reference/DAG consistency only. Not MSS/Toolkit tests, native GUI, OS security or product acceptance.',invariants:invariants.length,proposed_tests:tests.length,pr_packages:backlog.length,first_tasks:tasks.length,toolkit_operations:parity.operations.length,mss_named_tests:164,toolkit_source_text_git_blobs_verified:sourceTextCount,toolkit_test_declarations:tkTests.counts,scenario_paths:44,master_sections:18,local_markdown_links_checked:localLinks,pr_topological_order:order,project_tests_run_during_plan:0,github_writes:0,dispatcher_enabled:false};
fs.writeFileSync('artifact-validation.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));

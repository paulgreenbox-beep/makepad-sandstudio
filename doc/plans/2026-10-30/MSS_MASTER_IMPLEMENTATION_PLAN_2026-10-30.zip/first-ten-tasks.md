# Первые десять инженерных задач

Это готовые work packages, а не разрешение исполнять их в рамках PLAN FIRST. Новая owner задача должна назвать пакет/approved scope. Никаких автоматических Issues/веток/PR.

## W01 — Исправить ровно fixture/format дефект PR11

| Поле | Значение |
|---|---|
| Target PR | A00 |
| Входные данные | PR11 head192b81a, source line352, existing failing test/summary.json |
| Точные изменения | Две Unicode строки single Rust escape; rustfmt MSS_Remote; сохранить имя/assertions и refusal behavior. |
| Инварианты | INV-CMD-01 |
| Тесты | T-009 |
| План проверок | Named regression; Remote lib; root metadata/fmt/check/test alltargets/Clippy; no fail-fast нужен для полного failure report. |
| Ожидаемый результат | 45 tests PASS/0fail/0ignored +fmt PASS на новом exact SHA. |
| Definition of Done | Новый source-bound record, diff только reviewed fixture/fmt; никаких transport/SDK изменений. |

## W02 — Собрать проверенный integration acceptance diff

| Поле | Значение |
|---|---|
| Target PR | A01 |
| Входные данные | Исправленный W01 + PR10 source heads4/currentmain snapshot |
| Точные изменения | Owner-approved nonrewriting merge #11→#10; refreshdocs/evidence; ancestor tests всех4heads. Сам merge вmain делает владелец. |
| Инварианты | INV-TEST-01; INV-CMD-01 |
| Тесты | T-X02 |
| План проверок | Все7Cargo commands+diffserial, test inventory assertions preserved, code-vs-doc hashes. |
| Ожидаемый результат | Один reviewable integration SHA с45 tests и exact source lineage. |
| Definition of Done | Draft ready, исходные PR не переписаны; main неизменён до отдельного owner merge; old evidence retained. |

## W03 — Закрепить инвентари и минимальный static plan/contract validator

| Поле | Значение |
|---|---|
| Target PR | A02 |
| Входные данные | Этот bundle, raw112catalog/schema/source manifests, existing8SKLT |
| Точные изменения | Добавить reviewed manifests/ref integrity tests в verification/ и minimal docs; objectIDs прежние; дописать Remote/Render direct API dependency declarations. |
| Инварианты | INV-ID-01; INV-ID-03; INV-ID-04; INV-AUTH-02; INV-AUTH-04; INV-CMD-03; INV-CANCEL-01; INV-RENDER-01; INV-RENDER-05; INV-RENDER-07; INV-TEST-01; INV-STRUCT-01; INV-PARITY-01; INV-PLATFORM-01 |
| Тесты | T-001; T-003; T-004; T-006; T-008; T-011; T-015; T-024; T-028; T-030; T-035; T-051; T-X01 |
| План проверок | 112 set equality/schema/caps; testnames+sourceIDs; DAG/no unknown refs; SKLT graph drift. |
| Ожидаемый результат | Воспроизводимый source-only baseline, не runtime PASS. |
| Definition of Done | Validator запускается без model/GPU/network/install, все ссылки/колонки присутствуют; no GLIF/adoption. |

## W04 — Согласовать конкретный Windows qualification profile/ADR

| Поле | Значение |
|---|---|
| Target PR | A03 |
| Входные данные | Makepad130be pinned Windows sources/runtime appendix + hard constraints |
| Точные изменения | Новый doc/windows-feasibility.md: точный app entry/readback/hot-reload-off/token/desktop/profile; A/B risks, exact budgets, prerequisites и forbidden calls. |
| Инварианты | INV-RENDER-08; INV-PLATFORM-01; INV-RENDER-02; INV-PROC-05 |
| Тесты | T-031; T-052; T-X12 |
| План проверок | Static named source refs, no user-desktop/global-input imports/call paths; recipe dry review без запуска. |
| Ожидаемый результат | Одно минимальное проверяемое candidate решение или source-level NO-GO. |
| Definition of Done | Все prerequisites проверяемы; отсутствие GPU/env остаётся NOT_RUN; никаких host изменений. |

## W05 — Создать минимальный trusted app-owned frame fixture

| Поле | Значение |
|---|---|
| Target PR | A03 |
| Входные данные | Approved W04, Makepad pin, public texture readback refs,7crate interface |
| Точные изменения | Opt-in fixture в MSS_SDK/tests/fixtures/native_frame_app: два поля, counter, nonce region, RenderBGRAu8 readback ticket; disabled network/dialog/plugins/hot-reload; no SDK copy. Вложенный fixture Cargo.toml содержит standalone [workspace], exact Makepad revision и собственный lockfile; не добавлять его неявно в root workspace. |
| Инварианты | INV-RENDER-08; INV-PLATFORM-01; INV-RENDER-02; INV-PROC-05 |
| Тесты | T-031; T-052; T-X12 |
| План проверок | Targeted fmt/check и synthetic adapter contracts; live frame gate отдельно в W06. Отдельные cargo metadata/check/test --manifest-path MSS_SDK/tests/fixtures/native_frame_app/Cargo.toml --locked; root checks не заменяют это. Public entry/readback Signal ticket drain проверять источником, не обещать по имени Texture. |
| Ожидаемый результат | Source-reviewed fixture с явным Unsupported если public producer hook недоступен. |
| Definition of Done | No upstreammods/globalinput; no fabricated pixels/capture success; ограниченные memory/frame specs. |

## W06 — Первый контролируемый Windows app-origin frame experiment

| Поле | Значение |
|---|---|
| Target PR | A03 |
| Входные данные | W05 + отдельно owner-approved физический Windows/GPU/run profile; fixed-fixture retained-handle/Job/bootstrap harness, ещё не production ProcessLease/API auth. |
| Точные изменения | Harness запускает только exact fixturebinary own Job/private object, измеряет30frames/nonce/readback/health/cleanup; source/OS/driver/pins/time в evidence. На этом этапе только read/capture и self-driven nonce, внешняя mutation закрыта до A06; обязательный named B case T-X12. Shared A tests только если выбран A, иначе честный NO-GO/NOT_RUN. |
| Инварианты | INV-RENDER-08; INV-PLATFORM-01; INV-RENDER-02; INV-PROC-05 |
| Тесты | T-031; T-052; T-X12 |
| План проверок | Good frame + wrongbinding + capturetimeout + normal/Job cleanup; hosted comparative cases only if admitted. |
| Ожидаемый результат | GO либо конкретный NO-GO; никакого user desktop fallback. |
| Definition of Done | Every PASS real renderer/process observation; no app started без run authorization; absent prerequisites NOT_RUN. |

## W07 — Минимальный Core ProcessLease/epoch owner

| Поле | Значение |
|---|---|
| Target PR | A04 |
| Входные данные | W04/W06 proof, currentCore API, broker primitive patterns reviewed как reference |
| Точные изменения | MSS_Core/windows owner module: epoch, retainedhandles, image/birth identity, suspendedJoblaunch, own-only cleanup/quarantine; dependency review exact Windows pin first. |
| Инварианты | INV-ID-02; INV-PROC-01; INV-PROC-02; INV-PROC-03; INV-PROC-05 |
| Тесты | T-002; T-017; T-018; T-021; T-X11 |
| План проверок | Generation/PID/image mismatch, assignmentfailure, childdeath, neighborpreservation; existing16Core tests. Runtime-profile inherited-handle canary T-X11 отдельно от broker profile. |
| Ожидаемый результат | Own process нельзя перепутать с logicalID/соседом. |
| Definition of Done | Native evidence on approvedprofile; Core прежние publiccontracts preserved, no blanket foreign process access. |

## W08 — Read-only authenticated SDK/API channel

| Поле | Значение |
|---|---|
| Target PR | A05 |
| Входные данные | W07 ProcessLease, W05fixture, RequestContext auth-first contract |
| Точные изменения | Protected namedpipe handshake peeridentity+launchcapability; app-provided capabilities/state; derivingprincipal->context; disable rawRemoteHTTP. |
| Инварианты | INV-AUTH-01; INV-AUTH-03; INV-CMD-02 |
| Тесты | T-005; T-007; T-010 |
| План проверок | Wrongprincipal/PID/nonce/generation/targetcap, direct-port bypassnegative; no mutation route beforeledger. |
| Ожидаемый результат | Один actual read/frame producer связан с exact own app, forged requests denied. |
| Definition of Done | No secretslogs; no secondregistry; unsupported actions explicit; actual channel deny not gateway-only mock. |

## W09 — Reserved/dispatched/observed/unknown ledger до первой mutation

| Поле | Значение |
|---|---|
| Target PR | A06 |
| Входные данные | W08 authenticated contexts + proposed requesttuple/generation |
| Точные изменения | Small bounded per-session ledger атомарно reserve; commandseq/duplicate/refusal/cancel/outcome; independent fixture counterread. В scope включён SDK trusted fixture action/counter+observer после ledger reserve для реального lost-reply case; до reserve никакой app mutation. |
| Инварианты | INV-CMD-04; INV-CMD-05; INV-CANCEL-02 |
| Тесты | T-012; T-013; T-016 |
| План проверок | Tworequests race, wronggeneration, seqMAX, lostreplyaftereffect, workerloss, cancel phases. |
| Ожидаемый результат | Не более одного effect и no automatic unknown replay. |
| Definition of Done | Property/race+native fault cases source-bound; existingRemote NotDispatched path unchanged without executor. |

## W10 — Первая безопасная registry/disabled-dispatcher reconciliation

| Поле | Значение |
|---|---|
| Target PR | B00 |
| Входные данные | PR5baseb455/currentmain83 + PR7policy/catalog + infraaudit |
| Точные изменения | Разрешить только AGENTS overlap с сохранением строгих правил main/Cargo.lock; сохранить GOAL IDs, описатьstale refs; отдельныйпланcatalogNode/broker exactchecks, no enablement. |
| Инварианты | INV-STRUCT-01; INV-GITHUB-02 |
| Тесты | T-044; T-051 |
| План проверок | Schema/GOAL/source/dependency validator; future B01 retain80model-free tests; enabledfalse/noVERIFIED. |
| Ожидаемый результат | Проверяемый diff реестра без потериconstraints и duplicateGOAL system. |
| Definition of Done | Owner-controlled sourceupdateapproval; no Secrets/runner/dispatcher/main switch, all blocked prerequisites retained. |

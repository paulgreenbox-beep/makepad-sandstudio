// Read-only source/evidence extraction for the master plan. Does not run checks.
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');
const root = process.env.MSS_AUDIT_SOURCE_ROOT;
if (!root) throw new Error('Set MSS_AUDIT_SOURCE_ROOT to the local audit source directory.');
const repo = path.join(root, 'mss-integration-pr1-4');
const out = path.join(root, 'mss-master-plan-20261030/runtime');
const makepad = process.env.MAKEPAD_SOURCE_ROOT;
if (!makepad) throw new Error('Set MAKEPAD_SOURCE_ROOT to the pinned Makepad checkout.');
const makepadSha = '130be1d0318adcf69453d925342607466353152c';
const revisions = [
  ['main', '83ff50112fbbdc1cd2a43ccd2ac1650504394a67'],
  ['pr1', '6998cef53077eab021f129e583d4979e2e70e297'],
  ['pr2', 'abcf43b08a13da5fbf70ba1b66ef16de512ebcb5'],
  ['pr3', 'ad42653ac6e5b60c63262e48441a02607b0e5d83'],
  ['pr4', 'de2d32ee44cbab5882a5f5bf359db89e565cd26f'],
  ['pr10', '8863cc326b99f8d76b2bf66725d87540aab79f02'],
  ['pr11', '192b81ac83cfa3945318804430af25b3795609ad'],
];
const git = (...args) => cp.execFileSync('git', args, { cwd: repo, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 });
const bytes = (sha, file) => cp.execFileSync('git', ['show', `${sha}:${file}`], { cwd: repo, maxBuffer: 20 * 1024 * 1024 });
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const coreEvidencePath = path.join(repo, 'doc/cronica/20261030-core-pr1.json');
const integrationEvidencePath = path.join(repo, 'doc/cronica/20261030-integration-pr1-4.json');
const pr11EvidencePath = path.join(root, 'mss-pr11-windows-evidence-192b81a/summary.json');
const e1 = json(coreEvidencePath), e10 = json(integrationEvidencePath), e11 = json(pr11EvidencePath);
const evidence = {
  pr1: { source: e1.source_commit, record: 'https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/6998cef53077eab021f129e583d4979e2e70e297/doc/cronica/20261030-core-pr1.json', sha256: hash(fs.readFileSync(coreEvidencePath)), checks: e1.checks },
  pr10: { source: e10.source_commit, record: 'https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/8863cc326b99f8d76b2bf66725d87540aab79f02/doc/cronica/20261030-integration-pr1-4.json', sha256: hash(fs.readFileSync(integrationEvidencePath)), checks: e10.checks },
  pr11: { source: e11.source_commit, record: pr11EvidencePath, sha256: hash(fs.readFileSync(pr11EvidencePath)), checks: e11.checks },
};
const allTests = new Map(), files = [], revisionSummary = [];
for (const [revision, sha] of revisions) {
  const paths = git('ls-tree', '-r', '--name-only', sha).trim().split('\n').filter(Boolean);
  const reviewed = paths.filter(f => /^(MSS_[^/]+\/(?:src\/.+\.rs|tests\/.+|README\.md|[^/]+\.sklt|Cargo\.toml)|(?:Cargo\.toml|Cargo\.lock|README\.md|AGENTS\.md|SECURITY\.md)|doc\/(?:architecture|maps|compatibility|testing|dungeon)\.md)$/.test(f));
  let count = 0;
  const moduleCounts = {};
  for (const file of reviewed) {
    const data = bytes(sha, file), text = data.toString('utf8');
    files.push({ repository: 'paulgreenbox-beep/makepad-sandstudio', revision, source_sha: sha, path: file, bytes: data.length, sha256: hash(data), line_count: text.split('\n').length, url: `https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/${sha}/${file}`, method: 'git show at exact immutable SHA; read-only' });
    if (!file.endsWith('.rs')) continue;
    const matcher = /#\[test\]\s*(?:#\[[^\]]+\]\s*)*fn\s+([a-zA-Z_][a-zA-Z_0-9]*)\s*\(/g;
    let match;
    while ((match = matcher.exec(text))) {
      const name = match[1], fnOffset = text.indexOf(`fn ${name}`, match.index);
      const line = text.slice(0, fnOffset).split('\n').length;
      const nextAttr = text.indexOf('#[test]', matcher.lastIndex);
      const body = text.slice(fnOffset, nextAttr < 0 ? text.length : nextAttr);
      const module = file.split('/')[0], target = file.includes('/tests/') ? path.posix.basename(file, '.rs') : 'lib';
      const key = `${module}/${target}/${name}`;
      let item = allTests.get(key);
      if (!item) { item = { id: key, module, target, function_name: name, harness_name: file.includes('/tests/') ? name : `tests::${name}`, evidence_level: 'RUST_LOGICAL_UNIT_OR_PUBLIC_COMPOSITION_ONLY', native_gui_or_toolkit_acceptance: 'NOT_VERIFIED', revisions: [] }; allTests.set(key, item); }
      let result = 'NOT_RUN', source = null, resultSource = null, note = 'No exact-head execution evidence supplied for this source PR; do not inherit integration PASS.';
      if (revision === 'pr1') {
        const equal = hash(bytes(e1.source_commit, file)) === hash(data);
        if (equal) { result = 'PASS'; source = e1.source_commit; resultSource = evidence.pr1.record; note = 'Published head file byte-identical to exact tested Core file; historical source-level development evidence.'; }
      } else if (revision === 'pr10') {
        const equal = hash(bytes(e10.source_commit, file)) === hash(data);
        const tc = e10.checks.find(c => c.name === 'test').test_cases.find(t => t.test === item.harness_name);
        if (!equal || !tc) throw new Error(`Integration evidence not bound: ${key}`);
        result = tc.outcome === 'ok' ? 'PASS' : 'FAIL'; source = e10.source_commit; resultSource = evidence.pr10.record;
        note = 'Published head source file byte-identical to tested source. Synthetic logical/PNG fixture evidence only.';
      } else if (revision === 'pr11') {
        const tc = e11.checks.find(c => c.name === 'test').test_cases.find(t => t.test === item.harness_name);
        if (!tc) throw new Error(`PR11 evidence missing: ${key}`);
        result = tc.outcome === 'ok' ? 'PASS' : 'FAIL'; source = e11.source_commit; resultSource = pr11EvidencePath;
        note = result === 'FAIL' ? 'Unmodified Unicode fixture contains literal doubled backslash; assertion expected InvalidInput, observed NotDispatched; remaining loop cases not proven.' : 'Historical exact-source local Windows Rust test evidence; no runtime GUI acceptance.';
      }
      item.revisions.push({ revision, present: true, source_sha: sha, path: file, line, url: `https://github.com/paulgreenbox-beep/makepad-sandstudio/blob/${sha}/${file}#L${line}`, file_sha256: hash(data), body_excerpt_sha256: hash(body), result, result_source_sha: source, result_source: resultSource, note });
      count++; moduleCounts[module] = (moduleCounts[module] ?? 0) + 1;
    }
  }
  revisionSummary.push({ revision, sha, behavioral_test_count: count, by_module: moduleCounts, native_process_tests: 0, toolkit_execution: 'NOT_RUN', runtime_acceptance: 'NOT_VERIFIED' });
}
for (const item of allTests.values()) {
  const known = new Set(item.revisions.map(r => r.revision));
  for (const [revision, sha] of revisions) if (!known.has(revision)) item.revisions.push({ revision, present: false, source_sha: sha, result: 'NOT_RUN', reason: 'Test absent in this tree. No fabricated result.' });
  item.revisions.sort((a, b) => revisions.findIndex(r => r[0] === a.revision) - revisions.findIndex(r => r[0] === b.revision));
}
const tests = [...allTests.values()].sort((a, b) => a.id.localeCompare(b.id));
const makepadPaths = [
  'Cargo.toml', 'widgets/Cargo.toml', 'platform/Cargo.toml',
  'platform/src/app_main.rs', 'platform/src/web_socket.rs', 'platform/src/cx.rs', 'platform/src/cx_api.rs',
  'platform/src/remote.rs', 'platform/src/remote_activity.rs', 'platform/src/hosted_relay.rs', 'platform/src/memory_watchdog.rs',
  'platform/src/os/cx_shared.rs', 'platform/src/os/shared_framebuf.rs',
  'platform/src/os/windows/windows.rs', 'platform/src/os/windows/windows_stdin.rs', 'platform/src/os/windows/d3d11.rs',
  'platform/src/os/windows/win32_app.rs', 'platform/src/os/windows/win32_window.rs', 'platform/src/os/windows/windows_game_input.rs',
  'platform/src/texture.rs', 'platform/src/os/linux/hosted_gpu.rs',
  'platform/studio/src/studio.rs', 'platform/studio/src/shared_framebuf.rs', 'platform/studio/src/gpu.rs',
  'widgets/core/src/hosted_view.rs', 'apps/wm/src/run_view.rs',
];
for (const file of makepadPaths) {
  const data = fs.readFileSync(path.join(makepad, file));
  const pinned = cp.execFileSync('git', ['show', `${makepadSha}:${file}`], { cwd: makepad, maxBuffer: 20 * 1024 * 1024 });
  const normalized = buffer => buffer.toString('utf8').replace(/\r\n/g, '\n');
  if (normalized(data) !== normalized(pinned)) throw new Error(`Makepad cached source differs beyond line endings: ${file}`);
  files.push({ repository: 'makepad/makepad', revision: 'pinned-and-live-dev', source_sha: makepadSha, path: file, bytes: pinned.length, sha256: hash(pinned), cache_bytes: data.length, cache_sha256: hash(data), cached_content_matches_exact_git_object_after_crlf_normalization: true, line_count: normalized(pinned).split('\n').length, url: `https://github.com/makepad/makepad/blob/${makepadSha}/${file}`, method: 'read-only pinned Cargo cache source checked against exact git object; Windows CRLF normalization recorded explicitly; selected full paths and cross-references; no build/run' });
}
const documents = [
  ['win32k-policy','https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-process_mitigation_system_call_disable_policy','DisallowWin32kSystemCalls blocks GUI syscalls; broker profile is not GUI runtime profile.'],
  ['exploit-reference','https://learn.microsoft.com/en-us/defender-endpoint/exploit-protection-reference','Win32k disable targets dedicated non-UI processes; GUI compatibility must not be presumed.'],
  ['dxgi-create-handle','https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_2/nf-dxgi1_2-idxgiresource1-createsharedhandle','NULL security attributes uses creator default SD; named-resource precreation risk; explicit random/private or duplicated-handle design requires qualification.'],
  ['dxgi-keyed-acquire','https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgikeyedmutex-acquiresync','Accept only S_OK; explicitly classify WAIT_TIMEOUT/WAIT_ABANDONED; abandoned surface must be recreated.'],
  ['create-station','https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-createwindowstationw','Named station admin restriction, NULL LUID-derived station, CWF_CREATE_ONLY existing-station refusal; explicit SD required.'],
  ['create-desktop','https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-createdesktopw','Desktop belongs to process window station; may return existing object; USER32 API.'],
  ['station-creation','https://learn.microsoft.com/en-us/windows/win32/winstation/window-station-and-desktop-creation','Interactive and service/noninteractive desktop assignment differs; physical host qualification remains required.'],
  ['set-thread-desktop','https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setthreaddesktop','Cannot rebind UI thread after windows/hooks; desktop bound before app UI initialization.'],
  ['d3d-device','https://learn.microsoft.com/en-us/windows/win32/direct3d11/overviews-direct3d-11-devices-intro','Device creation separated from swapchain; immediate-context calls require one-thread serialization.'],
];
const now = new Date().toISOString();
const inventory = { schema: 'mss-masterplan-runtime-test-inventory-v1', generated_at: now, extraction: 'Read-only git/source/evidence analysis. No build, check, test, app or model execution performed in this planning task.', deduplication: 'module + target + exact function name; revision presence/results retained; no double counting focused/workspace same cases', accepted_result_states: ['PASS','FAIL','BLOCKED','NOT_RUN','NOT_VERIFIED'], evidence_levels: { SOURCE_REVIEW: 'code declarations only', RUST_LOGICAL_UNIT_OR_PUBLIC_COMPOSITION_ONLY: 'executed source-bound Rust tests; no live app/GPU/desktop evidence', NATIVE_RUNTIME: 'no accepted result in inspected runtime trees' }, revisions: revisionSummary, unique_named_tests: tests.length, tests, historical_execution_records: evidence, limitations: ['main has zero behavioral tests', 'Source PRs2-4 have test declarations but no accepted exact-head run', 'PR10 44 PASS belongs to tested352e2c3 and identical source files at published8863cc3', 'PR11 44 PASS1 FAIL plus fmt FAIL; no correction authorized', 'No SDK/MCP/Desktop behavioral tests; no .aiui.json execution', 'Development records are not independent release/security certification'] };
const manifest = { schema: 'mss-runtime-source-reference-manifest-v1', generated_at: now, repository: 'https://github.com/paulgreenbox-beep/makepad-sandstudio', github_read_only_refresh: { main: revisions[0][1], pr1: revisions[1][1], pr2: revisions[2][1], pr3: revisions[3][1], pr4: revisions[4][1], pr10: revisions[5][1], pr11: revisions[6][1], prs_draft_open_unmerged: true, makepad_dev_head: makepadSha, makepad_mss_pin: makepadSha, dev_sha_gap: 0, caveat: 'Snapshot checked via connected GitHub GET before artifact generation; no branch upgrade or mutation.' }, files, official_documents: documents.map(([id,url,claim])=>({id,url,claim,consulted_on:'2026-10-30',source_type:'Microsoft official primary API documentation',runtime_qualification:false})), evidence_records: Object.entries(evidence).map(([revision,e])=>({revision,source_sha:e.source,record:e.record,sha256:e.sha256})), source_checkouts: [{path:repo,head:git('rev-parse','HEAD').trim(),status:git('status','--porcelain').trim()}, {path:path.join(root,'mss-pr11-windows-tests'),head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:path.join(root,'mss-pr11-windows-tests'),encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:path.join(root,'mss-pr11-windows-tests'),encoding:'utf8'}).trim()}] };
fs.writeFileSync(path.join(out,'runtime-test-inventory.json'),JSON.stringify(inventory,null,2)+'\n');
fs.writeFileSync(path.join(out,'source-reference-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({unique_named_tests:tests.length,revisions:revisionSummary,source_files:files.length,planning_runs:0}));
